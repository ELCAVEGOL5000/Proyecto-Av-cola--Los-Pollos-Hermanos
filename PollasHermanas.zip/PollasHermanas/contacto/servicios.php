
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Lotes de Aves</title>
  <link rel="stylesheet" href="servicios.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>
<body>

  <header>
  <div class="logo">
      <div class="icon" id="icon"></div>
      Sky Line
      <span class="corp">Corp</span>
    </div>
    <nav>
      <ul>
          <li><a href="servicios.php">Servicios</a></li>
          <li><a href="nosotros.php">Nosotros</a></li>
          <li><a href="contacto.php">Contacto</a></li>
      </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">dashboard</span> Panel de Control</a></li>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../alimentacion/alimentacion.php"><span class="material-symbols-outlined">restaurant</span> Alimentación</a></li>
      <li><a href="../salud/salud.php"><span class="material-symbols-outlined">favorite</span> Salud</a></li>
      <li><a href="../produccion/produccion.php"><span class="material-symbols-outlined">egg</span> Producción</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="confi" href="configuracion.php"><span class="material-symbols-outlined">settings</span> Configuración</a></li>
      <li><a class="cerrarSesion" href="../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

  <section id="servicios" class="servicios">
    <div class="container">
      <h1>Paneles del Sistema</h1>

      <div class="panel-card">
        <h2>👷 Panel de Operarios</h2>
        <p>
          Este panel está diseñado para el personal que trabaja directamente con los lotes de aves. Su objetivo es facilitar el registro diario de actividades operativas y mantener el control sobre el estado de cada lote.
        </p>
        <ul>
          <li>Registro de alimentación, salud y producción por lote.</li>
          <li>Alertas automáticas para tareas pendientes como vacunación o limpieza.</li>
          <li>Visualización del estado general del lote: salud, consumo y rendimiento.</li>
          <li>Interfaz simple y rápida para uso en campo.</li>
        </ul>
        <div class="evitar">
          <strong>⚠️ Evitar:</strong>
          <ul>
            <li>Registrar datos incompletos o sin supervisión.</li>
            <li>Omitir tareas por falta de tiempo o recursos.</li>
            <li>Modificar información sin autorización.</li>
          </ul>
          <div class="tips">
        <h2>🧠 Tips para Operarios</h2>
        <ul>
            <li>✅ Registrá los datos apenas completes la tarea para evitar olvidos.</li>
            <li>📷 Si tenés acceso a cámara, podés documentar anomalías visualmente.</li>
            <li>🗓️ Usá el historial para verificar si una tarea ya fue realizada.</li>
            <li>📌 Consultá con el supervisor si algo no está claro antes de registrar.</li>
            <li>🧼 Mantené el orden en los registros para facilitar auditorías.</li>
        </ul>
</div>
</div>

<script src="../../sidebar.js"></script>

</body>
</html>