<?php
session_start();
require_once '../../Sesion/config.php';

if (!isset($_SESSION['usuario_id'])) {
  header('Location: ../../Sesion/inicioSesion.php');
  exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Variable para mensaje
$mensaje = "";

// --- Agregar nuevo lote ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_registro'])) {
  $codigo_lote = $conn->real_escape_string($_POST['codigo_lote_nuevo']);
  $tipo = $conn->real_escape_string($_POST['tipo_nuevo']);
  $cantidad = (int) $_POST['cantidad_nueva'];
  $fecha_inicio = $conn->real_escape_string($_POST['fecha_inicio_nueva']);
  $estado = 'activo';

  $sqlInsert = "INSERT INTO lotes (codigo_lote, tipo, cantidad, fecha_inicio, estado)
                VALUES ('$codigo_lote', '$tipo', $cantidad, '$fecha_inicio', '$estado')";
  
  if ($conn->query($sqlInsert) === TRUE) {
      // Redirigir con mensaje de éxito
      header("Location: " . $_SERVER['PHP_SELF'] . "?mensaje=Lote agregado correctamente");
      exit();
  } else {
      $mensaje = "Error al insertar lote: " . $conn->error;
  }
}

// --- Mostrar mensaje desde URL ---
if (isset($_GET['mensaje'])) {
    $mensaje = $_GET['mensaje'];
}

$sql = "SELECT * FROM lotes ORDER BY fecha_inicio ASC, id ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Lotes</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<link rel="stylesheet" href="lotes.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<!-- BOTÓN MENU TOGGLE FUERA DEL SIDEBAR PARA QUE SIEMPRE SEA VISIBLE -->
<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">home</span> Panel de Control</a></li>
      <li class="active"><a href="lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../alimentacion/alimentacion.php"><span class="material-symbols-outlined">restaurant</span> Alimentación</a></li>
      <li><a href="../salud/salud.php"><span class="material-symbols-outlined">favorite</span> Salud</a></li>
      <li><a href="../produccion/produccion.php"><span class="material-symbols-outlined">egg</span> Producción</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<div id="main-content">
  <h1>Lotes</h1>

  <table>
    <thead>
      <tr>
        <th>Código</th>
        <th>Tipo</th>
        <th>Cantidad</th>
        <th>Fecha de Inicio</th>
        <th>Estado</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result->num_rows > 0): ?>
        <?php while($lote = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($lote['codigo_lote']) ?></td>
            <td><?= htmlspecialchars($lote['tipo']) ?></td>
            <td><?= htmlspecialchars($lote['cantidad']) ?></td>
            <td><?= htmlspecialchars($lote['fecha_inicio']) ?></td>
            <td>
              <span class="estado <?= strtolower($lote['estado']) ?>">
                <?= htmlspecialchars(ucfirst($lote['estado'])) ?>
              </span>
            </td>
          </tr>
          <?php endwhile; ?>  <?php else: ?>
            <tr><td colspan="6">No hay lotes activos.</td></tr> <?php endif; ?>
          </table>
        </div>

 <!-- Formulario oculto inicialmente -->
 <div id="formulario-agregar" class="formulario-agregar">
  <h2>Agregar Nuevo Lote</h2>
  <form id="formAgregarRegistro" method="POST" action="">
    <input type="hidden" name="agregar_registro" value="1" />

    <div class="form-group">
        <label for="codigo_lote_nuevo">Código Lote:</label>
        <input type="text" id="codigo_lote_nuevo" name="codigo_lote_nuevo" required />
      </div>

      <div class="form-group">
        <label for="tipo_nuevo">Tipo:</label>
        <input type="text" id="tipo_nuevo" name="tipo_nuevo" required />
      </div>

      <div class="form-group">
        <label for="cantidad_nueva">Cantidad:</label>
        <input type="number" step="0.01" id="cantidad_nueva" name="cantidad_nueva" required />
      </div>

      <div class="form-group">
        <label for="fecha_inicio_nueva">Fecha de Inicio:</label>
        <input type="date" id="fecha_inicio_nueva" name="fecha_inicio_nueva" required />
      </div>


    <div class="form-buttons">
      <button type="submit" class="btn guardar">Guardar</button>
      <button type="button" id="btnCancelar" class="btn cancelar">Cancelar</button>
    </div>
  </form>
</div>


<script src="../../sidebar.js"></script>
</body>
</html>
