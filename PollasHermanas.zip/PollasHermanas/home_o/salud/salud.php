<?php
include '../../Sesion/config.php';

$mensaje = '';

// Manejo de formulario POST para insertar datos de salud
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lote_id'])) {
    $lote_id = $conn->real_escape_string($_POST['lote_id']);
    $fecha = $conn->real_escape_string($_POST['fecha']);
    $tipo_control = $conn->real_escape_string($_POST['tipo_control']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);
    $resultado_salud = $conn->real_escape_string($_POST['resultado']);

    $sql_insert = "INSERT INTO salud (lote_id, fecha, tipo_control, descripcion, resultado) 
                   VALUES ('$lote_id', '$fecha', '$tipo_control', '$descripcion', '$resultado_salud')";
    if ($conn->query($sql_insert) === TRUE) {
        $mensaje = "Registro de salud agregado correctamente.";
        // Redirigir para evitar reenvío POST y preservar filtros GET si existen
        header('Location: salud.php' . (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''));
        exit();
    } else {
        $mensaje = "Error al agregar registro: " . $conn->error;
    }
}

$sql_lotes = "SELECT * FROM lotes WHERE estado = 'activo'";
$resultado_lotes = $conn->query($sql_lotes);

$tipos_control = ['Control de Salud', 'Vacunación', 'Otro tipo'];
$sql_tipos = "SELECT DISTINCT tipo_control FROM salud ORDER BY tipo_control";
$resultado_tipos = $conn->query($sql_tipos);

$where_clause = 'WHERE 1=1';
if (isset($_GET['tipo_control']) && !empty($_GET['tipo_control']) && $_GET['tipo_control'] !== 'Filtrar por Tipo de Control') {
    $tipo_filtro = $conn->real_escape_string($_GET['tipo_control']);
    $where_clause .= " AND s.tipo_control = '$tipo_filtro'";
}
if (isset($_GET['resultado']) && !empty($_GET['resultado']) && $_GET['resultado'] !== 'Filtrar por Resultado' && $_GET['resultado'] !== 'Todos') {
    $resultado_filtro = $conn->real_escape_string($_GET['resultado']);
    $where_clause .= " AND s.resultado = '$resultado_filtro'";
}

$sql_salud_filtrada = "SELECT s.*, l.codigo_lote 
                       FROM salud s 
                       INNER JOIN lotes l ON s.lote_id = l.id 
                       $where_clause 
                       ORDER BY s.fecha DESC";
$resultado_salud = $conn->query($sql_salud_filtrada);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Monitoreo de Salud Avícola</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<link rel="stylesheet" href="salud.css">

<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>

<script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#f5e3b3",
                        "background-light": "#f6f8f6",
                        "background-dark": "#152111",
                    },
                    fontFamily: {
                        "display": ["Inter"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.25rem",
                        "lg": "0.5rem",
                        "xl": "0.75rem",
                        "full": "9999px"
                    },
                },
            },
        }
</script>
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>
  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">Sky Line <span class="corp">Corp</span></span>
      </div>
    </div>
    <ul>
      <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">home</span> Panel de control</a></li>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../alimentacion/alimentacion.php"><span class="material-symbols-outlined">restaurant</span> Alimentación</a></li>
      <li class="active"><a href="salud.php"><span class="material-symbols-outlined">favorite</span> Salud</a></li>
      <li><a href="../produccion/produccion.php"><span class="material-symbols-outlined">egg</span> Producción</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<main class="flex-1 p-6 lg:p-10">
<div class="titulo">
<h1 class="text-4xl font-bold text-gray-900 dark:text-white mb-4">Historial de Salud del Lote</h1>
<p class="text-gray-500 dark:text-gray-400 mb-6">Monitoreo y registro de la salud de los lotes de aves.</p>
</div>

<?php if (!empty($mensaje)): ?>
  <div class="mb-4 p-3 bg-green-200 text-green-800 rounded"><?= htmlspecialchars($mensaje) ?></div>
<?php endif; ?>

<div class="flex flex-col lg:flex-row gap-6">

  <!-- Formulario -->
  <aside id="formulario" class="w-full lg:w-80 bg-background-light dark:bg-background-dark border border-gray-200 dark:border-gray-800 p-6 rounded-xl shadow-md">
    <h2 class="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Añadir Registro de Salud</h2>
    <form method="POST" class="space-y-4">

      <div>
        <label for="lote_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Lote</label>
        <select name="lote_id" id="lote_id" required class="form-select w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50">
          <option value="">Seleccionar Lote</option>
          <?php if ($resultado_lotes) $resultado_lotes->data_seek(0); while ($lote = $resultado_lotes->fetch_assoc()): ?>
            <option value="<?= $lote['id'] ?>"><?= htmlspecialchars($lote['codigo_lote']) ?> (<?= htmlspecialchars($lote['tipo']) ?> - <?= htmlspecialchars($lote['cantidad']) ?> aves)</option>
          <?php endwhile; ?>
        </select>
      </div>

      <div>
        <label for="fecha" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Fecha</label>
        <input type="date" name="fecha" id="fecha" required class="w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50 px-3 py-2" />
      </div>

      <div>
        <label for="tipo_control" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tipo de Control</label>
        <select name="tipo_control" id="tipo_control" required class="form-select w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50">
          <option value="">Seleccionar Control</option>
          <?php foreach ($tipos_control as $tipo): ?>
  <option value="<?= htmlspecialchars($tipo) ?>" <?= (isset($_GET['tipo_control']) && $_GET['tipo_control'] === $tipo) ? 'selected' : '' ?>>
    <?= htmlspecialchars($tipo) ?>
  </option>
<?php endforeach; ?>

        </select>
      </div>

      <div>
        <label for="descripcion" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Descripción</label>
        <textarea name="descripcion" id="descripcion" rows="3" placeholder="Descripción detallada del control" class="w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50 px-3 py-2"></textarea>
      </div>

      <div>
        <label for="resultado" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Resultado</label>
        <select name="resultado" id="resultado" required class="form-select w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50">
          <option value="">Seleccionar Resultado</option>
          <option value="saludable">Saludable</option>
          <option value="enfermo">Enfermo</option>
          <option value="vacunado">Vacunado</option>
        </select>
      </div>

      <div>
        <button type="submit" class="w-full bg-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-primary/90 transition-colors duration-300 flex items-center justify-center" style="color: black;"> 
          <span class="material-symbols-outlined mr-2">add_circle</span> Añadir Registro
        </button>
      </div>
    </form>
  </aside>

  <!-- Tabla -->
  <section class="flex-1 overflow-x-auto bg-white dark:bg-gray-900 rounded-xl shadow-md p-6">
    <!-- Filtros -->
    <div class="mb-6">
      <form method="GET" class="flex flex-col sm:flex-row gap-4">
        <div class="flex-1">
          <label class="sr-only" for="filter_tipo">Filtrar por Tipo de Control</label>
          <select name="tipo_control" id="filter_tipo" class="form-select w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50">
            <option value="">Filtrar por Tipo de Control</option>
            <?php 
            if ($resultado_tipos) $resultado_tipos->data_seek(0);
            while ($tipo = $resultado_tipos->fetch_assoc()):
            ?>
              <option value="<?= htmlspecialchars($tipo['tipo_control']) ?>" <?= (isset($_GET['tipo_control']) && $_GET['tipo_control'] === $tipo['tipo_control']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($tipo['tipo_control']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="flex-1">
          <label class="sr-only" for="filter_resultado">Filtrar por Resultado</label>
          <select name="resultado" id="filter_resultado" class="form-select w-full rounded-lg border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:border-primary focus:ring-primary/50">
            <option value="">Filtrar por Resultado</option>
            <option value="Todos" <?= (!isset($_GET['resultado']) || $_GET['resultado'] === 'Todos' || empty($_GET['resultado'])) ? 'selected' : '' ?>>Todos</option>
            <option value="saludable" <?= (isset($_GET['resultado']) && $_GET['resultado'] === 'saludable') ? 'selected' : '' ?>>Saludable</option>
            <option value="enfermo" <?= (isset($_GET['resultado']) && $_GET['resultado'] === 'enfermo') ? 'selected' : '' ?>>Enfermo</option>
            <option value="vacunado" <?= (isset($_GET['resultado']) && $_GET['resultado'] === 'vacunado') ? 'selected' : '' ?>>Vacunado</option>
          </select>
        </div>
        <div class="flex sm:flex-row gap-2">
          <button type="submit" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90" style="color: black;">Filtrar</button>
          <?php if (isset($_GET['tipo_control']) || isset($_GET['resultado'])): ?>
            <a href="salud.php" class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">Limpiar</a>
          <?php endif; ?>
        </div>
      </form>
    </div>

    <!-- Tabla con registros -->
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
      <thead class="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-gray-800">
        <tr>
          <th class="px-6 py-3">Lote</th>
          <th class="px-6 py-3">Fecha</th>
          <th class="px-6 py-3">Tipo de Control</th>
          <th class="px-6 py-3">Descripción</th>
          <th class="px-6 py-3 text-center">Resultado</th>
          <th class="px-6 py-3 text-center">Acciones</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($resultado_salud && $resultado_salud->num_rows > 0): ?>
        <?php while ($registro = $resultado_salud->fetch_assoc()):
          $color_class = 'bg-gray-100 text-gray-800 dark:bg-gray-900/50 dark:text-gray-300';
          $texto_resultado = ucfirst($registro['resultado']);
          switch ($registro['resultado']) {
            case 'saludable': $color_class = 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300'; break;
            case 'enfermo': $color_class = 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'; break;
            case 'vacunado': $color_class = 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300'; break;
          }
        ?>
          <tr class="bg-white dark:bg-gray-900 border-b dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50">
            <td class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap"><?= htmlspecialchars($registro['codigo_lote']) ?></td>
            <td class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap"><?= date('Y-m-d', strtotime($registro['fecha'])) ?></td>
            <td class="px-6 py-4"><?= htmlspecialchars($registro['tipo_control']) ?></td>
            <td class="px-6 py-4"><?= htmlspecialchars($registro['descripcion']) ?></td>
            <td class="px-6 py-4 text-center"><span class="px-3 py-1 text-xs font-medium rounded-full <?= $color_class ?>"><?= $texto_resultado ?></span></td>
            <td class="px-6 py-4 text-center"><button class="text-primary/80 hover:text-primary"><span class="material-symbols-outlined">visibility</span></button></td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="6" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">No hay registros de salud disponibles.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </section>

</div>

</main>

<script src="../../sidebar.js"></script>

</body>
</html>
