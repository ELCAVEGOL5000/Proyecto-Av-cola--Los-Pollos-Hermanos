<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluir configuración de la base de datos
include '../../Sesion/config.php';

// 1️⃣ Lotes activos
$sql_lotes = "SELECT id, codigo_lote, tipo, cantidad, estado FROM lotes";
$result_lotes = $conn->query($sql_lotes);

// Consumo de alimento hoy
$sql_hoy = "SELECT SUM(cantidad_kg) AS consumo_hoy FROM alimentacion WHERE DATE(fecha) = CURDATE()";
$result_hoy = $conn->query($sql_hoy);
$alimentacion_hoy = $result_hoy->fetch_assoc();

// Consumo diario últimos 7 días por lote
$sql_7dias_lotes = "
    SELECT a.lote_id, l.codigo_lote, DATE(a.fecha) as dia, SUM(a.cantidad_kg) as consumo
    FROM alimentacion a
    JOIN lotes l ON a.lote_id = l.id
    WHERE a.fecha >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY a.lote_id, DATE(a.fecha)
    ORDER BY a.lote_id, DATE(a.fecha)
";
$result_7dias_lotes = $conn->query($sql_7dias_lotes);

$fechas = [];
$lotes = [];
$consumos_por_lote = [];

while($row = $result_7dias_lotes->fetch_assoc()) {
    $fechas[$row['dia']] = $row['dia']; // Guardar fechas únicas
    $lotes[$row['lote_id']] = $row['codigo_lote']; // Guardar lotes
    $consumos_por_lote[$row['lote_id']][$row['dia']] = (float)$row['consumo'];
}

// Ordenar fechas
$fechas = array_values($fechas);

// Crear datasets para Chart.js
$datasets = [];
$colores = ['#F5E3B3','#F28C28','#FF6384','#36A2EB','#4BC0C0','#9966FF'];
$index = 0;

foreach($lotes as $lote_id => $lote_nombre){
    $data = [];
    foreach($fechas as $fecha){
        $data[] = $consumos_por_lote[$lote_id][$fecha] ?? 0;
    }
    $datasets[] = [
        'label' => $lote_nombre,
        'data' => $data,
        'backgroundColor' => 'rgba(0,0,0,0)', // No relleno para líneas
        'borderColor' => $colores[$index % count($colores)],
        'fill' => false,
        'tension' => 0.3,
        'pointBackgroundColor' => $colores[$index % count($colores)]
    ];
    $index++;
}

// Últimos 10 registros de alimentación
$sql_ultimos = "
    SELECT a.fecha, l.codigo_lote, a.tipo_alimento, a.cantidad_kg
    FROM alimentacion a
    JOIN lotes l ON a.lote_id = l.id
    ORDER BY a.fecha DESC
    LIMIT 10
";
$result_ultimos = $conn->query($sql_ultimos);

// Consumo por lote
$sql_c_lotes = "
    SELECT l.codigo_lote, l.tipo, SUM(a.cantidad_kg) AS consumo_lote
    FROM alimentacion a
    JOIN lotes l ON a.lote_id = l.id
    GROUP BY l.id, l.codigo_lote, l.tipo
    ORDER BY l.codigo_lote ASC
";
$result_c_lotes = $conn->query($sql_c_lotes);

// Resumen de Producción
$sql_produccion = "SELECT SUM(cantidad) as produccion_total FROM produccion";
$result_produccion = $conn->query($sql_produccion);
$produccion = $result_produccion->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>



    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": {
              light: "#E6F7E1",
              DEFAULT: "#f5e3b3",
              dark: "#388E3C"
            },
            "background-light": "#F7F9F7",
            "background-dark": "#121212",
            "surface-light": "#FFFFFF",
            "surface-dark": "#1E1E1E",
            "text-light": "#1E1E1E",
            "text-dark": "#E0E0E0",
            "text-muted-light": "#616161",
            "text-muted-dark": "#BDBDBD"
          },
          fontFamily: {
            "display": ["Inter", "sans-serif"],
            "body": ["Noto Sans", "sans-serif"]
          },
          borderRadius: {"DEFAULT": "0.5rem", "lg": "0.75rem", "xl": "1rem", "full": "9999px"},
        },
      },
    }
  </script>
</head>
<body>
    
<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="dashboard.php"><span class="material-symbols-outlined">home</span> Panel de Control</a></li>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../alimentacion/alimentacion.php"><span class="material-symbols-outlined">restaurant</span> Alimentación</a></li>
      <li><a href="../salud/salud.php"><span class="material-symbols-outlined">favorite</span> Salud</a></li>
      <li><a href="../produccion/produccion.php"><span class="material-symbols-outlined">egg</span> Producción</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<main class="flex-1 px-6 md:px-10 py-8">
<div class="max-w-screen-xl mx-auto">
<div class="mb-8">

<!-- Lotes -->
<h1 class="text-3xl font-bold font-display tracking-tight">Panel de Control</h1>
<p class="text-text-muted-light dark:text-text-muted-dark mt-1">Visión general de las métricas clave de su productora avícola.</p>
</div>
<div class="grid grid-cols-1 @container lg:grid-cols-4 gap-6">
<div class="lg:col-span-2 bg-surface-light dark:bg-surface-dark p-6 rounded-lg shadow-sm">
    <h2 class="text-xl font-bold font-display mb-4 flex items-center gap-2"><span class="material-symbols-outlined text-primary">egg</span>Lotes Activos</h2>
    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="border-b border-black/10 dark:border-white/10 text-text-muted-light dark:text-text-muted-dark">
                <tr>
                    <th class="py-3 px-4 font-semibold">Lote ID</th>
                    <th class="py-3 px-4 font-semibold">Tipo</th>
                    <th class="py-3 px-4 font-semibold">Estado</th>
                    <th class="py-3 px-4 font-semibold text-right">Cantidad</th>
                </tr>
            </thead>
            <tbody>
<?php if ($result_lotes && $result_lotes->num_rows > 0): ?>
    <?php while($lote = $result_lotes->fetch_assoc()): ?>
    <tr class="border-b border-black/10 dark:border-white/10 hover:bg-background-light dark:hover:bg-background-dark">
        <td class="py-3 px-4 font-medium"><?= htmlspecialchars($lote['codigo_lote']) ?></td>
        <td class="py-3 px-4 text-text-muted-light dark:text-text-muted-dark"><?= htmlspecialchars($lote['tipo']) ?></td>
        <td class="py-3 px-4">
            <?php if ($lote['estado'] === 'activo'): ?>
                <span class="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 font-medium px-2.5 py-0.5 rounded-full text-xs">Activo</span>
            <?php else: ?>
                <span class="bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300 font-medium px-2.5 py-0.5 rounded-full text-xs">Inactivo</span>
            <?php endif; ?>
        </td>
        <td class="py-3 px-4 text-right font-medium"><?= number_format($lote['cantidad']) ?></td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
<tr>
    <td class="py-3 px-4 text-center" colspan="4">No hay lotes activos</td>
</tr>
<?php endif; ?>
</tbody>
        </table>
    </div>
</div>

<!-- 🟡 Alertas de Salud Dinámicas -->
<div class="lg:col-span-2 bg-surface-light dark:bg-surface-dark p-6 rounded-lg shadow-sm">
  <h2 class="text-xl font-bold font-display mb-4 flex items-center gap-2">
    <span class="material-symbols-outlined text-yellow-500">warning</span>
    Alertas de Salud
  </h2>

  <div class="space-y-4">
  <?php
  $alertas = [];

  // 🔸 1. Detectar bajo consumo (comparar últimos 3 días vs promedio anterior)
  $sql_consumo = "
      SELECT l.id, l.codigo_lote,
             AVG(CASE WHEN a.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 DAY) THEN a.cantidad_kg END) AS prom_3dias,
             AVG(CASE WHEN a.fecha < DATE_SUB(CURDATE(), INTERVAL 3 DAY) 
                      AND a.fecha >= DATE_SUB(CURDATE(), INTERVAL 10 DAY) THEN a.cantidad_kg END) AS prom_semana
      FROM alimentacion a
      JOIN lotes l ON a.lote_id = l.id
      WHERE a.fecha >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)
      GROUP BY l.id, l.codigo_lote
  ";
  $res_consumo = $conn->query($sql_consumo);

  if ($res_consumo && $res_consumo->num_rows > 0) {
      while ($row = $res_consumo->fetch_assoc()) {
          $prom_3 = (float)$row['prom_3dias'];
          $prom_sem = (float)$row['prom_semana'];
          if ($prom_sem > 0 && $prom_3 < $prom_sem * 0.8) {
              $porc = round((1 - ($prom_3 / $prom_sem)) * 100, 1);
              $alertas[] = [
                  'tipo' => 'consumo_bajo',
                  'icono' => 'science',
                  'color' => 'yellow',
                  'titulo' => 'Bajo consumo de alimento',
                  'mensaje' => "{$row['codigo_lote']} muestra una reducción del {$porc}% en el consumo."
              ];
          }
      }
  }

  // 🔸 2. Lotes con alertas de salud (últimos 3 días)
  $sql_salud = "
      SELECT DISTINCT l.codigo_lote
      FROM salud s
      JOIN lotes l ON s.lote_id = l.id
      WHERE s.resultado = 'enfermo'
      AND s.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)
  ";
  $res_salud = $conn->query($sql_salud);
  if ($res_salud && $res_salud->num_rows > 0) {
      while ($s = $res_salud->fetch_assoc()) {
          $alertas[] = [
              'tipo' => 'mortalidad',
              'icono' => 'skull',
              'color' => 'red',
              'titulo' => 'Aumento de Mortalidad',
              'mensaje' => "{$s['codigo_lote']} presenta problemas de salud recientes."
          ];
      }
  }

  // 🔸 Mostrar alertas
  if (count($alertas) > 0):
      foreach ($alertas as $a): 
  ?>
      <div class="flex items-start gap-4 p-4 rounded-lg bg-background-light dark:bg-background-dark border border-<?= $a['color'] ?>-200 dark:border-<?= $a['color'] ?>-900/50">
        <div class="flex-shrink-0 size-10 flex items-center justify-center rounded-full bg-<?= $a['color'] ?>-100 dark:bg-<?= $a['color'] ?>-900/30 text-<?= $a['color'] ?>-600 dark:text-<?= $a['color'] ?>-400">
          <span class="material-symbols-outlined text-xl"><?= $a['icono'] ?></span>
        </div>
        <div>
          <p class="font-semibold text-text-light dark:text-text-dark"><?= htmlspecialchars($a['titulo']) ?></p>
          <p class="text-sm text-text-muted-light dark:text-text-muted-dark"><?= htmlspecialchars($a['mensaje']) ?></p>
        </div>
        <button onclick="window.location.href='../salud/salud.php'" class="ml-auto p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/5 self-center">
          <span class="material-symbols-outlined text-sm">arrow_forward</span>
        </button>
      </div>
  <?php 
      endforeach;
  else: 
  ?>
      <p class="text-sm text-text-muted-light dark:text-text-muted-dark">No hay alertas activas en este momento.</p>
  <?php endif; ?>
  </div>
</div>


<!-- resumen de alimentacion -->

<div class="lg:col-span-2 bg-surface-light dark:bg-surface-dark p-6 rounded-lg shadow-sm">
<h2 class="text-xl font-bold font-display mb-4 flex items-center gap-2">
  <span class="material-symbols-outlined text-primary">feed</span>Resumen de Alimentación
</h2>

<div class="grid grid-cols-1 @[20rem]:grid-cols-2 gap-4 text-center">
  <div class="bg-background-light dark:bg-background-dark p-4 rounded-lg">
    <p class="text-sm text-text-muted-light dark:text-text-muted-dark">Consumo Hoy</p>
    <p class="text-2xl font-bold font-display mt-1 text-primary-dark dark:text-primary-light">
      <?= number_format($alimentacion_hoy['consumo_hoy'] ?? 0) ?> kg
    </p>
  </div>
</div>

<div class="mt-6">
  <canvas id="consumoChart" height="150"></canvas>
</div>
</div>


<!-- Resumen de produccion -->

<div class="lg:col-span-2 bg-surface-light dark:bg-surface-dark p-6 rounded-lg shadow-sm">
  <h2 class="text-xl font-bold font-display mb-4 flex items-center gap-2">
    <span class="material-symbols-outlined text-primary">monitoring</span>Resumen de Producción
  </h2>

  <?php
  // Huevos producidos hoy
  $sql_huevos_hoy = "
      SELECT SUM(cantidad) AS huevos_hoy
      FROM produccion
      WHERE DATE(fecha) = CURDATE() AND tipo = 'huevos'
  ";
  $result_huevos_hoy = $conn->query($sql_huevos_hoy);
  $hoy = $result_huevos_hoy->fetch_assoc();

  // Total aves activas (para % puesta)
  $sql_total_aves = "SELECT SUM(cantidad) AS total_aves FROM lotes WHERE estado = 'activo'";
  $result_total_aves = $conn->query($sql_total_aves);
  $total_aves = $result_total_aves->fetch_assoc();

  // Porcentaje de puesta
  $porcentaje_puesta = 0;
  if (!empty($total_aves['total_aves']) && $total_aves['total_aves'] > 0) {
      $porcentaje_puesta = ($hoy['huevos_hoy'] / $total_aves['total_aves']) * 100;
  }

  // Producción por lote hoy
  $sql_produccion_lotes = "
      SELECT l.codigo_lote, SUM(p.cantidad) AS cantidad
      FROM produccion p
      JOIN lotes l ON p.lote_id = l.id
      WHERE DATE(p.fecha) = CURDATE() AND p.tipo = 'huevos'
      GROUP BY l.codigo_lote
      ORDER BY l.codigo_lote ASC
  ";
  $result_produccion_lotes = $conn->query($sql_produccion_lotes);
  ?>

  <div class="grid grid-cols-1 @[20rem]:grid-cols-2 gap-4 text-center">
    <div class="bg-background-light dark:bg-background-dark p-4 rounded-lg">
      <p class="text-sm text-text-muted-light dark:text-text-muted-dark">Huevos Hoy</p>
      <p class="text-2xl font-bold font-display mt-1 text-primary-dark dark:text-primary-light">
        <?= number_format($hoy['huevos_hoy'] ?? 0) ?>
      </p>
    </div>

    <div class="bg-background-light dark:bg-background-dark p-4 rounded-lg">
      <p class="text-sm text-text-muted-light dark:text-text-muted-dark">% Puesta</p>
      <p class="text-2xl font-bold font-display mt-1">
        <?= number_format($porcentaje_puesta, 1) ?>%
      </p>
    </div>
  </div>

  <div class="mt-6">
    <div class="flex justify-between items-baseline mb-2">
      <h3 class="font-semibold font-display">Producción por Lote (Huevos/Día)</h3>
    </div>

    <div class="h-48 w-full flex items-end gap-2 sm:gap-4 px-2">
      <?php if ($result_produccion_lotes && $result_produccion_lotes->num_rows > 0): ?>
        <?php 
        // Calcular el máximo para escalar alturas
        $max_cant = 0;
        foreach($result_produccion_lotes as $r){ if($r['cantidad'] > $max_cant) $max_cant = $r['cantidad']; }
        $result_produccion_lotes->data_seek(0); // reiniciar puntero

        while($row = $result_produccion_lotes->fetch_assoc()):
          $altura = $max_cant > 0 ? ($row['cantidad'] / $max_cant) * 100 : 0;
        ?>
        <div class="flex-1 flex flex-col items-center gap-2 group">
          <div class="w-full bg-primary-light dark:bg-primary-dark/30 rounded-t-md group-hover:bg-primary-light dark:group-hover:bg-primary-dark/60 transition-colors relative" style="height: <?= $altura ?>%;">
            <div class="absolute -top-7 left-1/2 -translate-x-1/2 bg-surface-dark text-text-dark px-2 py-1 rounded-md text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              <?= number_format($row['cantidad']) ?>
            </div>
          </div>
          <p class="text-xs font-medium text-text-muted-light dark:text-text-muted-dark"><?= htmlspecialchars($row['codigo_lote']) ?></p>
        </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p class="text-sm text-text-muted-light dark:text-text-muted-dark">Sin registros de producción hoy.</p>
      <?php endif; ?>
    </div>
  </div>
</div>

</div>
</div>
</div>
</main>

<script src="../../sidebar.js"></script>

<script>
const ctx = document.getElementById('consumoChart').getContext('2d');
const consumoChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode($fechas) ?>,
        datasets: <?= json_encode($datasets) ?>
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: true }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Consumo (kg)' }
            },
            x: {
                title: { display: true, text: 'Fecha' }
            }
        }
    }
});
</script>


</body>
</html>