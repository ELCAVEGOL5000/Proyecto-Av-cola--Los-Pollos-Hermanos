<?php
include '../../Sesion/config.php';

// Insertar nuevo registro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lote_id = $_POST['lote'];
    $fecha = $_POST['fecha'];
    $tipo = $_POST['tipo_produccion'];
    $cantidad = $_POST['cantidad'];

    $stmt = $conn->prepare("INSERT INTO produccion (lote_id, fecha, tipo, cantidad) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issi", $lote_id, $fecha, $tipo, $cantidad);
    $stmt->execute();
    $stmt->close();
}

// Obtener lotes para dropdown
$lotes = $conn->query("SELECT id, codigo_lote FROM lotes WHERE estado='activo'");

// Filtrar por tipo y rango de fecha
$fechaInicio = $_GET['fecha_inicio'] ?? '';
$fechaFin = $_GET['fecha_fin'] ?? '';

$where = "1=1";
if ($fechaInicio) {
    $where .= " AND fecha >= '" . $conn->real_escape_string($fechaInicio) . "'";
}
if ($fechaFin) {
    $where .= " AND fecha <= '" . $conn->real_escape_string($fechaFin) . "'";
}

// Total producción
$resultTotal = $conn->query("SELECT SUM(cantidad) AS total FROM produccion WHERE $where");
$totalProduccion = $resultTotal->fetch_assoc()['total'] ?? 0;

// Producción por lote
$query = "
    SELECT l.codigo_lote AS lote, SUM(p.cantidad) AS total
    FROM produccion p
    JOIN lotes l ON p.lote_id = l.id
    WHERE $where
    GROUP BY l.codigo_lote
    ORDER BY l.codigo_lote
";
$result = $conn->query($query);

$lotesData = [];
$cantidadesData = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $lotesData[] = $row['lote'];
        $cantidadesData[] = (int)$row['total'];
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Producción</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link rel="stylesheet" href="produccion.css">
    <link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter%3Awght%40400%3B500%3B700%3B900&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900" onload="this.rel='stylesheet'" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: { "primary": "#f5e3b3", "background-light": "#505050", "background-dark": "#152111" },
                    fontFamily: { "display": ["Inter"] },
                    borderRadius: { "DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px" },
                },
            },
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
</head>
<body>
<header>
    <div class="logo-header">
        <div class="icon"></div>
        Sky Line <span class="corp">Corp</span>
    </div>
    <nav>
        <ul>
            <li><a href="../contacto/servicios.php">Servicios</a></li>
            <li><a href="../contacto/nosotros.php">Nosotros</a></li>
            <li><a href="../contacto/contacto.php">Contacto</a></li>
        </ul>
    </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
    <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
    <div>
        <div class="logo">
            <div class="icon"></div>
            <div class="textos">
                <span class="main-text">Sky Line <span class="corp">Corp</span></span>
            </div>
        </div>
        <ul>
            <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">home</span> Panel de Control</a></li>
            <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
            <li><a href="../alimentacion/alimentacion.php"><span class="material-symbols-outlined">restaurant</span> Alimentación</a></li>
            <li><a href="../salud/salud.php"><span class="material-symbols-outlined">favorite</span> Salud</a></li>
            <li class="active"><a href="produccion.php"><span class="material-symbols-outlined">egg</span> Producción</a></li>
        </ul>
    </div>
    <div class="footer">
        <ul>
            <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
        </ul>
    </div>
</div>

<main class="flex-grow">
<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 md:py-12">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 xl:gap-12">
        <div class="lg:col-span-2">
            <div class="mb-8">
                <h1 class="text-4xl font-bold tracking-tight text-neutral-900 dark:text-white">Seguimiento de la Producción</h1>
            </div>

            <!-- Formulario de registro -->
            <div class="bg-white dark:bg-neutral-900/50 p-6 md:p-8 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-800">
                <h3 class="text-xl font-bold text-neutral-900 dark:text-white mb-6">Añadir Nuevo Registro</h3>
                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="lote" class="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">Lote</label>
                        <select name="lote" id="lote" required class="form-select w-full rounded-lg border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:ring-primary focus:border-primary dark:text-white dark:placeholder-neutral-500">
                            <option value="">Seleccionar lote</option>
                            <?php
                            if ($lotes && $lotes->num_rows > 0) {
                                while ($fila = $lotes->fetch_assoc()) {
                                    echo '<option value="' . $fila['id'] . '">' . htmlspecialchars($fila['codigo_lote']) . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="fecha" class="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">Fecha</label>
                        <input type="date" name="fecha" id="fecha" required class="form-input w-full rounded-lg border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:ring-primary focus:border-primary dark:text-white dark:placeholder-neutral-500" />
                    </div>
                    <div>
                        <label for="tipo_produccion" class="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">Tipo de Producción</label>
                        <select name="tipo_produccion" id="tipo_produccion" required class="form-select w-full rounded-lg border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:ring-primary focus:border-primary dark:text-white dark:placeholder-neutral-500">
                            <option value="">Seleccionar tipo</option>
                            <option value="huevos">Huevos</option>
                            <option value="pollos">Pollos</option>
                        </select>
                    </div>
                    <div>
                        <label for="cantidad" class="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">Cantidad</label>
                        <input type="number" name="cantidad" id="cantidad" placeholder="Ingresar cantidad" required class="form-input w-full rounded-lg border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:ring-primary focus:border-primary dark:text-white dark:placeholder-neutral-500" />
                    </div>
                    <div class="md:col-span-2">
                        <button type="submit" class="w-full md:w-auto inline-flex items-center justify-center rounded-lg bg-primary px-6 py-3 text-sm font-bold text-black hover:bg-primary/80 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:focus:ring-offset-background-dark">
                            Guardar Registro
                        </button>
                    </div>
                </form>
            </div>

            <!-- Gráfico de producción -->
            <div class="mt-12 bg-white dark:bg-neutral-900/50 p-6 md:p-8 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-800">
                <h3 class="text-xl font-bold text-neutral-900 dark:text-white mb-6">Producción por Lote</h3>
                <div class="h-80 w-full">
                    <canvas id="produccionChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Filtro -->
        <div class="lg:col-span-1 max-w-sm mx-auto">
            <div class="sticky top-24">
                <form method="GET" action="" class="bg-white dark:bg-neutral-900/50 p-6 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-800 space-y-6">
                    <h3 class="text-xl font-bold text-neutral-900 dark:text-white mb-6">Resumen y Filtros</h3>

                    <div>
                        <p class="text-sm font-medium text-neutral-600 dark:text-neutral-400">Producción Total</p>
                        <p class="text-4xl font-bold text-neutral-900 dark:text-white mt-1">
                            <?php echo number_format($totalProduccion); ?>
                        </p>
                    </div>

                    <div>
                        <label for="fecha_inicio" class="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">Rango de Fechas</label>
                        <div class="grid grid-cols-2 gap-4">
                            <input type="date" name="fecha_inicio" id="fecha_inicio" value="<?php echo htmlspecialchars($fechaInicio); ?>" class="form-input w-full rounded-lg border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:ring-primary focus:border-primary dark:text-white" />
                            <input type="date" name="fecha_fin" id="fecha_fin" value="<?php echo htmlspecialchars($fechaFin); ?>" class="form-input w-full rounded-lg border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 focus:ring-primary focus:border-primary dark:text-white" />
                        </div>
                    </div>

                    <div>
                        <button type="submit" class="w-full inline-flex items-center justify-center rounded-lg bg-primary px-6 py-3 text-sm font-bold text-black hover:bg-primary/80 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:focus:ring-offset-background-dark">
                            Aplicar Filtro
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</main>


<script src="../../sidebar.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const lotes = <?php echo json_encode($lotesData); ?> || [];
const cantidades = <?php echo json_encode($cantidadesData); ?> || [];

const ctx = document.getElementById('produccionChart').getContext('2d');

if(lotes.length === 0){
    ctx.font = "16px Arial";
    ctx.fillText("No hay datos para mostrar", 50, 50);
} else {
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: lotes,
            datasets: [{
                label: 'Producción total',
                data: cantidades,
                backgroundColor: 'rgba(76, 223, 32, 0.5)',
                borderColor: '#4cdf20',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, title: { display: true, text: 'Cantidad' } },
                x: { title: { display: true, text: 'Lotes' } }
            },
            plugins: {
                legend: { display: false },
                title: { display: true, text: 'Producción por Lote (últimos registros)' }
            }
        }
    });
}

</script>

</body>
</html>
