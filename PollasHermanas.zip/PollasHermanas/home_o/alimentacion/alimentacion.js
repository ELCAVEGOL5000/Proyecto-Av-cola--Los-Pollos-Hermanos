const toggleBtn = document.getElementById('menu-toggle');
const sidebar = document.getElementById('sidebar');
const header = document.querySelector('header');

toggleBtn.addEventListener('click', () => {
  sidebar.classList.toggle('active');
  header.classList.toggle('shifted');
});

document.addEventListener('click', (event) => {
  if (sidebar.classList.contains('active')) {
    if (!sidebar.contains(event.target) && !toggleBtn.contains(event.target)) {
      sidebar.classList.remove('active');
      header.classList.remove('shifted');
    }
  }
});


const btnAgregar = document.getElementById('btnAgregar');
  const btnCancelar = document.getElementById('btnCancelar');
  const contenido = document.getElementById('main-content');
  const formulario = document.getElementById('formulario-agregar');
  const titulo = document.querySelector('#main-content > h1');

  btnAgregar.addEventListener('click', () => {
    contenido.style.display = 'none';
    titulo.style.display = 'none';
    btnAgregar.style.display = 'none';
    formulario.style.display = 'block';
  });

  btnCancelar.addEventListener('click', () => {
    contenido.style.display = 'block';
    titulo.style.display = 'block';
    btnAgregar.style.display = 'inline-block';
    formulario.style.display = 'none';
  });