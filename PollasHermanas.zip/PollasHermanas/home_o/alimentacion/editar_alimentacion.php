<?php
session_start();
require_once '../../Sesion/config.php';

if (!isset($_SESSION['usuario_id'])) {
  header('Location: ../../Sesion/inicioSesion.php');
  exit();
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = "";
$error = "";

if (!isset($_GET['id'])) {
    die("No se especificó el registro a editar.");
}

$id = intval($_GET['id']);

// Procesar formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_registro'])) {
    $fecha = $_POST['fecha'];
    $tipo_alimento = $_POST['tipo_alimento'];
    $cantidad_kg = $_POST['cantidad_kg'];
    $codigo_lote = $_POST['codigo_lote'];

    // Validar datos básicos
    if (!$fecha || !$tipo_alimento || !$cantidad_kg || !$codigo_lote) {
        $error = "Todos los campos son obligatorios.";
    } else {
        // Buscar id del lote para el código_lote
        $stmt = $conn->prepare("SELECT id FROM lotes WHERE codigo_lote = ?");
        $stmt->bind_param("s", $codigo_lote);
        $stmt->execute();
        $resultLote = $stmt->get_result();

        if ($resultLote->num_rows > 0) {
            $lote = $resultLote->fetch_assoc();
            $lote_id = $lote['id'];

            // Actualizar registro
            $stmt2 = $conn->prepare("UPDATE alimentacion SET fecha = ?, tipo_alimento = ?, cantidad_kg = ?, lote_id = ? WHERE id = ?");
            $stmt2->bind_param("ssdii", $fecha, $tipo_alimento, $cantidad_kg, $lote_id, $id);

            if ($stmt2->execute()) {
                // Redirigir a la página principal después de guardar
                header("Location: alimentacion.php?mensaje=Alimentacion actualizada correctamente");
                exit();
            } else {
                $error = "Error al actualizar el registro.";
            }
        } else {
            $error = "Código de lote no encontrado.";
        }
    }
} // ← cierre del if de POST

// Obtener datos actuales para mostrar en el formulario
$stmt = $conn->prepare("
    SELECT a.fecha, a.tipo_alimento, a.cantidad_kg, l.codigo_lote 
    FROM alimentacion a
    JOIN lotes l ON a.lote_id = l.id
    WHERE a.id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Registro no encontrado.");
}

$registro = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Editar Registro de Alimentación</title>
<link rel="stylesheet" href="alimentacion.css" />
<link rel="stylesheet" href="tu_css_sidebar_y_general.css" />
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="#">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<!-- Sidebar aquí si tienes -->

<div id="main-content">
  <h1>Editar Registro de Alimentación</h1>

  <?php if ($error): ?>
    <p style="color: red; font-weight: bold; margin-left: 20px;"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>

  <form method="POST" class="formulario-agregar" style="display: block; max-width: 500px; margin: 20px auto;">

    <input type="hidden" name="editar_registro" value="1" />

    <div class="form-group">
      <label for="codigo_lote">Código Lote:</label>
      <input type="text" id="codigo_lote" name="codigo_lote" value="<?= htmlspecialchars($registro['codigo_lote']) ?>" required />
    </div>

    <div class="form-group">
      <label for="tipo_alimento">Tipo de alimento</label>
      <input list="tipos_alimento" id="tipo_alimento" name="tipo_alimento" value="<?= htmlspecialchars($registro['tipo_alimento']) ?>" required />
      <datalist id="tipos_alimento">
        <option value="Semillas">
        <option value="Trigo">
        <option value="Pienso">
        <option value="Maíz">
        <option value="Cebada">
        <option value="Cereal">
      </datalist>
    </div>

    <div class="form-group">
      <label for="cantidad_kg">Cantidad (kg):</label>
      <input type="number" step="0.01" id="cantidad_kg" name="cantidad_kg" value="<?= htmlspecialchars($registro['cantidad_kg']) ?>" required />
    </div>

    <div class="form-group">
      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" value="<?= htmlspecialchars($registro['fecha']) ?>" required />
    </div>

    <div class="form-buttons">
      <button type="submit" class="btn guardar">Guardar Cambios</button>
      <a href="alimentacion.php" class="btn cancelar" style="text-align:center; line-height: 32px; text-decoration:none;">Cancelar</a>
    </div>
  </form>
</div>

</body>
</html>