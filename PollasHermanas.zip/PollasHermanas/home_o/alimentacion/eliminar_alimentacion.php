<?php
session_start();
require_once '../../Sesion/config.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../../inicioSesion.php');
    exit();
  }

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar si se recibió el ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No se especificó el registro a eliminar.");
}

$id = intval($_GET['id']);

// Preparar y ejecutar eliminación
$stmt = $conn->prepare("DELETE FROM alimentacion WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    // Redirigir de nuevo a la página principal con mensaje de éxito
    header("Location: alimentacion.php?mensaje=Registro eliminado correctamente");
    exit;
} else {
    echo "Error al eliminar el registro: " . $conn->error;
}

$stmt->close();
$conn->close();
?>