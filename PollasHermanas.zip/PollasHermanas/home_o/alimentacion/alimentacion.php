<?php
session_start();
require_once '../../Sesion/config.php';

if (!isset($_SESSION['usuario_id'])) {
  header('Location: ../../Sesion/inicioSesion.php');
  exit();
}


$message = "";

// Procesar formulario si se envió
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_registro'])) {
    $fecha = $_POST['fecha'];
    $tipo_alimento = $_POST['Comida'];
    $cantidad_kg = $_POST['cantidad_kg'];
    $codigo_lote = $_POST['codigo_lote'];

    // Buscar id del lote
    $stmt = $conn->prepare("SELECT id FROM lotes WHERE codigo_lote = ?");
    $stmt->bind_param("s", $codigo_lote);
    $stmt->execute();
    $resultLote = $stmt->get_result();

    if ($resultLote->num_rows > 0) {
        $lote = $resultLote->fetch_assoc();
        $lote_id = $lote['id'];

        // Insertar en alimentacion
        $stmt2 = $conn->prepare("INSERT INTO alimentacion (fecha, tipo_alimento, cantidad_kg, lote_id) VALUES (?, ?, ?, ?)");
        $stmt2->bind_param("ssdi", $fecha, $tipo_alimento, $cantidad_kg, $lote_id);
        if ($stmt2->execute()) {
            $message = "Registro agregado correctamente.";
        } else {
            $message = "Error al guardar el registro.";
        }
    } else {
        $message = "Código de lote no encontrado.";
    }
}

// Consulta para obtener historial de alimentación con datos del lote
$sql = "
    SELECT 
        a.id,
        a.fecha,
        a.tipo_alimento,
        a.cantidad_kg,
        l.codigo_lote
    FROM alimentacion a
    JOIN lotes l ON a.lote_id = l.id
    ORDER BY a.fecha DESC
";

$result = $conn->query($sql);

// Consulta para obtener lotes activos (o todos)
$sql_lotes = "SELECT codigo_lote FROM lotes WHERE estado='activo' ORDER BY codigo_lote";
$resultado_lotes = $conn->query($sql_lotes);



?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Alimentación</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
<link rel="stylesheet" href="alimentacion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">home</span> Panel de Control</a></li>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li class="active"><a href="alimentacion.php"><span class="material-symbols-outlined">restaurant</span> Alimentación</a></li>
      <li><a href="../salud/salud.php"><span class="material-symbols-outlined">favorite</span> Salud</a></li>
      <li><a href="../produccion/produccion.php"><span class="material-symbols-outlined">egg</span> Producción</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<div id="main-content">
  <h1>Historial de Alimentación</h1>


  <?php if (isset($_GET['mensaje'])): ?>
  <p style="color: green; font-weight: bold; margin-left: 20px;">
    <?= htmlspecialchars($_GET['mensaje']) ?>
  </p>
  <?php endif; ?>

  <?php if($message): ?>
    <p style="color: green; font-weight: bold; margin-left: 20px;"><?= htmlspecialchars($message) ?></p>
  <?php endif; ?>

  <div class="boton-container">
    <button id="btnAgregar">Agregar Registro</button>
  </div>

  <table>
    <thead>
      <tr>
        <th>Fecha</th>
        <th>Tipo de alimento</th>
        <th>Cantidad (kg)</th>
        <th>Código de lote</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['fecha']) ?></td>
            <td><?= htmlspecialchars($row['tipo_alimento']) ?></td>
            <td><?= htmlspecialchars($row['cantidad_kg']) ?></td>
            <td><?= htmlspecialchars($row['codigo_lote']) ?></td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="4" style="text-align:center;">No hay registros</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

 <!-- Formulario oculto inicialmente -->
 <div id="formulario-agregar" class="formulario-agregar">
  <h2>Agregar Nuevo Registro</h2>
  <form id="formAgregarRegistro" method="POST" action="">
    <input type="hidden" name="agregar_registro" value="1" />

    <div class="form-group">
      <label for="codigo_lote">Código Lote:</label>
      <select id="codigo_lote" name="codigo_lote" required>
        <option value="" disabled selected>Seleccione un lote</option>
        <?php if ($resultado_lotes): ?>
          <?php while ($lote = $resultado_lotes->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($lote['codigo_lote']) ?>">
              <?= htmlspecialchars($lote['codigo_lote']) ?>
            </option>
            <?php endwhile; ?>
            <?php endif; ?>
          </select>
    </div>


    <div class="form-group">
      <label for="Comida">Comida</label>
      <input list="Opciones" id="Comida" name="Comida" required/>
      <datalist id="Opciones">
        <option value="Semillas">
        <option value="trigo ">
        <option value="Pienso">
        <option value="Maíz">
        <option value="Cebada">
        <option value="Cereal">
    </div>

    <div class="form-group">
      <label for="cantidad_kg">Cantidad (kg):</label>
      <input type="number" step="0.01" id="cantidad_kg" name="cantidad_kg" required />
    </div>

    <div class="form-group">
      <label for="fecha">Fecha:</label>
      <input type="date" id="fecha" name="fecha" required />
    </div>

    <div class="form-buttons">
      <button type="submit" class="btn guardar">Guardar</button>
      <button type="button" id="btnCancelar" class="btn cancelar">Cancelar</button>
    </div>
  </form>
</div>



<script src="../../sidebar.js"></script>

</body>
</html>
