<?php
session_start();
session_unset();
session_destroy();
header("Location: Sesion/inicioSesion.php");
exit();
?>