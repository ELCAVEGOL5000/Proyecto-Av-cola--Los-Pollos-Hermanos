
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Lotes de Aves</title>
  <link rel="stylesheet" href="servicios.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>
<body>

  <header>
  <div class="logo">
      <div class="icon" id="icon"></div>
      Sky Line
      <span class="corp">Corp</span>
    </div>
    <nav>
      <ul>
          <li><a href="servicios.php">Servicios</a></li>
          <li><a href="nosotros.php">Nosotros</a></li>
          <li><a href="contacto.php">Contacto</a></li>
      </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../galpones/galpones.php"><span class="material-symbols-outlined">gite</span> Galpones</a></li>
      <li><a href="../reportes/reportes.php"><span class="material-symbols-outlined">assessment</span><span>Reportes</span></a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

  <section id="servicios" class="servicios">
    <div class="container">
      <h1>Paneles del Sistema</h1>

      <div class="panel-card">
        <h2>🧑‍💼 Panel de Supervisores</h2>
        <p>
          Este panel permite a los supervisores tener una visión global de la producción. Está enfocado en el análisis de datos y la detección de problemas para mejorar la eficiencia.
        </p>
        <ul>
          <li>Monitoreo en tiempo real de todos los lotes y galpones.</li>
          <li>Reportes detallados de mortalidad, conversión alimenticia y producción.</li>
          <li>Alertas de anomalías como baja producción o alta mortalidad.</li>
          <li>Comparativas entre lotes para evaluar rendimiento.</li>
        </ul>
        <div class="evitar">
          <strong>⚠️ Evitar:</strong>
          <ul>
            <li>Modificar datos sin verificar con operarios o administradores.</li>
            <li>Ignorar alertas del sistema por considerarlas “menores”.</li>
            <li>Tomar decisiones sin consultar reportes históricos.</li>
          </ul>
          <div class="tips">
            <h2>🧠 Tips para Supervisores</h2>
             <ul>
            <li>📊 Revisá los reportes al menos una vez por semana para detectar tendencias.</li>
            <li>🔁 Compará lotes similares para identificar buenas prácticas.</li>
            <li>📣 Usá las alertas para coordinar acciones con operarios rápidamente.</li>
            <li>🧭 Validá los datos antes de tomar decisiones importantes.</li>
            <li>📥 Exportá reportes para compartir con gerencia o veterinarios.</li>
            </ul>
</div>

        </div>
      </div>

<script src="../../sidebar.js"></script>

</body>
</html>