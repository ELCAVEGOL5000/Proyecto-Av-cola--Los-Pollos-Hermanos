<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alertas de Anomalías</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
<script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": "#4cdf20",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "card-light": "#ffffff",
            "card-dark": "#1f2d1c",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49e",
            "border-light": "#dee5dc",
            "border-dark": "#30402b",
          },
          fontFamily: {
            "display": ["Inter", "sans-serif"]
          },
          borderRadius: {
            "DEFAULT": "0.5rem",
            "lg": "0.75rem",
            "xl": "1rem",
            "full": "9999px"
          },
        },
      },
    }
  </script>
<style>
    .material-symbols-outlined {
      font-variation-settings:
      'FILL' 1,
      'wght' 400,
      'GRAD' 0,
      'opsz' 24
    }
  </style>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
<link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">dashboard</span> Panel de Control</a></li>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../galpones/galpones.php"><span class="material-symbols-outlined">gite</span> Galpones</a></li>
      <li><a href="../reportes/reportes.php"><span class="material-symbols-outlined">assessment</span><span>Reportes</span></a></li>
      <li class="active"><a href="alertas.php"><span class="material-symbols-outlined">notifications_active</span><span>Alertas</span></a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="confi" href="configuracion.php"><span class="material-symbols-outlined">settings</span> Configuración</a></li>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>


<main class="flex-1 p-8">

<h1 class="text-3xl font-bold text-foreground-light dark:text-foreground-dark">Alertas de Anomalías</h1>

<section>
<div class="bg-card-light dark:bg-card-dark rounded-xl shadow-md border border-border-light dark:border-border-dark">
<div class="overflow-x-auto">
<table class="w-full text-left">
<thead class="border-b border-border-light dark:border-border-dark">
<tr>
<th class="py-3 px-4 font-semibold">Fecha/Hora</th>
<th class="py-3 px-4 font-semibold">Lote/Galpón</th>
<th class="py-3 px-4 font-semibold">Anomalía</th>
<th class="py-3 px-4 font-semibold text-center">Estado</th>
<th class="py-3 px-4 font-semibold text-center">Acciones</th>
</tr>
</thead>
<tbody>
<tr class="border-b border-border-light dark:border-border-dark hover:bg-background-light dark:hover:bg-background-dark">
<td class="py-3 px-4">2023-10-26 08:15</td>
<td class="py-3 px-4">Lote 23-A / Galpón 1</td>
<td class="py-3 px-4">
<p class="font-medium text-red-500">Alta mortalidad</p>
<p class="text-sm text-muted-light dark:text-muted-dark">22 aves encontradas, superando el umbral.</p>
</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                  Pendiente
                </span>
</td>
<td class="py-3 px-4 text-center">
<div class="flex justify-center items-center gap-2">
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">check_circle</span>
</button>
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">assignment</span>
</button>
</div>
</td>
</tr>
<tr class="border-b border-border-light dark:border-border-dark hover:bg-background-light dark:hover:bg-background-dark">
<td class="py-3 px-4">2023-10-25 11:30</td>
<td class="py-3 px-4">Lote 22-C / Galpón 3</td>
<td class="py-3 px-4">
<p class="font-medium text-orange-500">Consumo de alimento inusual</p>
<p class="text-sm text-muted-light dark:text-muted-dark">Disminución del 15% en el consumo esperado.</p>
</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                  Revisada
                </span>
</td>
<td class="py-3 px-4 text-center">
<div class="flex justify-center items-center gap-2">
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">check_circle</span>
</button>
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">assignment</span>
</button>
</div>
</td>
</tr>
<tr class="border-b border-border-light dark:border-border-dark hover:bg-background-light dark:hover:bg-background-dark">
<td class="py-3 px-4">2023-10-25 09:00</td>
<td class="py-3 px-4">Lote 23-B / Galpón 2</td>
<td class="py-3 px-4">
<p class="font-medium text-blue-500">Baja producción de huevos</p>
<p class="text-sm text-muted-light dark:text-muted-dark">Producción un 10% por debajo del promedio histórico.</p>
</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Resuelta
                </span>
</td>
<td class="py-3 px-4 text-center">
<div class="flex justify-center items-center gap-2">
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">check_circle</span>
</button>
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">assignment</span>
</button>
</div>
</td>
</tr>
<tr class="hover:bg-background-light dark:hover:bg-background-dark">
<td class="py-3 px-4">2023-10-24 16:45</td>
<td class="py-3 px-4">Lote 23-A / Galpón 1</td>
<td class="py-3 px-4">
<p class="font-medium text-red-500">Alta mortalidad</p>
<p class="text-sm text-muted-light dark:text-muted-dark">18 aves encontradas.</p>
</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Resuelta
                </span>
</td>
<td class="py-3 px-4 text-center">
<div class="flex justify-center items-center gap-2">
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">check_circle</span>
</button>
<button class="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
<span class="material-symbols-outlined text-base">assignment</span>
</button>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</section>
</main>

<script src="../../sidebar.js"></script>

</body>
</html>