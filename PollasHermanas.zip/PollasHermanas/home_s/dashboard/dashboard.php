<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de control</title>

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
<script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": "#4cdf20",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "card-light": "#ffffff",
            "card-dark": "#1f2d1c",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49e",
            "border-light": "#dee5dc",
            "border-dark": "#30402b",
          },
          fontFamily: {
            "display": ["Inter", "sans-serif"]
          },
          borderRadius: {
            "DEFAULT": "0.5rem",
            "lg": "0.75rem",
            "xl": "1rem",
            "full": "9999px"
          },
        },
      },
    }
  </script>
<style>
    .material-symbols-outlined {
      font-variation-settings:
      'FILL' 1,
      'wght' 400,
      'GRAD' 0,
      'opsz' 24
    }
  </style>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
<link rel="stylesheet" href="../../home_o/dashboard/dashboard.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="dashboard.php"><span class="material-symbols-outlined">dashboard</span> Panel de Control</a></li>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../galpones/galpones.php"><span class="material-symbols-outlined">gite</span> Galpones</a></li>
      <li><a href="../reportes/reportes.php"><span class="material-symbols-outlined">assessment</span><span>Reportes</span></a></li>
      <li><a href="../alertas/alertas.php"><span class="material-symbols-outlined">notifications_active</span><span>Alertas</span></a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="confi" href="configuracion.php"><span class="material-symbols-outlined">settings</span> Configuración</a></li>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>



<main class="flex-1 p-8">

<h1 class="text-3xl font-bold text-foreground-light dark:text-foreground-dark">Panel de Control de Supervisor</h1>

<section class="mb-8">
<h2 class="text-2xl font-bold mb-4 text-foreground-light dark:text-foreground-dark">Vista General de Lotes y Galpones</h2>
<div class="bg-card-light dark:bg-card-dark rounded-lg shadow-sm overflow-x-auto">
<table class="w-full text-left">
<thead class="border-b border-border-light dark:border-border-dark">
<tr>
<th class="p-4 font-semibold">Lote</th>
<th class="p-4 font-semibold">Galpón</th>
<th class="p-4 font-semibold">Estado</th>
<th class="p-4 font-semibold text-right">Edad (días)</th>
<th class="p-4 font-semibold text-right">Densidad (aves/m²)</th>
<th class="p-4 font-semibold text-right">Mortalidad (%)</th>
<th class="p-4 font-semibold text-right">Producción (huevos/día)</th>
</tr>
</thead>
<tbody>
<tr class="border-b border-border-light dark:border-border-dark">
<td class="p-4">Lote 2023-A</td>
<td class="p-4 text-muted-light dark:text-muted-dark">Galpón 1</td>
<td class="p-4"><span class="px-3 py-1 text-sm font-medium rounded-full bg-primary/20 text-primary">Activo</span></td>
<td class="p-4 text-right">35</td>
<td class="p-4 text-right">12</td>
<td class="p-4 text-right text-red-500">1.5</td>
<td class="p-4 text-right">5000</td>
</tr>
<tr class="border-b border-border-light dark:border-border-dark">
<td class="p-4">Lote 2023-B</td>
<td class="p-4 text-muted-light dark:text-muted-dark">Galpón 2</td>
<td class="p-4"><span class="px-3 py-1 text-sm font-medium rounded-full bg-primary/20 text-primary">Activo</span></td>
<td class="p-4 text-right">28</td>
<td class="p-4 text-right">11</td>
<td class="p-4 text-right">0.8</td>
<td class="p-4 text-right">4800</td>
</tr>
<tr class="border-b border-border-light dark:border-border-dark">
<td class="p-4">Lote 2023-C</td>
<td class="p-4 text-muted-light dark:text-muted-dark">Galpón 3</td>
<td class="p-4"><span class="px-3 py-1 text-sm font-medium rounded-full bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-300">Inactivo</span></td>
<td class="p-4 text-right">0</td>
<td class="p-4 text-right">0</td>
<td class="p-4 text-right">0.0</td>
<td class="p-4 text-right">0</td>
</tr>
<tr class="border-b border-border-light dark:border-border-dark">
<td class="p-4">Lote 2023-D</td>
<td class="p-4 text-muted-light dark:text-muted-dark">Galpón 1</td>
<td class="p-4"><span class="px-3 py-1 text-sm font-medium rounded-full bg-primary/20 text-primary">Activo</span></td>
<td class="p-4 text-right">14</td>
<td class="p-4 text-right">10</td>
<td class="p-4 text-right">0.5</td>
<td class="p-4 text-right">2500</td>
</tr>
<tr>
<td class="p-4">Lote 2023-E</td>
<td class="p-4 text-muted-light dark:text-muted-dark">Galpón 2</td>
<td class="p-4"><span class="px-3 py-1 text-sm font-medium rounded-full bg-primary/20 text-primary">Activo</span></td>
<td class="p-4 text-right">7</td>
<td class="p-4 text-right">9</td>
<td class="p-4 text-right">0.2</td>
<td class="p-4 text-right">1000</td>
</tr>
</tbody>
</table>
</div>
</section>
<section class="mb-8">
<h2 class="text-2xl font-bold mb-4 text-foreground-light dark:text-foreground-dark">Reportes</h2>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
<button class="w-full bg-primary text-black font-bold py-3 px-4 rounded-lg shadow-sm hover:bg-primary/90 transition-colors">
            Generar Reporte de Mortalidad
          </button>
<button class="w-full bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark text-foreground-light dark:text-foreground-dark font-bold py-3 px-4 rounded-lg shadow-sm hover:bg-primary/10 transition-colors">
            Conversión Alimenticia
          </button>
<button class="w-full bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark text-foreground-light dark:text-foreground-dark font-bold py-3 px-4 rounded-lg shadow-sm hover:bg-primary/10 transition-colors">
            Producción
          </button>
<button class="w-full bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark text-foreground-light dark:text-foreground-dark font-bold py-3 px-4 rounded-lg shadow-sm hover:bg-primary/10 transition-colors">
            Rendimiento General
          </button>
</div>
</section>
<section>
<h2 class="text-2xl font-bold mb-4 text-foreground-light dark:text-foreground-dark">Alertas de Anomalías</h2>
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
<div class="bg-red-500/10 dark:bg-red-900/20 border border-red-500/20 dark:border-red-500/30 rounded-lg p-6 flex gap-6 items-start">
<div class="text-red-500 mt-1">
<span class="material-symbols-outlined text-4xl">warning</span>
</div>
<div>
<h3 class="font-bold text-lg text-red-800 dark:text-red-300">Alta Mortalidad en Lote 2023-A</h3>
<p class="text-red-700 dark:text-red-400 mt-1">La mortalidad ha superado el 2% en la última semana. Se sugiere investigar posibles enfermedades o problemas de manejo.</p>
</div>
</div>
<div class="bg-yellow-500/10 dark:bg-yellow-900/20 border border-yellow-500/20 dark:border-yellow-500/30 rounded-lg p-6 flex gap-6 items-start">
<div class="text-yellow-500 mt-1">
<span class="material-symbols-outlined text-4xl">monitoring</span>
</div>
<div>
<h3 class="font-bold text-lg text-yellow-800 dark:text-yellow-300">Baja Producción en Lote 2023-D</h3>
<p class="text-yellow-700 dark:text-yellow-400 mt-1">La producción ha disminuido un 15% en los últimos 3 días. Se recomienda revisar las condiciones del galpón y la alimentación.</p>
</div>
</div>
</div>
</section>
</main>


<script src="../../sidebar.js"></script>

</body>
</html>