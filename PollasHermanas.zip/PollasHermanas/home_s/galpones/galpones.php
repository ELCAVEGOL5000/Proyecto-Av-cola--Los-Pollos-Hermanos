<?php
include '../../Sesion/config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Usar $conn en lugar de $mysqli
$sql = "SELECT g.id, g.nombre, g.capacidad, g.estado, 
               l.id AS lote_id, l.cantidad AS lote_cantidad, l.codigo_lote AS lote_codigo
        FROM galpones g
        LEFT JOIN galpones_lotes gl ON g.id = gl.galpon_id
        LEFT JOIN lotes l ON gl.lote_id = l.id";


$result = $conn->query($sql);

$galpones = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row['id'];
        if (!isset($galpones[$id])) {
            $galpones[$id] = [
                'nombre' => $row['nombre'],
                'capacidad' => $row['capacidad'],
                'estado' => $row['estado'],
                'lotes' => []
            ];
        }
        if ($row['lote_id']) {
            $galpones[$id]['lotes'][] = [
                'id' => $row['lote_id'],
                'codigo' => $row['lote_codigo'],
                'cantidad' => $row['lote_cantidad']
            ];
        }
    }
}


?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galpones</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com" rel="preconnect"/>
    <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
    <script>
        tailwind.config = {
        darkMode: "class",
        theme: {
            extend: {
            colors: {
                "primary": "#4cdf20",
                "background-light": "#f6f8f6",
                "background-dark": "#152111",
                "foreground-light": "#131711",
                "foreground-dark": "#e3e4e3",
                "card-light": "#ffffff",
                "card-dark": "#1f2d1c",
                "muted-light": "#6c8764",
                "muted-dark": "#a2b49e",
                "border-light": "#dee5dc",
                "border-dark": "#30402b",
            },
            fontFamily: {
                "display": ["Inter", "sans-serif"]
            },
            borderRadius: {
                "DEFAULT": "0.5rem",
                "lg": "0.75rem",
                "xl": "1rem",
                "full": "9999px"
            },
            },
        },
        }
    </script>
    <style>
        .material-symbols-outlined {
        font-variation-settings:
        'FILL' 1,
        'wght' 400,
        'GRAD' 0,
        'opsz' 24
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
    <link rel="stylesheet" href="../../home_o/lotes/lotes.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../lotes/lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li class="active"><a href="galpones.php"><span class="material-symbols-outlined">gite</span> Galpones</a></li>
      <li><a href="../reportes/reportes.php"><span class="material-symbols-outlined">assessment</span><span>Reportes</span></a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<main class="flex-1 p-8 max-w-7xl mx-auto">
<h1 class="text-3xl font-bold text-foreground-light dark:text-foreground-dark">Gestión de Galpones</h1>

<section class="mb-8">
<div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
<div class="relative w-full md:w-auto">
</div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
<?php foreach($galpones as $galpon): 
     $capacidadUsada = array_sum(array_column($galpon['lotes'], 'cantidad'));
     $porcentaje = $galpon['capacidad'] > 0 ? round(($capacidadUsada / $galpon['capacidad']) * 100) : 0;

    // Determinar estado
    $estadoClass = '';
    $estadoText = '';
    switch($galpon['estado']) {
        case 'inactivo':
            $estadoClass = 'bg-red-500/20 text-red-500 flex items-center gap-1.5';
            $estadoText = '<span class="material-symbols-outlined text-base">error</span> Inactivo';
            break;
        case 'activo':
            $estadoClass = 'bg-primary/20 text-primary';
            $estadoText = 'Operativo';
            break;
        case 'mantenimiento':
            $estadoClass = 'bg-yellow-500/20 text-yellow-500 flex items-center gap-1.5';
            $estadoText = '<span class="material-symbols-outlined text-base">build</span> Mantenimiento';
            break;
    } 
?>

<div class="bg-card-light dark:bg-card-dark rounded-xl shadow-md border border-border-light dark:border-border-dark p-6 flex flex-col justify-between">
    <div>
        <div class="flex justify-between items-start">
            <div>
                <h3 class="text-xl font-bold text-foreground-light dark:text-foreground-dark"><?= htmlspecialchars($galpon['nombre']) ?></h3>
                <p class="text-muted-light dark:text-muted-dark">Capacidad Total: <?= number_format($galpon['capacidad']) ?></p>
            </div>
            <span class="px-3 py-1 text-sm font-medium rounded-full <?= $estadoClass ?>"><?= $estadoText ?></span>
        </div>
        <div class="mt-4 grid grid-cols-2 gap-4">
            <div>
                <p class="text-sm text-muted-light dark:text-muted-dark">Lotes Alojados</p>
                <p class="text-lg font-semibold"><?= count($galpon['lotes']) ?></p>
            </div>
            <div>
                <p class="text-sm text-muted-light dark:text-muted-dark">Capacidad Utilizada</p>
                <p class="text-lg font-semibold"><?= number_format($capacidadUsada) ?> (<?= $porcentaje ?>%)</p>
            </div>
        </div>
    </div>
    <div class="mt-6 border-t border-border-light dark:border-border-dark pt-4">
    <button class="w-full text-sm bg-primary/10 text-primary font-medium py-2 px-3 rounded-lg shadow-sm hover:bg-primary/20 transition-colors flex items-center justify-center gap-2 ver-lotes-btn" <?= count($galpon['lotes']) == 0 ? 'disabled' : '' ?>>
        <span>Ver Lotes</span>
        <span class="material-symbols-outlined">arrow_forward</span>
    </button>

    <!-- Contenedor de lotes oculto -->
    <div class="lotes-list mt-2 hidden">
        <?php if(count($galpon['lotes']) > 0): ?>
            <ul class="list-disc list-inside text-sm text-muted-light dark:text-muted-dark">
                <?php foreach($galpon['lotes'] as $lote): ?>
                  <li>Código: <?= htmlspecialchars($lote['codigo']) ?> — Cantidad: <?= number_format($lote['cantidad']) ?></li>

                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-sm text-muted-light dark:text-muted-dark">No hay lotes.</p>
        <?php endif; ?>
    </div>
</div>

</div>
<?php endforeach; ?>
</div>

</section>
</main>

<script src="../../sidebar.js"></script>

<script>
document.querySelectorAll('.ver-lotes-btn').forEach(button => {
    button.addEventListener('click', () => {
        const lotesList = button.nextElementSibling;
        lotesList.classList.toggle('hidden');
    });
});
</script>


</body>
</html>
