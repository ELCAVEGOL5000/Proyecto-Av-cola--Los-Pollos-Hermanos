<?php
include '../../Sesion/config.php';

header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lote_id = $_POST['lote_id'] ?? null;
    $cantidad_muerta = $_POST['cantidad'] ?? null;

    if (!$lote_id || !is_numeric($cantidad_muerta) || $cantidad_muerta < 0) {
        echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
        exit;
    }

    // Verificar cantidad actual de aves
    $res = $conn->query("SELECT cantidad FROM lotes WHERE id = $lote_id");
    if ($res && $res->num_rows > 0) {
        $lote = $res->fetch_assoc();
        $cantidad_actual = $lote['cantidad'];

        if ($cantidad_muerta > $cantidad_actual) {
            echo json_encode(['success' => false, 'message' => 'La cantidad de aves muertas no puede superar la cantidad actual']);
            exit;
        }

        // Actualizar cantidad de aves
        $nueva_cantidad = $cantidad_actual - $cantidad_muerta;
        $stmt = $conn->prepare("UPDATE lotes SET cantidad = ? WHERE id = ?");
        $stmt->bind_param("ii", $nueva_cantidad, $lote_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Cantidad de aves actualizada correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al actualizar la base de datos']);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Lote no encontrado']);
    }

    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
