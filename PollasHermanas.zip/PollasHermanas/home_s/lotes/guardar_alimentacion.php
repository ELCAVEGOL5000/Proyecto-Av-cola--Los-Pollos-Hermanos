<?php
include '../../Sesion/config.php';

header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lote_id = $_POST['lote_id'] ?? null;
    $tipo_alimento = $_POST['tipo_alimento'] ?? null;
    $cantidad_kg = $_POST['cantidad_kg'] ?? null;

    if (!$lote_id || !$tipo_alimento || !is_numeric($cantidad_kg) || $cantidad_kg <= 0) {
        echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO alimentacion (lote_id, fecha, tipo_alimento, cantidad_kg) VALUES (?, NOW(), ?, ?)");
    $stmt->bind_param("isd", $lote_id, $tipo_alimento, $cantidad_kg);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Registro de alimentación guardado']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al guardar en la base de datos']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
