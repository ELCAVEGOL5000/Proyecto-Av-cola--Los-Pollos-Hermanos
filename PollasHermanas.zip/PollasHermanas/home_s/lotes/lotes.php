<?php
include '../../Sesion/config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$sql = "
SELECT 
    l.id,
    l.codigo_lote,
    l.tipo,
    l.cantidad,
    l.estado,
    g.nombre AS galpon,
    s.resultado AS salud_estado,
    p.cantidad AS produccion_reciente
FROM lotes l
LEFT JOIN galpones g ON g.lote_asignado_id = l.id
LEFT JOIN (
    SELECT lote_id, resultado
    FROM salud s1
    WHERE fecha = (
        SELECT MAX(fecha) FROM salud s2 WHERE s2.lote_id = s1.lote_id
    )
) s ON s.lote_id = l.id
LEFT JOIN (
    SELECT lote_id, SUM(cantidad) AS cantidad
    FROM produccion p1
    WHERE fecha = (
        SELECT MAX(fecha) FROM produccion p2 WHERE p2.lote_id = p1.lote_id
    )
    GROUP BY lote_id
) p ON p.lote_id = l.id
ORDER BY l.id DESC
";

$result = $conn->query($sql);
$lotes = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $lotes[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lotes</title>

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
<script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary":"#4cdf20",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "card-light": "#ffffff",
            "card-dark": "#1f2d1c",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49e",
            "border-light": "#dee5dc",
            "border-dark": "#30402b",
          },
          fontFamily: {
            "display": ["Inter", "sans-serif"]
          },
          borderRadius: {
            "DEFAULT": "0.5rem",
            "lg": "0.75rem",
            "xl": "1rem",
            "full": "9999px"
          },
        },
      },
    }
  </script>
<style>
    .material-symbols-outlined {
      font-variation-settings:
      'FILL' 1,
      'wght' 400,
      'GRAD' 0,
      'opsz' 24
    }
  </style>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
<link rel="stylesheet" href="../../home_o/lotes/lotes.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="lotes.php"><span class="material-symbols-outlined">view_cozy</span> Lotes</a></li>
      <li><a href="../galpones/galpones.php"><span class="material-symbols-outlined">gite</span> Galpones</a></li>
      <li><a href="../reportes/reportes.php"><span class="material-symbols-outlined">assessment</span><span>Reportes</span></a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>


<main class="flex-1 p-8 max-w-7xl mx-auto">

<h1 class="text-3xl font-bold text-foreground-light dark:text-foreground-dark">Monitoreo de Lotes</h1>

<div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
<div class="relative w-full md:w-auto">
</div>
</div>

<section class="mb-8">

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

<?php foreach($lotes as $lote): 
    // Obtener galpón asignado
    $galpon = $lote['galpon'] ?? '-';
    
    // Último estado de salud (puede venir null)
    $salud = $lote['salud_estado'] ?? '-';

    // Última producción
    $produccion = $lote['produccion_reciente'] ?? '-';

    // Determinar clase y texto del estado
    $estado_text = ucfirst($lote['estado']);
    $estado_class = ''; // Inicializamos la variable

switch ($lote['estado']) {
    case 'activo':
        $estado_class = 'bg-primary/20 text-primary';
        break;
    case 'inactivo':
        $estado_class = 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
        break;
    // El "default" en switch reemplaza a "default" en match
    default:
        $estado_class = 'bg-yellow-500/20 text-yellow-500';
        break;
}
?>



<div class="bg-card-light dark:bg-card-dark rounded-xl shadow-md border border-border-light dark:border-border-dark p-6 flex flex-col justify-between">
<div>
<div class="flex justify-between items-start">
<div>
<h3 class="text-xl font-bold text-foreground-light dark:text-foreground-dark"><?= htmlspecialchars($lote['codigo_lote']) ?></h3>
<p class="text-muted-light dark:text-muted-dark"><?= htmlspecialchars($galpon) ?></p>
</div>
<span class="px-3 py-1 text-sm font-medium rounded-full <?= $estado_class ?>"><?= $estado_text ?></span>
</div>

<div class="mt-4 grid grid-cols-2 gap-4">
<div>
<p class="text-sm text-muted-light dark:text-muted-dark">Cantidad Aves</p>
<p class="text-lg font-semibold"><?= number_format($lote['cantidad']) ?></p>
</div>
<div>
<p class="text-sm text-muted-light dark:text-muted-dark">Tipo de Lote</p>
<p class="text-lg font-semibold"><?= htmlspecialchars($lote['tipo']) ?></p>
</div>
<div>
<p class="text-sm text-muted-light dark:text-muted-dark">Estado de Salud</p>
<p class="text-lg font-semibold <?= $salud === 'enfermo' ? 'text-red-500' : ($salud === 'vacunado' ? 'text-yellow-500' : 'text-green-500') ?>"><?= htmlspecialchars($salud) ?></p>
</div>
<div>
<p class="text-sm text-muted-light dark:text-muted-dark">Producción Reciente</p>
<p class="text-lg font-semibold"><?= is_numeric($produccion) ? number_format($produccion) : $produccion ?> <?= $lote['tipo'] === 'Ponedoras' ? 'huevos/día' : 'kg' ?></p>
</div>
</div>
</div>

<div class="mt-6 border-t border-border-light dark:border-border-dark pt-4 flex gap-2">
<button class="btn-mortalidad w-full text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark text-foreground-light dark:text-foreground-dark font-medium py-2 px-3 rounded-lg shadow-sm hover:bg-primary/10 transition-colors" data-lote="<?= $lote['id'] ?>">Mortalidad</button>

<button class="btn-alimentacion w-full text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark text-foreground-light dark:text-foreground-dark font-medium py-2 px-3 rounded-lg shadow-sm hover:bg-primary/10 transition-colors" data-lote="<?= $lote['id'] ?>">Conv. Alimenticia</button>

</div>
</div>

<?php endforeach; ?>

<!-- Modal Mortalidad -->
<div id="modalMortalidad" class="hidden fixed inset-0 bg-black/50 flex justify-center items-center z-50">
  <div class="bg-card-light dark:bg-card-dark rounded-xl p-6 w-96 relative">
    <h2 class="text-xl font-bold mb-4 text-foreground-light dark:text-foreground-dark">Registrar Mortalidad</h2>
    <form id="formMortalidad">
      <input type="hidden" name="lote_id" id="lote_id">
      <div class="mb-4">
        <label for="cantidad" class="block text-sm text-muted-light dark:text-muted-dark">Cantidad de Aves Fallecidas</label>
        <input type="number" name="cantidad" id="cantidad" min="0" class="w-full border border-border-light dark:border-border-dark rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"/>
      </div>
      <div class="flex justify-end gap-2">
        <button type="button" id="cerrarModal" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-300">Cancelar</button>
        <button type="submit" class="px-4 py-2 rounded-lg bg-primary text-white">Guardar</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Alimentación -->
<div id="modalAlimentacion" class="hidden fixed inset-0 bg-black/50 flex justify-center items-center z-50">
  <div class="bg-card-light dark:bg-card-dark rounded-xl p-6 w-96 relative">
    <h2 class="text-xl font-bold mb-4 text-foreground-light dark:text-foreground-dark">Registrar Conv. Alimenticia</h2>
    <form id="formAlimentacion">
      <input type="hidden" name="lote_id" id="lote_id_alimento">
      <div class="mb-4">
        <label for="tipo_alimento" class="block text-sm text-muted-light dark:text-muted-dark">Tipo de Alimento</label>
        <input type="text" name="tipo_alimento" id="tipo_alimento" class="w-full border border-border-light dark:border-border-dark rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"/>
      </div>
      <div class="mb-4">
        <label for="cantidad_kg" class="block text-sm text-muted-light dark:text-muted-dark">Cantidad (kg)</label>
        <input type="number" name="cantidad_kg" id="cantidad_kg" min="0.1" step="0.01" class="w-full border border-border-light dark:border-border-dark rounded-lg px-3 py-2 focus:ring-primary focus:border-primary"/>
      </div>
      <div class="flex justify-end gap-2">
        <button type="button" id="cerrarModalAlimento" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-300">Cancelar</button>
        <button type="submit" class="px-4 py-2 rounded-lg bg-primary text-white">Guardar</button>
      </div>
    </form>
  </div>
</div>


</div>
</section>
</main>




<script src="../../sidebar.js"></script>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('modalMortalidad');
  const cerrarModal = document.getElementById('cerrarModal');
  const form = document.getElementById('formMortalidad');
  const loteInput = document.getElementById('lote_id');

  // Abrir modal
  document.querySelectorAll('.btn-mortalidad').forEach(btn => {
    btn.addEventListener('click', () => {
      loteInput.value = btn.dataset.lote;
      modal.classList.remove('hidden');
    });
  });

  // Cerrar modal
  cerrarModal.addEventListener('click', () => {
    modal.classList.add('hidden');
    form.reset();
  });

  // Enviar formulario
  form.addEventListener('submit', e => {
    e.preventDefault();
    const formData = new FormData(form);
    
    fetch('guardar_mortalidad.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      if(data.success){
        alert('Mortalidad registrada correctamente');
        modal.classList.add('hidden');
        form.reset();
        // Opcional: recargar la página para actualizar datos
        location.reload();
      } else {
        alert('Error: ' + data.message);
      }
    })
    .catch(err => {
      alert('Error en la petición');
      console.error(err);
    });
  });
});

const modalAlimentacion = document.getElementById('modalAlimentacion');
const cerrarModalAlimento = document.getElementById('cerrarModalAlimento');
const formAlimentacion = document.getElementById('formAlimentacion');
const loteAlimentoInput = document.getElementById('lote_id_alimento');

// Abrir modal Conv. Alimenticia
document.querySelectorAll('.btn-alimentacion').forEach(btn => {
  btn.addEventListener('click', () => {
    loteAlimentoInput.value = btn.dataset.lote;
    modalAlimentacion.classList.remove('hidden');
  });
});

// Cerrar modal
cerrarModalAlimento.addEventListener('click', () => {
  modalAlimentacion.classList.add('hidden');
  formAlimentacion.reset();
});

// Enviar formulario
formAlimentacion.addEventListener('submit', e => {
  e.preventDefault();
  const formData = new FormData(formAlimentacion);

  fetch('guardar_alimentacion.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if(data.success){
      alert('Alimentación registrada correctamente');
      modalAlimentacion.classList.add('hidden');
      formAlimentacion.reset();
      location.reload(); // recargar para ver cambios si es necesario
    } else {
      alert('Error: ' + data.message);
    }
  })
  .catch(err => {
    alert('Error en la petición');
    console.error(err);
  });
});

const searchInput = document.getElementById('searchInput');
const estadoFilter = document.getElementById('estadoFilter');
const loteCards = document.querySelectorAll('.lote-card');

function filtrarLotes() {
    const busqueda = searchInput.value.toLowerCase();
    const estado = estadoFilter.value.toLowerCase();

    loteCards.forEach(card => {
        const codigo = card.dataset.lote;
        const galpon = card.dataset.galpon;
        const cardEstado = card.dataset.estado;

        const coincideBusqueda = codigo.includes(busqueda) || galpon.includes(busqueda);
        const coincideEstado = estado === 'filtrar por estado' || cardEstado === estado;

        if(coincideBusqueda && coincideEstado){
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}

searchInput.addEventListener('input', filtrarLotes);
estadoFilter.addEventListener('change', filtrarLotes);


</script>


</body>
</html>