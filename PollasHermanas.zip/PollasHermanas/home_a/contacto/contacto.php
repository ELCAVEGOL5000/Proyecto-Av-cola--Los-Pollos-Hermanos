<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Contacto</title>
    <link rel="stylesheet" href="contacto.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>
<body>
<header>
  <div class="logo">
      <div class="icon" id="icon"></div>
      Sky Line
      <span class="corp">Corp</span>
    </div>
    <nav>
      <ul>
          <li><a href="servicios.php">Servicios</a></li>
          <li><a href="nosotros.php">Nosotros</a></li>
          <li><a href="contacto.php">Contacto</a></li>
      </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../abm/lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="../abm/reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<div class="container">
    <h1>Contacto</h1>
    <ul>
        <li><span class="email-label">Benjamín Ibañez (Product Owner):</span> <a href="mailto:benjamin.ibanezet32@gmail.com">benjamin.ibanezet32@gmail.com</a></li>
        <li><span class="email-label">Benjamin Korstanje (Scrum Master):</span> <a href="mailto:benjamin.korstanjeet32@gmail.com">benjamin.korstanjeet32@gmail.com</a></li>
        <li><span class="email-label">Ignacio Alvarez(Team):</span> <a href="mailto:ignacio.alvarezet32@gmail.com">ignacio.alvarezet32@gmail.com</a></li>
        <li><span class="email-label">Ramiro Averbuj(Team):</span> <a href="mailto:ramiro.averbujet32@gmail.com">ramiro.averbujet32@gmail.com</a></li>
        <li><span class="email-label">Correo general:</span> <a href="mailto:sky.line.corp.27@gmail.com">sky.line.corp.27@gmail.com</a></li>
    </ul>
</div>

<footer>
  &copy; 2025 Sky Line. Todos los derechos reservados.
</footer>

<script src="../../sidebar.js"></script>

</body>
</html>