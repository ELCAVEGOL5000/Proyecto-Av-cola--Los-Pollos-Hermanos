<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sobre Sky LineCorp</title>
  <link rel="stylesheet" href="nosotros.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>
<body>

<header>
  <div class="logo">
      <div class="icon" id="icon"></div>
      Sky Line
      <span class="corp">Corp</span>
    </div>
    <nav>
      <ul>
          <li><a href="servicios.php">Servicios</a></li>
          <li><a href="nosotros.php">Nosotros</a></li>
          <li><a href="contacto.php">Contacto</a></li>
      </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="../reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

  <main>
    <h1>Bienvenidos a Sky LineCorp</h1>
    <p>
      Somos una empresa dedicada a la producción responsable y sostenible de productos avícolas, comprometidos con la calidad, la innovación y el bienestar animal. Trabajamos de la mano con la naturaleza y la tecnología para ofrecer soluciones confiables y eficientes.
    </p>

    <section class="values">
      <article class="value-card">
        <h3>Calidad</h3>
        <p>Nos esforzamos por mantener los más altos estándares en todos nuestros productos para garantizar la satisfacción y confianza de nuestros clientes.</p>
      </article>

      <article class="value-card">
        <h3>Sostenibilidad</h3>
        <p>Cuidamos el medio ambiente mediante prácticas responsables que minimizan el impacto ecológico y promueven la conservación.</p>
      </article>

      <article class="value-card">
        <h3>Innovación</h3>
        <p>Implementamos tecnología avanzada para optimizar procesos y mejorar continuamente nuestra producción y servicios.</p>
      </article>

      <article class="value-card">
        <h3>Compromiso</h3>
        <p>Valoramos a nuestro equipo y clientes, fomentando relaciones basadas en la transparencia, respeto y responsabilidad.</p>
      </article>
    </section>
  </main>

  <footer>
    &copy; 2025 Sky LineCorp. Todos los derechos reservados.
  </footer>
  
  <script src="../../sidebar.js"></script>
  
</body>
</html>