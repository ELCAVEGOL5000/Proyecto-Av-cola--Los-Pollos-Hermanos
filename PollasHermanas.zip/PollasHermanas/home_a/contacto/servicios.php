
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Lotes de Aves</title>
  <link rel="stylesheet" href="servicios.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>
<body>

  <header>
  <div class="logo">
      <div class="icon" id="icon"></div>
      Sky Line
      <span class="corp">Corp</span>
    </div>
    <nav>
      <ul>
          <li><a href="servicios.php">Servicios</a></li>
          <li><a href="nosotros.php">Nosotros</a></li>
          <li><a href="contacto.php">Contacto</a></li>
      </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../abm/lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="../abm/reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

  <section id="servicios" class="servicios">
    <div class="container">
      <h1>Paneles del Sistema</h1>

      <div class="panel-card">
        <h2>🧑‍💻 Panel de Administradores</h2>
        <p>
          El panel administrativo es el núcleo de gestión del sistema. Ofrece control total sobre los recursos, usuarios y reportes estratégicos para la toma de decisiones.
        </p>
        <ul>
          <li>ABM completo de lotes, galpones, insumos, empleados y usuarios.</li>
          <li>Reportes de rentabilidad, trazabilidad y consumo de insumos.</li>
          <li>Gestión de roles y permisos para cada tipo de usuario.</li>
          <li>Control de distribución y logística de producción.</li>
        </ul>
        <div class="evitar">
          <strong>⚠️ Evitar:</strong>
          <ul>
            <li>Asignar permisos sin revisar responsabilidades.</li>
            <li>Eliminar registros sin respaldo o auditoría.</li>
            <li>Ignorar inconsistencias en reportes financieros.</li>
          </ul>
        <div class="tips">
        <h2>🧠 Tips para Administradores</h2>
        <ul>
            <li>🔐 Asigná roles con cuidado para evitar accesos innecesarios.</li>
            <li>🧾 Realizá respaldos periódicos de la base de datos.</li>
            <li>📈 Usá los reportes de rentabilidad para ajustar presupuestos.</li>
            <li>🧑‍💻 Revisá logs de actividad para detectar errores o mal uso.</li>
            <li>🛠️ Documentá cambios importantes en la configuración del sistema.</li>
        </ul>
</div>

        </div>
      </div>

    </div>

<script src="../../sidebar.js"></script>

</body>
</html>