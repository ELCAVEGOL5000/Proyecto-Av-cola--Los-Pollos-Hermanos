<?php
session_start();
header('Content-Type: application/json');
include '../Sesion/config.php';
   if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
       http_response_code(405);
       echo json_encode(['error' => 'Método no permitido']);
       exit();
   }
   $input = json_decode(file_get_contents('php://input'), true);
   $nombre = $input['nombre'] ?? null;
   if (!$nombre) {
       http_response_code(400);
       echo json_encode(['error' => 'Nombre del lote requerido']);
       exit();
   }
   try {
       $stmt = $conn->prepare("INSERT INTO lotes (nombre, estado, fecha_creacion) VALUES (?, 'activo', NOW())");
       $stmt->bind_param('s', $nombre);
       if ($stmt->execute()) {
           echo json_encode(['success' => true, 'message' => 'Lote creado exitosamente']);
       } else {
           throw new Exception('Error al insertar lote');
       }
       $stmt->close();
   } catch (Exception $e) {
       http_response_code(500);
       echo json_encode(['error' => 'Error interno del servidor: ' . $e->getMessage()]);
   }
   $conn->close();
   ?>


<!DOCTYPE html>
<html lang="es">
<head>
    <link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
    <link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter:wght@400;500;700;900" onload="this.rel='stylesheet'" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
    <title>Inicio</title>
    <link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
        tailwind.config = {
        darkMode: "class",
        theme: {
            extend: {
            colors: {
                "primary": "#f5e3b3",
                "background-light": "#f6f8f6",
                "background-dark": "#152111",
                "foreground-light": "#131711",
                "foreground-dark": "#e3e4e3",
                "subtle-light": "#dee5dc",
                "subtle-dark": "#2a3628",
                "muted-light": "#6c8764",
                "muted-dark": "#a2b49f",
            },
            fontFamily: {
                "display": ["Inter"]
            },
            borderRadius: {
                "DEFAULT": "0.5rem",
                "lg": "0.75rem",
                "xl": "1rem",
                "full": "9999px"
            },
            },
        },
        }
    </script>
    <link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../../contacto/servicios.php">Servicios</a></li>
      <li><a href="../../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="dashboard.php"><span class="material-symbols-outlined">home</span> Panel de Control</a></li>
      <li><a href="../abm/lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="confi" href="configuracion.php"><span class="material-symbols-outlined">settings</span> Configuración</a></li>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>



<main class="flex-1 p-8">
<div class="max-w-7xl mx-auto">

<h1 class="text-3xl font-bold">Panel de Control de Administrador</h1>
<p class="text-muted-light dark:text-muted-dark">Gestiona de forma completa la información de los empleados.</p>

<section class="mb-8">
<h2 class="text-2xl font-bold mb-4">Resumen General</h2>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
<div class="bg-background-light dark:bg-subtle-dark p-6 rounded-lg border border-subtle-light dark:border-subtle-dark">
<p class="text-base font-medium text-muted-light dark:text-muted-dark mb-2">Lotes Activos</p>
<p class="text-4xl font-bold">12</p>
</div>
<div class="bg-background-light dark:bg-subtle-dark p-6 rounded-lg border border-subtle-light dark:border-subtle-dark">
<p class="text-base font-medium text-muted-light dark:text-muted-dark mb-2">Galpones Ocupados</p>
<p class="text-4xl font-bold">8</p>
</div>
<div class="bg-background-light dark:bg-subtle-dark p-6 rounded-lg border border-subtle-light dark:border-subtle-dark">
<p class="text-base font-medium text-muted-light dark:text-muted-dark mb-2">Empleados Activos</p>
<p class="text-4xl font-bold">45</p>
</div>
</div>
</section>
<section class="mb-8">
<h2 class="text-2xl font-bold mb-4">Acciones Rápidas</h2>
<div class="flex gap-4">
<button class="flex items-center justify-center rounded-DEFAULT h-12 px-6 bg-primary text-background-dark font-bold text-sm transition-transform hover:scale-105">
<span class="material-symbols-outlined mr-2">add_circle</span>
<span>Crear Nuevo Lote</span>
</button>
<button class="flex items-center justify-center rounded-DEFAULT h-12 px-6 bg-subtle-light dark:bg-subtle-dark text-foreground-light dark:text-foreground-dark font-bold text-sm transition-colors hover:bg-subtle-light/80 dark:hover:bg-subtle-dark/80">
<span class="material-symbols-outlined mr-2">add_shopping_cart</span>
<span>Añadir Insumo</span>
</button>
</div>
</section>
<section>
<h2 class="text-2xl font-bold mb-4">Reportes Recientes</h2>
<div class="overflow-x-auto bg-background-light dark:bg-subtle-dark rounded-lg border border-subtle-light dark:border-subtle-dark">
<table class="w-full text-left">
<thead class="border-b border-subtle-light dark:border-subtle-dark">
<tr>
<th class="p-4 text-sm font-bold">Reporte</th>
<th class="p-4 text-sm font-bold">Fecha de Generación</th>
<th class="p-4 text-sm font-bold text-right">Acciones</th>
</tr>
</thead>
<tbody>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0">
<td class="p-4 text-sm">Rentabilidad del Lote 2023-Q4</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">2024-01-15</td>
<td class="p-4 text-sm font-bold text-primary text-right">
<a class="hover:underline" href="#">Descargar</a>
</td>
</tr>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0">
<td class="p-4 text-sm">Consumo de Insumos - Alimento</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">2024-01-10</td>
<td class="p-4 text-sm font-bold text-primary text-right">
<a class="hover:underline" href="#">Descargar</a>
</td>
</tr>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0">
<td class="p-4 text-sm">Distribución de Productos - Enero</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">2024-01-05</td>
<td class="p-4 text-sm font-bold text-primary text-right">
<a class="hover:underline" href="#">Descargar</a>
</td>
</tr>
</tbody>
</table>
</div>
</section>
</div>
</main>

<script src="../../sidebar.js"></script>



<script>

async function cargarDatosDashboard() {
    try {
        const response = await fetch('/api/dashboard-data.php');
        if (!response.ok) {
            throw new Error('Error en la respuesta de la API');
        }
        const data = await response.json();
        document.getElementById('lotes-activos').textContent = data.lotesActivos || 'N/A';
        document.getElementById('galpones-ocupados').textContent = data.galponesOcupados || 'N/A';
        document.getElementById('empleados-activos').textContent = data.empleadosActivos || 'N/A';
        console.log('Datos del dashboard actualizados:', data);
    } catch (error) {
        console.error('Error al cargar datos del dashboard:', error);
        alert('Error al cargar datos. Inténtalo de nuevo.');
    }
}

async function cargarReportes() {
    try {
        const response = await fetch('/api/reportes.php');
        if (!response.ok) {
            throw new Error('Error en la respuesta de la API de reportes');
        }
        const reportes = await response.json();
        const tbody = document.querySelector('#reportes-table tbody');
        tbody.innerHTML = '';
        reportes.forEach(reporte => {
            const row = `<tr>
                <td class="p-4 text-sm">${reporte.nombre}</td>
                <td class="p-4 text-sm text-muted-light dark:text-muted-dark">${reporte.fecha}</td>
                <td class="p-4 text-sm font-bold text-primary text-right"><a class="hover:underline" href="#">Descargar</a></td>
            </tr>`;
            tbody.innerHTML += row;
        });
        console.log('Reportes actualizados:', reportes);
    } catch (error) {
        console.error('Error al cargar reportes:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    cargarDatosDashboard();
    cargarReportes();
    // Actualizar automáticamente cada 30 segundos
    setInterval(() => {
        cargarDatosDashboard();
        cargarReportes();
    }, 30000);
});
// Evento para botón de crear lote
document.getElementById('btn-crear-lote')?.addEventListener('click', async () => {
    try {
        const response = await fetch('/api/crear-lote.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre: 'Nuevo Lote' })
        });
        if (response.ok) {
            alert('Lote creado exitosamente');
            cargarDatosDashboard();
        }
    } catch (error) {
        console.error('Error al crear lote:', error);
    }
});
</script>

</body>
</html>