<?php
require_once '../../../Sesion/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo = $_POST['codigo_lote'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $cantidad = $_POST['cantidad'] ?? '';
    $fecha = $_POST['fecha_inicio'] ?? '';
    $estado = $_POST['estado'] ?? '';

    if (!$codigo || !$tipo || !$cantidad || !$fecha || !$estado) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO lotes (codigo_lote, tipo, cantidad, fecha_inicio, estado) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $codigo, $tipo, $cantidad, $fecha, $estado);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => $conn->error]);
    }
}
