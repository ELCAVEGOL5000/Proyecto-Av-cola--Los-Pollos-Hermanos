<?php
require_once '../../../Sesion/config.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $codigo = $_POST['codigo_lote'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $cantidad = $_POST['cantidad'] ?? '';
    $fecha = $_POST['fecha_inicio'] ?? '';
    $estado = $_POST['estado'] ?? '';

    if (!$id) {
        $response['message'] = 'Falta el ID del lote.';
        echo json_encode($response);
        exit;
    }

    $stmt = $conn->prepare("UPDATE lotes SET codigo_lote=?, tipo=?, cantidad=?, fecha_inicio=?, estado=? WHERE id=?");
    $stmt->bind_param("ssissi", $codigo, $tipo, $cantidad, $fecha, $estado, $id);

    if ($stmt->execute()) {
        $response['success'] = true;
    } else {
        $response['message'] = 'Error al actualizar el lote: ' . $stmt->error;
    }

    echo json_encode($response);
}
