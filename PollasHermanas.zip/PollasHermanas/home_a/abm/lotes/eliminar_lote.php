<?php
require_once '../../../Sesion/config.php';

if (!isset($_POST['id'])) {
    echo "No se proporcionó ID";
    exit;
}

$id = intval($_POST['id']); // aseguramos que sea número

$stmt = $conn->prepare("DELETE FROM lotes WHERE id = ?");
if (!$stmt) {
    echo "Error en la preparación de la consulta: " . $conn->error;
    exit;
}

$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo "success"; // todo ok
    } else {
        echo "No se encontró el lote con ID $id"; // id inexistente
    }
} else {
    echo "Error al ejecutar la consulta: " . $stmt->error;
}
exit;
