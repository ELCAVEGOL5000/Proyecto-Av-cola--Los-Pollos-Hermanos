<?php
require_once '../../../Sesion/config.php';

$where = [];
$params = [];

if (!empty($_POST['codigo'])) {
    $where[] = "codigo_lote LIKE ?";
    $params[] = "%" . $_POST['codigo'] . "%";
}

if (!empty($_POST['estado'])) {
    $where[] = "estado = ?";
    $params[] = $_POST['estado'];
}

if (!empty($_POST['fecha'])) {
    $where[] = "fecha_inicio = ?";
    $params[] = $_POST['fecha'];
}

$sql = "SELECT id, codigo_lote, tipo, cantidad, fecha_inicio, estado FROM lotes";

if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY fecha_inicio DESC";

$stmt = $conn->prepare($sql);

if ($params) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $estado = strtolower($row['estado']);
        $clase = match($estado) {
            'activo' => 'bg-green-100 text-green-800',
            'pendiente' => 'bg-yellow-100 text-yellow-800',
            'finalizado' => 'bg-gray-100 text-gray-800',
            default => 'bg-gray-100 text-gray-800'
        };
        echo '<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">';
        echo '<td class="p-4 text-sm font-medium">' . htmlspecialchars($row['codigo_lote']) . '</td>';
        echo '<td class="p-4 text-sm text-muted-light dark:text-muted-dark">' . htmlspecialchars(ucfirst($row['tipo'])) . '</td>';
        echo '<td class="p-4 text-sm text-muted-light dark:text-muted-dark">' . number_format($row['cantidad']) . '</td>';
        echo '<td class="p-4 text-sm text-muted-light dark:text-muted-dark">' . date('d/m/Y', strtotime($row['fecha_inicio'])) . '</td>';
        echo '<td class="p-4 text-sm"><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ' . $clase . '">' . ucfirst($estado) . '</span></td>';
        echo '<td class="p-4 text-right">
                <div class="flex justify-end gap-2">
                  <button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Editar">
                    <span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
                  </button>
                  <button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Eliminar" onclick="eliminarLote(' . $row['id'] . ')">
                    <span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
                  </button>
                </div>
              </td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="6" class="p-4 text-center text-sm text-muted-light dark:text-muted-dark">No hay lotes registrados.</td></tr>';
}
?>
