<?php
include '../../Sesion/config.php';

$id = $_POST['id'] ?? 0;

$stmt = $conn->prepare("DELETE FROM galpones WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: galpones.php");
exit;
?>
