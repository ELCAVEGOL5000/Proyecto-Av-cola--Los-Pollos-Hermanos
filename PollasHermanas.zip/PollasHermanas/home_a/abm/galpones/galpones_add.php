<?php
include '../../../Sesion/config.php';
$error_msg = '';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $capacidad = $_POST['capacidad'];
    $estado = $_POST['estado'];
    $ubicacion = $_POST['ubicacion'];

    $stmt = $conn->prepare("INSERT INTO galpones (nombre, capacidad, estado, ubicacion) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $nombre, $capacidad, $estado, $ubicacion);
    if (isset($_POST['lotes']) && is_array($_POST['lotes'])) {
        foreach ($_POST['lotes'] as $lote_id) {
            $lote_id = intval($lote_id);
            $conn->query("INSERT INTO galpones_lotes (galpon_id, lote_id) VALUES ($galpon_id, $lote_id)");
        }
    }

    if ($stmt->execute()) {
        header("Location: ../galpones.php");
        exit;
    } else {
        $error_msg = $stmt->error;
    }
}
?>
