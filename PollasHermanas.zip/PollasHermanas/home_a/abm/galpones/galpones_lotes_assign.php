<?php
include '../../Sesion/config.php';
$galpon_id = $_GET['galpon_id'] ?? 0;

// Traer lotes existentes
$lotes = $conn->query("SELECT * FROM lotes")->fetch_all(MYSQLI_ASSOC);

// Lotes asignados actualmente
$asignados_res = $conn->query("SELECT lote_id FROM galpones_lotes WHERE galpon_id=$galpon_id");
$asignados = $asignados_res->fetch_all(MYSQLI_ASSOC);
$asignados_ids = array_column($asignados, 'lote_id');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lotes_post = $_POST['lotes'] ?? [];

    $stmt = $conn->prepare("DELETE FROM galpones_lotes WHERE galpon_id=?");
    $stmt->bind_param("i", $galpon_id);
    $stmt->execute();

    $stmt = $conn->prepare("INSERT INTO galpones_lotes (galpon_id, lote_id) VALUES (?, ?)");
    foreach ($lotes_post as $lote_id) {
        $stmt->bind_param("ii", $galpon_id, $lote_id);
        $stmt->execute();
    }

    header("Location: ../galpones.php");
    exit;
}
?>

<form method="POST">
    <?php foreach($lotes as $lote): ?>
        <label>
            <input type="checkbox" name="lotes[]" value="<?= $lote['id'] ?>" 
            <?= in_array($lote['id'], $asignados_ids)?'checked':'' ?>>
            <?= $lote['codigo_lote'] ?>
        </label><br>
    <?php endforeach; ?>
    <button type="submit">Asignar Lotes</button>
</form>
