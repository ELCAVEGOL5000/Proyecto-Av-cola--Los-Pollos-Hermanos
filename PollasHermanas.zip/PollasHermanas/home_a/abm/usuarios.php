<?php
include '../../Sesion/config.php';

// Recibir parámetros de filtro (si existen)
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$rol = isset($_GET['rol']) ? $conn->real_escape_string($_GET['rol']) : '';

$sql = "SELECT id, nombre, apellido, email, rol FROM usuarios WHERE 1";

if ($search) {
    $sql .= " AND (nombre LIKE '%$search%' OR email LIKE '%$search%')";
}

if ($rol) {
    $sql .= " AND rol = '$rol'";
}

$result = $conn->query($sql);

if(!$result) {
    die("Error en la consulta: " . $conn->error);
}

// Si es una petición AJAX, solo devolvemos las filas
if (isset($_GET['ajax'])) {
    if ($result->num_rows > 0) {
        while($user = $result->fetch_assoc()) {
            echo "<tr class='border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors'>
                <td class='p-4 text-sm font-medium'>".htmlspecialchars($user['nombre'])."</td>
                <td class='p-4 text-sm font-medium'>".htmlspecialchars($user['apellido'])."</td>
                <td class='p-4 text-sm text-muted-light dark:text-muted-dark'>".htmlspecialchars($user['email'])."</td>
                <td class='p-4 text-sm text-muted-light dark:text-muted-dark'>".ucfirst($user['rol'])."</td>
                <td class='p-4 text-right'>
                    <div class='flex justify-end gap-2'>
                        <button class='edit-btn p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors' title='Editar Rol/Permisos' data-id='{$user['id']}'>
                            <span class='material-symbols-outlined text-muted-light dark:text-muted-dark'>edit</span>
                        </button>
                        <button class='delete-btn p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors' title='Eliminar Usuario' data-id='{$user['id']}'>
                            <span class='material-symbols-outlined text-muted-light dark:text-muted-dark'>delete</span>
                        </button>
                    </div>
                </td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='5' class='p-4 text-center'>No hay usuarios registrados.</td></tr>";
    }
    exit;
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
    <link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter:wght@400;500;700;900" onload="this.rel='stylesheet'" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
    <title>Gestion Usuarios</title>
    <link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#f5e3b3",
                        "background-light": "#f6f8f6",
                        "background-dark": "#152111",
                        "foreground-light": "#131711",
                        "foreground-dark": "#e3e4e3",
                        "subtle-light": "#dee5dc",
                        "subtle-dark": "#2a3628",
                        "muted-light": "#6c8764",
                        "muted-dark": "#a2b49f",
                    },
                    fontFamily: {
                        "display": ["Inter"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.5rem",
                        "lg": "0.75rem",
                        "xl": "1rem",
                        "full": "9999px"
                    },
                },
            },
        }
    </script>
    <link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>
    
<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<main class="flex-1 p-8">
<div class="max-w-7xl mx-auto">
<h1 class="text-3xl font-bold">Gestión ABM de Usuarios</h1>
<p class="text-muted-light dark:text-muted-dark">Gestiona de forma completa las cuentas de usuario y sus roles.</p>
<section>
<div class="mb-6 border-b border-subtle-light dark:border-subtle-dark">
<nav aria-label="Tabs" class="flex gap-6 -mb-px">
<a href="lotes.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Lotes</button>
</a>
<a href="galpones.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Galpones</button>
</a>
<a href="insumos.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Insumos</button>
</a>
<a href="usuarios.php">
    <button class="px-1 py-4 border-b-2 border-primary text-primary font-medium text-sm">Usuarios</button>
</a>
</nav>
</div>
<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
<form id="filter-form" class="flex gap-2 flex-wrap">
  <div class="relative">
    <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted-light dark:text-muted-dark">search</span>
    <input id="search" name="search" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>" class="pl-10 pr-4 py-2 w-64 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm" placeholder="Buscar por nombre, email..." type="text"/>
  </div>
  <select id="rol" name="rol" class="w-48 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm">
    <option value="">Filtrar por rol</option>
    <option value="admin" <?= (isset($_GET['rol']) && $_GET['rol']=='administrador')?'selected':'' ?>>Administrador</option>
    <option value="supervisor" <?= (isset($_GET['rol']) && $_GET['rol']=='supervisor')?'selected':'' ?>>Supervisor</option>
    <option value="operario" <?= (isset($_GET['rol']) && $_GET['rol']=='operario')?'selected':'' ?>>Operador</option>
  </select>
</form>


</div>
<div class="overflow-x-auto bg-background-light dark:bg-subtle-dark rounded-lg border border-subtle-light dark:border-subtle-dark">
<table class="w-full text-left">
<thead class="border-b border-subtle-light dark:border-subtle-dark">
<tr>
<th class="p-4 text-sm font-bold">Nombre</th>
<th class="p-4 text-sm font-bold">Apellido</th>
<th class="p-4 text-sm font-bold">Correo Electrónico</th>
<th class="p-4 text-sm font-bold">Rol</th>
<th class="p-4 text-sm font-bold">Estado</th>
<th class="p-4 text-sm font-bold text-right">Acciones</th>
</tr>
</thead>

<!-- Modal Editar Rol -->
<div id="editModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50">
  <div class="bg-background-light dark:bg-subtle-dark p-6 rounded-lg w-80">
    <h2 class="text-lg font-bold mb-4 text-foreground-light dark:text-foreground-dark">Editar Rol</h2>
    <select id="editRol" class="w-full border border-subtle-light dark:border-subtle-dark rounded-DEFAULT p-2 mb-4 bg-background-light dark:bg-subtle-dark text-sm">
      <option value="admin">Administrador</option>
      <option value="supervisor">Supervisor</option>
      <option value="operario">Operario</option>
    </select>
    <div class="flex justify-end gap-2">
      <button id="cancelEdit" class="px-4 py-2 rounded-DEFAULT bg-subtle-light dark:bg-subtle-dark text-sm">Cancelar</button>
      <button id="saveEdit" class="px-4 py-2 rounded-DEFAULT bg-primary text-background-dark text-sm font-bold">Guardar</button>
    </div>
  </div>
</div>


<tbody id="usuarios-body">
<?php if($result && $result->num_rows > 0): ?>
    <?php while($user = $result->fetch_assoc()): ?>
        <tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">
            <td class="p-4 text-sm font-medium"><?= htmlspecialchars($user['nombre']) ?></td>
            <td class="p-4 text-sm font-medium"><?= htmlspecialchars($user['apellido']) ?></td>
            <td class="p-4 text-sm text-muted-light dark:text-muted-dark"><?= htmlspecialchars($user['email']) ?></td>
            <td class="p-4 text-sm text-muted-light dark:text-muted-dark"><?= ucfirst($user['rol']) ?></td>
            <td class="p-4 text-sm text-muted-light dark:text-muted-dark">
    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= $user['rol'] === 'ninguno' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800' ?>">
        <?= $user['rol'] === 'ninguno' ? 'Inactivo' : 'Activo' ?>
    </span>
</td>
            <td class="p-4 text-right">
                <div class="flex justify-end gap-2">
                    <button 
    class="edit-btn p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" 
    title="Editar Rol/Permisos"
    data-id="<?= $user['id'] ?>"
>
    <span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
</button>

<button 
    class="delete-btn p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" 
    title="Eliminar Usuario"
    data-id="<?= $user['id'] ?>"
>
    <span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
</button>

                </div>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr><td colspan="6" class="p-4 text-center">No hay usuarios registrados.</td></tr>
<?php endif; ?>
</tbody>

</table>
</div>
</section>
</div>
</main>

<script src="../../sidebar.js"></script>

<script>
let currentEditId = null;

// Función para actualizar la tabla (filtros)
function actualizarTabla(){
    const search = document.getElementById('search').value;
    const rol = document.getElementById('rol').value;

    fetch(`usuarios.php?ajax=1&search=${encodeURIComponent(search)}&rol=${encodeURIComponent(rol)}`)
        .then(res => res.text())
        .then(html => {
            document.getElementById('usuarios-body').innerHTML = html;
        });
}

document.addEventListener('click', function(e){
    // Abrir modal de editar
    if(e.target.closest('.edit-btn')){
        const btn = e.target.closest('.edit-btn');
        currentEditId = btn.dataset.id;
        const row = btn.closest('tr');
        const currentRol = row.querySelector('td:nth-child(4)').textContent.trim().toLowerCase();
        document.getElementById('editRol').value = currentRol;
        document.getElementById('editModal').classList.remove('hidden');
        document.getElementById('editModal').classList.add('flex');
    }

    // Cancelar edición
    if(e.target.id === 'cancelEdit'){
        document.getElementById('editModal').classList.add('hidden');
        currentEditId = null;
    }

    // Guardar edición
    if(e.target.id === 'saveEdit'){
        const nuevoRol = document.getElementById('editRol').value;
        if(!currentEditId) return;

        fetch('usuarios/usuarios_edit.php', {
            method: 'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: `id=${currentEditId}&rol=${encodeURIComponent(nuevoRol)}`
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                alert('Rol actualizado');
                document.getElementById('editModal').classList.add('hidden');

                // Actualizar fila en el DOM
                const row = document.querySelector(`button.edit-btn[data-id='${currentEditId}']`).closest('tr');
                
                // Actualizar columna Rol
                row.querySelector('td:nth-child(4)').textContent = nuevoRol.charAt(0).toUpperCase() + nuevoRol.slice(1);

                // Actualizar columna Estado
                const estadoSpan = row.querySelector('td:nth-child(5) span');
                if(nuevoRol === 'ninguno'){ 
                    estadoSpan.textContent = 'Inactivo';
                    estadoSpan.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800';
                } else {
                    estadoSpan.textContent = 'Activo';
                    estadoSpan.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800';
                }

                currentEditId = null;
            } else {
                alert('Error: '+data.error);
            }
        });
    }

    // Eliminar usuario
    if(e.target.closest('.delete-btn')){
        const btn = e.target.closest('.delete-btn');
        const id = btn.dataset.id;
        if(confirm('¿Seguro que quieres eliminar este usuario?')){
            fetch('usuarios/usuarios_delete.php', {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: `id=${id}`
            })
            .then(res => res.json())
            .then(data => {
                if(data.success){
                    alert('Usuario eliminado');
                    actualizarTabla();
                } else {
                    alert('Error: '+data.error);
                }
            });
        }
    }
});

// Actualizar tabla al cambiar filtros
document.getElementById('search').addEventListener('input', actualizarTabla);
document.getElementById('rol').addEventListener('change', actualizarTabla);


</script>



</body>
</html>