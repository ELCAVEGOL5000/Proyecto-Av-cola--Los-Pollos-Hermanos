<?php
include '../../Sesion/config.php';

// Obtener galpones y lotes
$galpones = $conn->query("SELECT id, nombre FROM galpones ORDER BY nombre");
$lotes = $conn->query("SELECT id, codigo_lote FROM lotes ORDER BY codigo_lote");

// Obtener reporte de mortalidad últimos 30 días
$reporte = $conn->query("
    SELECT 
        p.fecha,
        COALESCE(g.nombre, 'Sin asignar') AS galpon,
        l.codigo_lote,
        SUM(p.cantidad) AS produccion_total,
        ROUND((SUM(p.cantidad) * 0.1), 2) AS mortalidad_total
    FROM produccion p
    INNER JOIN lotes l ON p.lote_id = l.id
    LEFT JOIN galpones_lotes gl ON l.id = gl.lote_id
    LEFT JOIN galpones g ON gl.galpon_id = g.id
    WHERE p.fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY p.fecha, g.nombre, l.codigo_lote
    ORDER BY p.fecha DESC
");

$grafico = $conn->query("
    SELECT 
        COALESCE(g.nombre, 'Sin asignar') AS galpon,
        ROUND(AVG(p.cantidad * 0.1), 2) AS mortalidad_promedio
    FROM produccion p
    INNER JOIN lotes l ON p.lote_id = l.id
    LEFT JOIN galpones_lotes gl ON l.id = gl.lote_id
    LEFT JOIN galpones g ON gl.galpon_id = g.id
    WHERE p.fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY g.nombre
");

$labels = [];
$values = [];

while ($row = $grafico->fetch_assoc()) {
    $labels[] = $row['galpon'];
    $values[] = $row['mortalidad_promedio'];
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
<script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": "#f5e3b3 ",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "card-light": "#ffffff",
            "card-dark": "#1f2d1c",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49e",
            "border-light": "#dee5dc",
            "border-dark": "#30402b",
          },
          fontFamily: {
            "display": ["Inter", "sans-serif"]
          },
          borderRadius: {
            "DEFAULT": "0.5rem",
            "lg": "0.75rem",
            "xl": "1rem",
            "full": "9999px"
          },
        },
      },
    }
  </script>
<style>
    .material-symbols-outlined {
      font-variation-settings:
      'FILL' 1,
      'wght' 400,
      'GRAD' 0,
      'opsz' 24
    }
  </style>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
<link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li class="active"><a href="reportes.php"><span class="material-symbols-outlined">assessment</span><span>Reportes</span></a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>


<main class="flex-1 p-8 max-w-7xl mx-auto">

<h1 class="text-3xl font-bold text-foreground-light dark:text-foreground-dark">Reportes</h1>

<section class="mb-8">
</section>


<section>
  <div class="bg-card-light dark:bg-card-dark rounded-xl shadow-md border border-border-light dark:border-border-dark p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-xl font-bold">Reporte de Mortalidad - Últimos 30 días</h2>
      <div class="flex items-center gap-2">
        
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <div class="lg:col-span-3">
        <div class="overflow-x-auto">
          <table class="w-full text-left">
            <thead class="border-b border-border-light dark:border-border-dark">
              <tr>
                <th class="py-2 px-4 font-semibold">Fecha</th>
                <th class="py-2 px-4 font-semibold">Galpón</th>
                <th class="py-2 px-4 font-semibold">Lote</th>
                <th class="py-2 px-4 font-semibold text-right">Producción</th>
                <th class="py-2 px-4 font-semibold text-right">Mortalidad</th>
              </tr>
            </thead>
            <tbody>
  <?php if ($reporte->num_rows > 0): ?>
    <?php while($row = $reporte->fetch_assoc()): ?>
      <tr class="border-b border-border-light dark:border-border-dark">
        <td class="py-3 px-4"><?= htmlspecialchars($row['fecha']) ?></td>
        <td class="py-3 px-4"><?= htmlspecialchars($row['galpon'] ?? 'Sin asignar') ?></td>
        <td class="py-3 px-4"><?= htmlspecialchars($row['codigo_lote']) ?></td>
        <td class="py-3 px-4 text-right"><?= htmlspecialchars($row['produccion_total']) ?></td>
        <td class="py-3 px-4 text-right <?= ($row['mortalidad_total'] > 5 ? 'text-red-500' : '') ?>">
          <?= htmlspecialchars($row['mortalidad_total']) ?>%
        </td>
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr>
      <td colspan="5" class="text-center py-4 text-muted-light dark:text-muted-dark">No hay registros en los últimos 30 días.</td>
    </tr>
  <?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>
</section>
</main>

<script src="../../sidebar.js"></script>


</body>
</html>