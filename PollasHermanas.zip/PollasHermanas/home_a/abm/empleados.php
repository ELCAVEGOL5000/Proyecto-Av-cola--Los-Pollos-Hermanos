<!DOCTYPE html>
<html lang="es">
<head>
    <link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
    <link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter:wght@400;500;700;900" onload="this.rel='stylesheet'" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
    <title>Gestion Empleados</title>
    <link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": "#f5e3b3 ",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "subtle-light": "#dee5dc",
            "subtle-dark": "#2a3628",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49f",
          },
          fontFamily: {
            "display": ["Inter"]
          },
          borderRadius: {
            "DEFAULT": "0.5rem",
            "lg": "0.75rem",
            "xl": "1rem",
            "full": "9999px"
          },
        },
      },
    }
    </script>
    <link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li><a href="../dashboard/dashboard.php"><span class="material-symbols-outlined">home</span> Panel de Control</a></li>
      <li class="active"><a href="galpones.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>

    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="confi" href="configuracion.php"><span class="material-symbols-outlined">settings</span> Configuración</a></li>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>


<main class="flex-1 p-8">
<div class="max-w-7xl mx-auto">
<h1 class="text-3xl font-bold">Gestión ABM de Empleados</h1>
<p class="text-muted-light dark:text-muted-dark">Gestiona de forma completa la información de los empleados.</p>
<section>
<div class="mb-6 border-b border-subtle-light dark:border-subtle-dark">
<nav aria-label="Tabs" class="flex gap-6 -mb-px">

<a href="lotes.php">
<button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Lotes</button>
</a>
<a href="galpones.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Galpones</button>
</a>
<a href="insumos.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Insumos</button>
</a>
<a href="empleados.php">
    <button class="px-1 py-4 border-b-2 border-primary text-primary font-medium text-sm">Empleados</button>
</a>
<a href="usuarios.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Usuarios</button>
</a>

</nav>
</div>
<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
<div class="flex gap-2 flex-wrap">
<div class="relative">
<span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted-light dark:text-muted-dark">search</span>
<input class="pl-10 pr-4 py-2 w-64 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm" placeholder="Buscar por nombre, apellido..." type="text"/>
</div>
<select class="w-48 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm">
<option>Filtrar por rol</option>
<option>Operario</option>
<option>Supervisor</option>
<option>Administrador</option>
<option>Veterinario</option>
</select>
</div>
<button class="flex items-center justify-center rounded-DEFAULT h-10 px-6 bg-primary text-background-dark font-bold text-sm transition-transform hover:scale-105 w-full md:w-auto">
<span class="material-symbols-outlined mr-2">add</span>
<span>Añadir Nuevo Empleado</span>
</button>
</div>
<div class="overflow-x-auto bg-background-light dark:bg-subtle-dark rounded-lg border border-subtle-light dark:border-subtle-dark">
<table class="w-full text-left">
<thead class="border-b border-subtle-light dark:border-subtle-dark">
<tr>
<th class="p-4 text-sm font-bold">Nombre</th>
<th class="p-4 text-sm font-bold">Apellido</th>
<th class="p-4 text-sm font-bold">Rol</th>
<th class="p-4 text-sm font-bold">Correo Electrónico</th>
<th class="p-4 text-sm font-bold">Estado</th>
<th class="p-4 text-sm font-bold text-right">Acciones</th>
</tr>
</thead>
<tbody>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">
<td class="p-4 text-sm font-medium">Juan</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Pérez</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Operario</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">juan.perez@avicola.com</td>
<td class="p-4 text-sm"><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Activo</span></td>
<td class="p-4 text-right">
<div class="flex justify-end gap-2">
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Ver Detalles">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">visibility</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Editar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Eliminar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
</button>
</div>
</td>
</tr>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">
<td class="p-4 text-sm font-medium">María</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">García</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Supervisor</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">maria.garcia@avicola.com</td>
<td class="p-4 text-sm"><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Activo</span></td>
<td class="p-4 text-right">
<div class="flex justify-end gap-2">
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Ver Detalles">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">visibility</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Editar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Eliminar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
</button>
</div>
</td>
</tr>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">
<td class="p-4 text-sm font-medium">Carlos</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Rodríguez</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Administrador</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">carlos.r@avicola.com</td>
<td class="p-4 text-sm"><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Activo</span></td>
<td class="p-4 text-right">
<div class="flex justify-end gap-2">
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Ver Detalles">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">visibility</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Editar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Eliminar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
</button>
</div>
</td>
</tr>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">
<td class="p-4 text-sm font-medium">Ana</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Martínez</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">Operario</td>
<td class="p-4 text-sm text-muted-light dark:text-muted-dark">ana.martinez@avicola.com</td>
<td class="p-4 text-sm"><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Inactivo</span></td>
<td class="p-4 text-right">
<div class="flex justify-end gap-2">
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Ver Detalles">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">visibility</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Editar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
</button>
<button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Eliminar">
<span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
</button>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</section>
</div>
</main>


<script src="../../sidebar.js"></script>

</body>
</html>