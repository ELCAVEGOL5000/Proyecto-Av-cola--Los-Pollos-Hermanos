<?php
require_once '../../../Sesion/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $tipo = $_POST['tipo'];
    $cantidad = $_POST['cantidad'];
    $unidad = $_POST['unidad'];
    $fecha_ingreso = $_POST['fecha_ingreso'];
    $fecha_vencimiento = $_POST['fecha_vencimiento'] ?: null;

    $stmt = $conn->prepare("INSERT INTO inventario (nombre, tipo, cantidad, unidad, fecha_ingreso, fecha_vencimiento) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsss", $nombre, $tipo, $cantidad, $unidad, $fecha_ingreso, $fecha_vencimiento);
    $stmt->execute();
    $stmt->close();

    header("Location: insumos.php"); // redirige de nuevo a la lista
    exit();
}
?>
