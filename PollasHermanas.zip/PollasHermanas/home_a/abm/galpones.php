<?php
include '../../Sesion/config.php';

function limpiar($conn, $dato) {
    return htmlspecialchars(trim($conn->real_escape_string($dato)), ENT_QUOTES, 'UTF-8');
}

$error_msg = '';

try {
    // === EDITAR GALPÓN ===
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
        $id = intval($_POST['edit_id']);
        $nombre = limpiar($conn, $_POST['nombre']);
        $ubicacion = limpiar($conn, $_POST['ubicacion']);
        $capacidad = intval($_POST['capacidad']);
        $estado = limpiar($conn, $_POST['estado']);

        $stmt = $conn->prepare("UPDATE galpones SET nombre=?, ubicacion=?, capacidad=?, estado=? WHERE id=?");
        $stmt->bind_param("ssisi", $nombre, $ubicacion, $capacidad, $estado, $id);
        $stmt->execute();
        $stmt->close();
    }
    // === ACTUALIZAR GALPONES_LOTES ===
if(isset($_POST['lotes']) && is_array($_POST['lotes'])){
  $lotesSeleccionados = $_POST['lotes'];

  // Borrar los lotes actuales del galpón
  $stmtDel = $conn->prepare("DELETE FROM galpones_lotes WHERE galpon_id=?");
  $stmtDel->bind_param("i", $id);
  $stmtDel->execute();
  $stmtDel->close();

  // Insertar los nuevos lotes
  $stmtIns = $conn->prepare("INSERT INTO galpones_lotes (galpon_id, lote_id) VALUES (?, ?)");
  foreach($lotesSeleccionados as $lote_id){
      $lote_id = intval($lote_id);
      $stmtIns->bind_param("ii", $id, $lote_id);
      $stmtIns->execute();
  }
  $stmtIns->close();
}

    // === ELIMINAR GALPÓN ===
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
        $id = intval($_POST['delete_id']);
        $stmt = $conn->prepare("DELETE FROM galpones WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    // === OBTENER GALPONES ===
    $galpones = [];
    $res = $conn->query("SELECT * FROM galpones ORDER BY id ASC");
    if ($res) $galpones = $res->fetch_all(MYSQLI_ASSOC);

    // === OBTENER LOTES ACTIVOS ===
    $lotesActivos = [];
    $res = $conn->query("SELECT id, codigo_lote FROM lotes WHERE estado='activo'");
    while ($l = $res->fetch_assoc()) {
        $lotesActivos[] = $l;
    }

    // === OBTENER LOTES ASIGNADOS ===
    $lotesAsignados = [];
    $res = $conn->query("
        SELECT gl.galpon_id, l.codigo_lote 
        FROM galpones_lotes gl 
        JOIN lotes l ON gl.lote_id = l.id
    ");
    while ($row = $res->fetch_assoc()) {
        $lotesAsignados[$row['galpon_id']][] = $row['codigo_lote'];
    }

} catch (Exception $e) {
    $error_msg = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
    <link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter:wght@400;500;700;900" onload="this.rel='stylesheet'" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
    <title>Gestion Galpones</title>
    <link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#f5e3b3",
                        "background-light": "#f6f8f6",
                        "background-dark": "#152111",
                        "foreground-light": "#131711",
                        "foreground-dark": "#e3e4e3",
                        "subtle-light": "#dee5dc",
                        "subtle-dark": "#2a3628",
                        "muted-light": "#6c8764",
                        "muted-dark": "#a2b49f",
                    },
                    fontFamily: {
                        "display": ["Inter"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.5rem",
                        "lg": "0.75rem",
                        "xl": "1rem",
                        "full": "9999px"
                    },
                },
            },
        }
    </script>
    <link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="galpones.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>

<main class="flex-1 p-8">
<div class="max-w-7xl mx-auto">

<h1 class="text-3xl font-bold">Gestión ABM de Galpones</h1>
<p class="text-muted-light dark:text-muted-dark">Gestiona de forma completa las naves avícolas.</p>

<?php if (!empty($error_msg)): ?>
<div class="p-3 my-4 rounded bg-red-100 text-red-700">
  ⚠️ <?= htmlspecialchars($error_msg) ?>
</div>
<?php endif; ?>

<section>
<div class="mb-6 border-b border-subtle-light dark:border-subtle-dark">
<nav aria-label="Tabs" class="flex gap-6 -mb-px">
<a href="lotes.php">
<button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Lotes</button>
</a>
<a href="galpones.php">
    <button class="px-1 py-4 border-b-2 border-primary text-primary font-medium text-sm">Galpones</button>
</a>
<a href="insumos.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Insumos</button>
</a>
<a href="usuarios.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Usuarios</button>
</a>
</nav>
</div>

<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
<div class="flex gap-2 flex-wrap">
<div class="relative">
<span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted-light dark:text-muted-dark">search</span>
<input id="search-input" class="pl-10 pr-4 py-2 w-64 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm" placeholder="Buscar por código o nombre..." type="text"/>
</div>
<select id="estado-select" class="w-48 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm">
<option value="">Filtrar por estado</option>
<option value="activo">Activo</option>
<option value="inactivo">Inactivo</option>
<option value="mantenimiento">En mantenimiento</option>
</select>
</div>
<button id="btn-add-galpon" class="flex items-center justify-center rounded-DEFAULT h-10 px-6 bg-primary text-background-dark font-bold text-sm transition-transform hover:scale-105 w-full md:w-auto">
<span class="material-symbols-outlined mr-2">add</span>
<span>Añadir Nuevo Galpón</span>
</button>
</div>

<!-- === MODAL AGREGAR GALPÓN === -->
<div id="modal-add" class="fixed inset-0 bg-black/50 hidden z-50 flex items-center justify-center">
  <div class="bg-background-light dark:bg-subtle-dark p-6 rounded-xl w-96">
    <h2 class="text-xl font-bold mb-4">Añadir Nuevo Galpón</h2>
    <form method="POST" action="galpones/galpones_add.php">
      <div class="mb-4">
        <label class="block text-sm mb-1">Nombre</label>
        <input type="text" name="nombre" required class="w-full border rounded p-2">
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Ubicacion</label>
        <input type="text" name="ubicacion" required class="w-full border rounded p-2">
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Capacidad Máxima</label>
        <input type="number" name="capacidad" required class="w-full border rounded p-2">
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Asignar lotes</label>
        <select name="lotes[]" multiple class="w-full border rounded p-2">
          <?php foreach ($lotesActivos as $lote): ?>
            <option value="<?= $lote['id'] ?>"><?= htmlspecialchars($lote['codigo_lote']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Estado</label>
        <select name="estado" class="w-full border rounded p-2" required>
          <option value="activo">Activo</option>
          <option value="inactivo">Inactivo</option>
          <option value="mantenimiento">En mantenimiento</option>
        </select>
      </div>
      <div class="flex justify-end gap-2">
        <button type="button" onclick="toggleModal('modal-add')" class="px-4 py-2 bg-gray-300 rounded">Cancelar</button>
        <button type="submit" class="px-4 py-2 bg-primary text-background-dark rounded">Agregar</button>
      </div>
    </form>
  </div>
</div>

<!-- === MODAL EDITAR GALPÓN === -->
<div id="modal-edit" class="fixed inset-0 bg-black/50 hidden z-50 flex items-center justify-center">
  <div class="bg-background-light dark:bg-subtle-dark p-6 rounded-xl w-96">
    <h2 class="text-xl font-bold mb-4">Editar Galpón</h2>
    <form method="POST" id="form-edit-galpon">
      <input type="hidden" name="edit_id" id="edit-id">
      <div class="mb-4">
        <label class="block text-sm mb-1">Nombre</label>
        <input type="text" name="nombre" id="edit-nombre" required class="w-full border rounded p-2">
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Ubicación</label>
        <input type="text" name="ubicacion" id="edit-ubicacion" required class="w-full border rounded p-2">
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Capacidad Máxima</label>
        <input type="number" name="capacidad" id="edit-capacidad" required class="w-full border rounded p-2">
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Asignar lotes</label>
        <select name="lotes[]" multiple class="w-full border rounded p-2">
          <?php foreach ($lotesActivos as $lote): ?>
            <option value="<?= $lote['id'] ?>"><?= htmlspecialchars($lote['codigo_lote']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="mb-4">
        <label class="block text-sm mb-1">Estado</label>
        <select name="estado" id="edit-estado" class="w-full border rounded p-2" required>
          <option value="activo">Activo</option>
          <option value="inactivo">Inactivo</option>
          <option value="mantenimiento">En mantenimiento</option>
        </select>
      </div>
      <div class="flex justify-end gap-2">
        <button type="button" onclick="toggleModal('modal-edit')" class="px-4 py-2 bg-gray-300 rounded">Cancelar</button>
        <button type="submit" class="px-4 py-2 bg-primary text-background-dark rounded">Guardar</button>
      </div>
    </form>
  </div>
</div>

<div class="overflow-x-auto bg-background-light dark:bg-subtle-dark rounded-lg border border-subtle-light dark:border-subtle-dark">
<table class="w-full text-left">
<thead class="border-b border-subtle-light dark:border-subtle-dark">
<tr>
<th class="p-4 text-sm font-bold">Código/Nombre</th>
<th class="p-4 text-sm font-bold">Capacidad Máxima</th>
<th class="p-4 text-sm font-bold">Lotes Asignados</th>
<th class="p-4 text-sm font-bold">Estado</th>
<th class="p-4 text-sm font-bold text-right">Acciones</th>
</tr>
</thead>
<tbody>
<?php
if (!empty($galpones)) {
    foreach ($galpones as $galpon) {
        $estado = $galpon['estado'];
        switch ($estado) {
            case 'activo': $estado_class='bg-green-100 text-green-800'; break;
            case 'inactivo': $estado_class='bg-red-100 text-red-800'; break;
            case 'mantenimiento': $estado_class='bg-blue-100 text-blue-800'; break;
            default: $estado_class='bg-gray-100 text-gray-800';
        }

        $lote_text = isset($lotesAsignados[$galpon['id']]) ? implode(', ', $lotesAsignados[$galpon['id']]) : '-';

        echo "<tr data-galpon data-nombre='".strtolower($galpon['nombre'])."' data-estado='".strtolower($estado)."' class='border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors'>
        <td class='p-4 text-sm font-medium'>{$galpon['id']} - \"".htmlspecialchars($galpon['nombre'])."\"</td>
        <td class='p-4 text-sm text-muted-light dark:text-muted-dark'>".number_format($galpon['capacidad'])." aves</td>
        <td class='p-4 text-sm text-muted-light dark:text-muted-dark'>{$lote_text}</td>
        <td class='p-4 text-sm text-muted-light dark:text-muted-dark'>
            <span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {$estado_class}'>{$estado}</span>
        </td>
        <td class='p-4 text-right'>
            <div class='flex justify-end gap-2'>
                <button onclick=\"abrirEditar({$galpon['id']}, '".htmlspecialchars($galpon['nombre'], ENT_QUOTES)."', '".htmlspecialchars($galpon['ubicacion'], ENT_QUOTES)."', {$galpon['capacidad']}, '{$galpon['estado']}')\" class='p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors' title='Editar'>
                    <span class='material-symbols-outlined text-muted-light dark:text-muted-dark'>edit</span>
                </button>
                <form method='POST' action='' class='inline'>
                    <input type='hidden' name='delete_id' value='{$galpon['id']}'>
                    <button type='submit' class='p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors' title='Eliminar'>
                        <span class='material-symbols-outlined text-muted-light dark:text-muted-dark'>delete</span>
                    </button>
                </form>
            </div>
        </td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='5' class='p-4 text-sm text-muted-light dark:text-muted-dark'>No hay galpones registrados.</td></tr>";
}
?>
</tbody>
</table>
</div>

</section>
</div>
</main>


<script src="../../sidebar.js"></script>
<script>
function toggleModal(id) {
    document.getElementById(id).classList.toggle('hidden');
}

document.getElementById('btn-add-galpon').addEventListener('click', () => {
    toggleModal('modal-add');
});

function abrirEditar(id, nombre, ubicacion, capacidad, estado) {
    document.getElementById('modal-edit').classList.remove('hidden');
    document.getElementById('edit-id').value = id;
    document.getElementById('edit-nombre').value = nombre;
    document.getElementById('edit-ubicacion').value = ubicacion;
    document.getElementById('edit-capacidad').value = capacidad;
    document.getElementById('edit-estado').value = estado;
}

const searchInput = document.querySelector('#search-input');
const estadoSelect = document.querySelector('#estado-select');
const tableRows = document.querySelectorAll('tbody tr[data-galpon]');

function filtrarGalpones() {
    const texto = searchInput.value.toLowerCase();
    const estado = estadoSelect.value.toLowerCase();

    tableRows.forEach(row => {
        const nombre = row.dataset.nombre.toLowerCase();
        const estadoFila = row.dataset.estado.toLowerCase();
        const coincideTexto = nombre.includes(texto);
        const coincideEstado = estado === '' || estado === estadoFila;
        row.style.display = coincideTexto && coincideEstado ? '' : 'none';
    });
}

searchInput.addEventListener('input', filtrarGalpones);
estadoSelect.addEventListener('change', filtrarGalpones);
</script>

</body>
</html>
