<?php
include '../../../Sesion/config.php';

$id = $_POST['id'] ?? null;
$rol = $_POST['rol'] ?? null;

if(!$id || !$rol){
    echo json_encode(['success'=>false,'error'=>'Faltan datos']);
    exit;
}

$sql = "UPDATE usuarios SET rol=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si",$rol,$id);

if($stmt->execute()){
    echo json_encode(['success'=>true,'rol'=>$rol]);
} else {
    echo json_encode(['success'=>false,'error'=>$stmt->error]);
}
