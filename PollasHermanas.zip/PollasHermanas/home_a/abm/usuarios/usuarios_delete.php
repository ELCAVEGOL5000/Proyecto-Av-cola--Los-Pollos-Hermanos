<?php
include '../../../Sesion/config.php';

if(isset($_POST['id'])){
    $id = intval($_POST['id']);
    $sql = "DELETE FROM usuarios WHERE id=$id";
    if($conn->query($sql)){
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false, 'error'=>$conn->error]);
    }
    exit;
}
?>
