<?php
require_once '../../Sesion/config.php';

$where = [];
$params = [];

if (!empty($_GET['codigo'])) {
    $where[] = "codigo_lote LIKE ?";
    $params[] = "%" . $_GET['codigo'] . "%";
}

if (!empty($_GET['estado'])) {
    $where[] = "estado = ?";
    $params[] = $_GET['estado'];
}

if (!empty($_GET['fecha'])) {
    $where[] = "fecha_inicio = ?";
    $params[] = $_GET['fecha'];
}

$sql = "SELECT id, codigo_lote, tipo, cantidad, fecha_inicio, estado FROM lotes";

if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY fecha_inicio DESC";

$stmt = $conn->prepare($sql);

if ($params) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
  <link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter:wght@400;500;700;900" onload="this.rel='stylesheet'" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
  <title>Gestión Lotes</title>
  <link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": "#f5e3b3",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "subtle-light": "#dee5dc",
            "subtle-dark": "#2a3628",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49f",
          },
          fontFamily: { "display": ["Inter"] },
          borderRadius: { "DEFAULT": "0.5rem", "lg": "0.75rem", "xl": "1rem", "full": "9999px" },
        },
      },
    }
  </script>
  <style>
    .modal {
  transition: opacity 0.3s ease;
}
.modal-hidden {
  opacity: 0;
  pointer-events: none;
}
.modal-visible {
  opacity: 1;
  pointer-events: auto;
}
  </style>
  <link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../contacto/servicios.php">Servicios</a></li>
      <li><a href="../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">Sky Line <span class="corp">Corp</span></span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="lotes.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>


<main class="flex-1 p-8">
<div class="max-w-7xl mx-auto">

<h1 class="text-3xl font-bold">Gestión ABM de Lotes</h1>
<p class="text-muted-light dark:text-muted-dark">Gestiona de forma completa los lotes de aves.</p>

<section>
<div class="mb-6 border-b border-subtle-light dark:border-subtle-dark">
<nav aria-label="Tabs" class="flex gap-6 -mb-px">
  <a href="lotes.php">
    <button class="px-1 py-4 border-b-2 border-primary text-primary font-medium text-sm">Lotes</button>
  </a>
  <a href="galpones.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Galpones</button>
  </a>
  <a href="insumos.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Insumos</button>
  </a>
  <a href="usuarios.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Usuarios</button>
  </a>
</nav>
</div>

<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
  <div class="flex gap-2 flex-wrap">
    <div class="relative">
      <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted-light dark:text-muted-dark">search</span>
      <input
        type="text"
        name="codigo"
        id="codigo"
        value="<?= htmlspecialchars($_GET['codigo'] ?? '') ?>"
        placeholder="Buscar por código..."
        class="pl-10 pr-4 py-2 w-48 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm"
      />
    </div>
    <select
      name="estado"
      id="estado"
      class="w-40 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm"
    >
      <option value="">Filtrar por estado</option>
      <option value="activo" <?= (($_GET['estado'] ?? '') === 'Activo') ? 'selected' : '' ?>>Activo</option>
      <option value="inactivo" <?= (($_GET['estado'] ?? '') === 'Finalizado') ? 'selected' : '' ?>>Inactivo</option>
    </select>
    <input
      type="date"
      name="fecha"
      id="fecha"
      value="<?= htmlspecialchars($_GET['fecha'] ?? '') ?>"
      class="w-40 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm text-muted-light dark:text-muted-dark"
    />
  </div>

  <button id="btn-crear-lote" class="flex items-center justify-center rounded-DEFAULT h-10 px-6 bg-primary text-background-dark font-bold text-sm transition-transform hover:scale-105 w-full md:w-auto">
  <span class="material-symbols-outlined mr-2">add</span>
  <span>Crear Nuevo Lote</span>
</button>

<!-- Modal -->
<div id="modal-lote" class="fixed inset-0 flex items-center justify-center bg-black/50 opacity-0 pointer-events-none transition-opacity">
  <div class="bg-background-light dark:bg-subtle-dark rounded-DEFAULT p-6 w-full max-w-md relative">
    <h2 class="text-xl font-bold mb-4">Crear Nuevo Lote</h2>
    <form id="form-crear-lote">
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Código del Lote</label>
        <input type="text" name="codigo_lote" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Tipo de Ave</label>
        <input type="text" name="tipo" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Cantidad Inicial</label>
        <input type="number" name="cantidad" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Fecha de Inicio</label>
        <input type="date" name="fecha_inicio" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Estado</label>
        <select name="estado" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
          <option value="">Seleccionar estado</option>
          <option value="Activo">Activo</option>
          <option value="Pendiente">Pendiente</option>
          <option value="Finalizado">Finalizado</option>
        </select>
      </div>
      <div class="flex justify-end gap-2 mt-4">
        <button type="button" id="cerrar-modal" class="px-4 py-2 rounded-DEFAULT border border-subtle-light dark:border-subtle-dark">Cancelar</button>
        <button type="submit" class="px-4 py-2 rounded-DEFAULT bg-primary text-background-dark font-bold">Crear</button>
      </div>
    </form>
  </div>
</div>
</div>

<!-- Modal de Editar -->
<div id="modal-editar" class="fixed inset-0 flex items-center justify-center bg-black/50 opacity-0 pointer-events-none transition-opacity">
  <div class="bg-background-light dark:bg-subtle-dark rounded-DEFAULT p-6 w-full max-w-md relative">
    <h2 class="text-xl font-bold mb-4">Editar Lote</h2>
    <form id="form-editar-lote">
      <input type="hidden" name="id" id="edit-id">
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Código del Lote</label>
        <input type="text" name="codigo_lote" id="edit-codigo" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Tipo de Ave</label>
        <input type="text" name="tipo" id="edit-tipo" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Cantidad Inicial</label>
        <input type="number" name="cantidad" id="edit-cantidad" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Fecha de Inicio</label>
        <input type="date" name="fecha_inicio" id="edit-fecha" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
      </div>
      <div class="mb-3">
        <label class="block mb-1 text-sm font-medium">Estado</label>
        <select name="estado" id="edit-estado" class="w-full px-3 py-2 border border-subtle-light dark:border-subtle-dark rounded-DEFAULT" required>
          <option value="activo">Activo</option>
          <option value="inactivo">Inactivo</option>
        </select>
      </div>
      <div class="flex justify-end gap-2 mt-4">
        <button type="button" id="cerrar-modal-editar" class="px-4 py-2 rounded-DEFAULT border border-subtle-light dark:border-subtle-dark">Cancelar</button>
        <button type="submit" class="px-4 py-2 rounded-DEFAULT bg-primary text-background-dark font-bold">Guardar Cambios</button>
      </div>
    </form>
  </div>
</div>



<div class="overflow-x-auto bg-background-light dark:bg-subtle-dark rounded-lg border border-subtle-light dark:border-subtle-dark">
<table class="w-full text-left">
<thead class="border-b border-subtle-light dark:border-subtle-dark">
<tr>
  <th class="p-4 text-sm font-bold">Código del Lote</th>
  <th class="p-4 text-sm font-bold">Tipo de Ave</th>
  <th class="p-4 text-sm font-bold">Cantidad Inicial</th>
  <th class="p-4 text-sm font-bold">Fecha de Inicio</th>
  <th class="p-4 text-sm font-bold">Estado Actual</th>
  <th class="p-4 text-sm font-bold text-right">Acciones</th>
</tr>
</thead>
<tbody>

<?php


if ($result && $result->num_rows > 0):
  while ($row = $result->fetch_assoc()):
?>
<tr class="border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors">
  <td class="p-4 text-sm font-medium"><?= htmlspecialchars($row['codigo_lote']) ?></td>
  <td class="p-4 text-sm text-muted-light dark:text-muted-dark"><?= htmlspecialchars(ucfirst($row['tipo'])) ?></td>
  <td class="p-4 text-sm text-muted-light dark:text-muted-dark"><?= number_format($row['cantidad']) ?></td>
  <td class="p-4 text-sm text-muted-light dark:text-muted-dark"><?= date('d/m/Y', strtotime($row['fecha_inicio'])) ?></td>
  <td class="p-4 text-sm">
    <?php
      $estado = strtolower($row['estado']);
      $clase = ''; // 1. Inicializa la variable

// 2. Utiliza la estructura switch para la compatibilidad con versiones antiguas de PHP
switch ($estado) {
    case 'activo':
        $clase = 'bg-green-100 text-green-800';
        break;
    case 'pendiente':
        $clase = 'bg-yellow-100 text-yellow-800';
        break;
    case 'finalizado':
        $clase = 'bg-gray-100 text-gray-800';
        break;
    default:
        $clase = 'bg-gray-100 text-gray-800';
        break;
}
    ?>
    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= $clase ?>">
      <?= ucfirst($estado) ?>
    </span>
  </td>
  <td class="p-4 text-right">
    <div class="flex justify-end gap-2">
    <button class="btn-editar p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors"
        title="Editar" 
        data-id="<?= $row['id'] ?>"
        data-codigo="<?= htmlspecialchars($row['codigo_lote']) ?>"
        data-tipo="<?= htmlspecialchars($row['tipo']) ?>"
        data-cantidad="<?= htmlspecialchars($row['cantidad']) ?>"
        data-fecha="<?= htmlspecialchars($row['fecha_inicio']) ?>"
        data-estado="<?= htmlspecialchars($row['estado']) ?>">
  <span class="material-symbols-outlined text-muted-light dark:text-muted-dark">edit</span>
</button>

      <button class="p-2 rounded-full hover:bg-subtle-light dark:hover:bg-subtle-dark/70 transition-colors" title="Eliminar" onclick="eliminarLote(<?= $row['id'] ?>)">
        <span class="material-symbols-outlined text-muted-light dark:text-muted-dark">delete</span>
      </button>
    </div>
  </td>
</tr>
<?php
  endwhile;
else:
?>
<tr>
  <td colspan="6" class="p-4 text-center text-sm text-muted-light dark:text-muted-dark">No hay lotes registrados.</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</section>
</div>
</main>

<script src="../../sidebar.js"></script>
<script>
function eliminarLote(id) {
  if (confirm("¿Seguro que quieres eliminar este lote?")) {
    fetch('lotes/eliminar_lote.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'id=' + encodeURIComponent(id)
    })
    .then(res => res.text())
    .then(resp => {
      if (resp.trim() === 'success') {
        alert('Lote eliminado correctamente');
        filtrarTabla(); // refresca la tabla
      } else {
        alert('Error: ' + resp);
      }
    })
    .catch(err => alert('Error al eliminar: ' + err));
  }
}

const codigoInput = document.getElementById('codigo');
const estadoSelect = document.getElementById('estado');
const fechaInput = document.getElementById('fecha');
const tbody = document.querySelector('table tbody');

let timeout;

// Función que hace fetch al PHP y reemplaza el tbody
function filtrarTabla() {
  const codigo = codigoInput.value;
  const estado = estadoSelect.value;
  const fecha = fechaInput.value;

  const formData = new FormData();
  formData.append('codigo', codigo);
  formData.append('estado', estado);
  formData.append('fecha', fecha);

  fetch('lotes/filtrar_lotes.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.text())
  .then(html => {
    tbody.innerHTML = html;
  });
}

// Debounce para evitar demasiadas peticiones mientras escribes
function debounceFiltrar() {
  clearTimeout(timeout);
  timeout = setTimeout(filtrarTabla, 300); // 300ms de espera
}

// Eventos
codigoInput.addEventListener('input', debounceFiltrar);
estadoSelect.addEventListener('change', filtrarTabla);
fechaInput.addEventListener('change', filtrarTabla);

const btnCrear = document.getElementById('btn-crear-lote');
const modal = document.getElementById('modal-lote');
const btnCerrar = document.getElementById('cerrar-modal');
const formCrear = document.getElementById('form-crear-lote');

// Función para abrir modal
function abrirModal() {
  modal.classList.remove('opacity-0', 'pointer-events-none');
  modal.classList.add('opacity-100');
}

// Función para cerrar modal
function cerrarModal() {
  modal.classList.remove('opacity-100'); 
  modal.classList.add('opacity-0', 'pointer-events-none');
  formCrear.reset(); 
}

btnCrear.addEventListener('click', abrirModal);

btnCerrar.addEventListener('click', cerrarModal);

modal.addEventListener('click', (e) => {
  if (e.target === modal) { 
    cerrarModal();
  }
});

formCrear.addEventListener('submit', function(e) {
  e.preventDefault();

  const formData = new FormData(formCrear);

  fetch('lotes/crear_lote.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      alert('Lote creado correctamente');
      cerrarModal(); 
      filtrarTabla(); 
    } else {
      alert('Error: ' + data.message);
    }
  })
  .catch(err => alert('Error: ' + err));
});

// ----- EDITAR LOTE -----
const modalEditar = document.getElementById('modal-editar');
const formEditar = document.getElementById('form-editar-lote');
const cerrarEditarBtn = document.getElementById('cerrar-modal-editar');

document.addEventListener('click', (e) => {
  const btn = e.target.closest('.btn-editar');
  if (btn) {
    // Cargar datos en el formulario
    document.getElementById('edit-id').value = btn.dataset.id;
    document.getElementById('edit-codigo').value = btn.dataset.codigo;
    document.getElementById('edit-tipo').value = btn.dataset.tipo;
    document.getElementById('edit-cantidad').value = btn.dataset.cantidad;
    document.getElementById('edit-fecha').value = btn.dataset.fecha;
    document.getElementById('edit-estado').value = btn.dataset.estado;

    // Mostrar modal
    modalEditar.classList.remove('opacity-0', 'pointer-events-none');
    modalEditar.classList.add('opacity-100');
  }
});

// Cerrar modal
cerrarEditarBtn.addEventListener('click', () => {
  modalEditar.classList.remove('opacity-100');
  modalEditar.classList.add('opacity-0', 'pointer-events-none');
});

// Guardar cambios
formEditar.addEventListener('submit', (e) => {
  e.preventDefault();
  const formData = new FormData(formEditar);

  fetch('lotes/editar_lote.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
  alert('Lote actualizado correctamente');
  modalEditar.classList.remove('opacity-100');
  modalEditar.classList.add('opacity-0', 'pointer-events-none');
  formEditar.reset();
  filtrarTabla();
}
 else {
      alert('Error: ' + data.message);
    }
  })
  .catch(err => alert('Error: ' + err));
});


</script>


</body>
</html>
