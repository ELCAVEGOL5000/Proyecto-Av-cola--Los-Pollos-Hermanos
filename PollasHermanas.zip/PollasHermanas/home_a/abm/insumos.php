<?php

require_once '../../Sesion/config.php';

$sql = "SELECT * FROM inventario ORDER BY fecha_vencimiento ASC";
$result = $conn->query($sql);

// Función para mostrar el estado de vencimiento con estilos
function estadoVencimiento($fechaVencimiento) {
    if (!$fechaVencimiento) return "";

    $fechaHoy = new DateTime();
    $fechaVen = new DateTime($fechaVencimiento);
    $diff = $fechaHoy->diff($fechaVen);
    $dias = (int)$diff->format("%r%a"); // días relativos (negativos si ya venció)

    if ($dias < 0) {
        // Vencido
        return "<span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800'>{$fechaVen->format('d/m/Y')}</span>";
    } elseif ($dias <= 30) {
        // Próximo a vencer (menos de 30 días)
        return "<span class='inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800'>{$fechaVen->format('d/m/Y')}</span>";
    } else {
        // Vigente
        return $fechaVen->format('d/m/Y');
    }
}

// Función para capitalizar tipo (ejemplo: alimento => Alimento)
function tipoFormateado($tipo) {
    $mapaTipos = [
        'alimento' => 'Alimento',
        'medicamento' => 'Medicina',
        'otro' => 'Otro',
    ];
    return $mapaTipos[strtolower($tipo)] ?? ucfirst($tipo);
}

?>

<!DOCTYPE html>
<html lang="es"><head>
<meta charset="utf-8"/>
<meta charset="utf-8"/>
<link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
<link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Inter:wght@400;500;700;900" onload="this.rel='stylesheet'" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>
<title>Gestion Insumos</title>
<link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "primary": "#f5e3b3",
            "background-light": "#f6f8f6",
            "background-dark": "#152111",
            "foreground-light": "#131711",
            "foreground-dark": "#e3e4e3",
            "subtle-light": "#dee5dc",
            "subtle-dark": "#2a3628",
            "muted-light": "#6c8764",
            "muted-dark": "#a2b49f",
          },
          fontFamily: {
            "display": ["Inter"]
          },
          borderRadius: {
            "DEFAULT": "0.5rem",
            "lg": "0.75rem",
            "xl": "1rem",
            "full": "9999px"
          },
        },
      },
    }
  </script>
  <link rel="stylesheet" href="../../home_o/produccion/produccion.css">
</head>
<body>

<header>
  <div class="logo-header">
    <div class="icon"></div>
    Sky Line
    <span class="corp">Corp</span>
  </div>

  <nav>
    <ul>
      <li><a href="../../contacto/servicios.php">Servicios</a></li>
      <li><a href="../../contacto/nosotros.php">Nosotros</a></li>
      <li><a href="../../contacto/contacto.php">Contacto</a></li>
    </ul>
  </nav>
</header>

<button id="menu-toggle" aria-label="Abrir menú">
  <span class="material-symbols-outlined">menu</span>
</button>

<div id="sidebar">
  <div>
    <div class="logo">
      <div class="icon"></div>
      <div class="textos">
        <span class="main-text">
          Sky Line <span class="corp">Corp</span>
        </span>
      </div>
    </div>
    <ul>
      <li class="active"><a href="insumos.php"><span class="material-symbols-outlined">list_alt</span> Gestion ABM</a></li>
      <li><a href="reportes.php"><span class="material-symbols-outlined">assessment</span> Reportes</a></li>
    </ul>
  </div>
  <div class="footer">
    <ul>
      <li><a class="cerrarSesion" href="../../logout.php"><span class="material-symbols-outlined">logout</span> Cerrar Sesión</a></li>
    </ul>
  </div>
</div>



<main class="flex-1 p-8">

<div class="max-w-7xl mx-auto">
<h1 class="text-3xl font-bold">Gestión ABM de Insumos</h1>
<p class="text-muted-light dark:text-muted-dark">Gestiona de forma completa el inventario de insumos.</p>

<section>
<div class="mb-6 border-b border-subtle-light dark:border-subtle-dark">
<nav aria-label="Tabs" class="flex gap-6 -mb-px">

<a href="lotes.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Lotes</button>
</a>
<a href="galpones.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Galpones</button>
</a>
<a href="insumos.php">
    <button class="px-1 py-4 border-b-2 border-primary text-primary font-medium text-sm">Insumos</button>
</a>
<a href="usuarios.php">
    <button class="px-1 py-4 border-b-2 border-transparent text-muted-light dark:text-muted-dark hover:text-foreground-light dark:hover:text-foreground-dark hover:border-subtle-light dark:hover:border-subtle-dark text-sm transition-colors">Usuarios</button>
</a>


</nav>
</div>
<div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
<div class="flex gap-2 flex-wrap">
<div class="relative">
<span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted-light dark:text-muted-dark">search</span>
<input id="search-input" class="pl-10 pr-4 py-2 w-64 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm" placeholder="Buscar por nombre, tipo..." type="text"/>
</div>
<select id="tipo-filter" class="w-48 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm">
<option value="">Filtrar por tipo</option>
  <option value="alimento">Alimento</option>
  <option value="medicamento">Medicina</option>
  <option value="otro">Otro</option>
</select>
<select id="estado-filter" class="w-48 bg-background-light dark:bg-subtle-dark border border-subtle-light dark:border-subtle-dark rounded-DEFAULT focus:ring-primary focus:border-primary text-sm">
<option>Estado de vencimiento</option>
<option>Vigente</option>
<option>Próximo a vencer</option>
<option>Vencido</option>
</select>
</div>
<button id="add-insumo-btn" class="flex items-center justify-center rounded-DEFAULT h-10 px-6 bg-primary text-background-dark font-bold text-sm transition-transform hover:scale-105 w-full md:w-auto">
<span class="material-symbols-outlined mr-2">add</span>
<span>Añadir Nuevo Insumo</span>
</button>
</div>
<div class="overflow-x-auto bg-background-light dark:bg-subtle-dark rounded-lg border border-subtle-light dark:border-subtle-dark">
<table class="w-full text-left">
<thead class="border-b border-subtle-light dark:border-subtle-dark">
<tr>
<th class="p-4 text-sm font-bold">Nombre</th>
<th class="p-4 text-sm font-bold">Tipo</th>
<th class="p-4 text-sm font-bold">Cantidad Actual</th>
<th class="p-4 text-sm font-bold">Unidad</th>
<th class="p-4 text-sm font-bold">Fecha de Ingreso</th>
<th class="p-4 text-sm font-bold">Fecha de Vencimiento</th>
</tr>
</thead>
<tbody>
<?php
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr class='border-b border-subtle-light dark:border-subtle-dark last:border-b-0 hover:bg-subtle-light/30 dark:hover:bg-subtle-dark/50 transition-colors'>";
        echo "<td class='p-4 text-sm font-medium'>" . htmlspecialchars($row['nombre']) . "</td>";
        echo "<td class='p-4 text-sm text-muted-light dark:text-muted-dark'>" . tipoFormateado($row['tipo']) . "</td>";
        echo "<td class='p-4 text-sm text-muted-light dark:text-muted-dark'>" . htmlspecialchars($row['cantidad']) . "</td>";
        echo "<td class='p-4 text-sm text-muted-light dark:text-muted-dark'>" . htmlspecialchars($row['unidad']) . "</td>";
        echo "<td class='p-4 text-sm text-muted-light dark:text-muted-dark'>" . date("d/m/Y", strtotime($row['fecha_ingreso'])) . "</td>";
        echo "<td class='p-4 text-sm text-muted-light dark:text-muted-dark'>" . estadoVencimiento($row['fecha_vencimiento']) . "</td>";
        echo "<td class='p-4 text-right'>";
        echo "<div class='flex justify-end gap-2'>";
        echo "</div>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7' class='p-4 text-center text-muted-light dark:text-muted-dark'>No hay insumos registrados.</td></tr>";
}
?>
</tbody>
</table>
</div>
</section>

<!-- Modal de añadir insumo -->
<div id="add-insumo-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
  <div class="bg-background-light dark:bg-subtle-dark rounded-lg p-6 w-96">
    <h2 class="text-lg font-bold mb-4">Añadir Nuevo Insumo</h2>
    <form id="add-insumo-form" method="POST" action="insumos/insumos_add.php">
      <div class="mb-3">
        <label class="block text-sm font-medium">Nombre</label>
        <input type="text" name="nombre" required class="w-full p-2 border rounded"/>
      </div>
      <div class="mb-3">
        <label class="block text-sm font-medium">Tipo</label>
        <select name="tipo" required class="w-full p-2 border rounded">
          <option value="alimento">Alimento</option>
          <option value="medicamento">Medicina</option>
          <option value="otro">Otro</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="block text-sm font-medium">Cantidad</label>
        <input type="number" step="0.01" name="cantidad" required class="w-full p-2 border rounded"/>
      </div>
      <div class="mb-3">
        <label class="block text-sm font-medium">Unidad</label>
        <input type="text" name="unidad" required class="w-full p-2 border rounded"/>
      </div>
      <div class="mb-3">
        <label class="block text-sm font-medium">Fecha de Ingreso</label>
        <input type="date" name="fecha_ingreso" required class="w-full p-2 border rounded"/>
      </div>
      <div class="mb-3">
        <label class="block text-sm font-medium">Fecha de Vencimiento</label>
        <input type="date" name="fecha_vencimiento" class="w-full p-2 border rounded"/>
      </div>
      <div class="flex justify-end gap-2 mt-4">
        <button type="button" id="close-modal" class="px-4 py-2 border rounded">Cancelar</button>
        <button type="submit" class="px-4 py-2 bg-primary text-background-dark rounded">Añadir</button>
      </div>
    </form>
  </div>
</div>



</div>
</main>

<script src="../../sidebar.js"></script>


<script>
const searchInput = document.getElementById('search-input');
const tipoFilter = document.getElementById('tipo-filter');
const estadoFilter = document.getElementById('estado-filter');
const table = document.querySelector('table tbody');

function getEstadoVencimiento(fechaVencimiento) {
  if (!fechaVencimiento) return '';
  const hoy = new Date();
  const ven = new Date(fechaVencimiento.split('/').reverse().join('-'));
  const diff = (ven - hoy) / (1000 * 60 * 60 * 24);
  if (diff < 0) return 'Vencido';
  else if (diff <= 30) return 'Próximo a vencer';
  else return 'Vigente';
}

function filtrarTabla() {
  const searchText = searchInput.value.toLowerCase();
  const tipoValue = tipoFilter.value;
  const estadoValue = estadoFilter.value;

  const filas = table.querySelectorAll('tr');

  filas.forEach(fila => {
    const nombre = fila.cells[0].textContent.toLowerCase();
    const tipo = fila.cells[1].textContent;
    const fechaVen = fila.cells[5].textContent; // la celda de fecha de vencimiento
    const estado = getEstadoVencimiento(fechaVen);

    const coincideSearch = nombre.includes(searchText) || tipo.toLowerCase().includes(searchText);
    const coincideTipo = tipoValue === '' || tipo === tipoValue;
    const coincideEstado = estadoValue === '' || estado === estadoValue;

    if (coincideSearch && coincideTipo && coincideEstado) {
      fila.style.display = '';
    } else {
      fila.style.display = 'none';
    }
  });
}

searchInput.addEventListener('input', filtrarTabla);
tipoFilter.addEventListener('change', filtrarTabla);
estadoFilter.addEventListener('change', filtrarTabla);

const addBtn = document.getElementById('add-insumo-btn'); // ahora sí lo encuentra
const modal = document.getElementById('add-insumo-modal');
const closeModal = document.getElementById('close-modal');

addBtn.addEventListener('click', () => modal.classList.remove('hidden'));
closeModal.addEventListener('click', () => modal.classList.add('hidden'));

</script>


</body>
</html>