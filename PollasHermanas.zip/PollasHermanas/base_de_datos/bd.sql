DROP DATABASE IF EXISTS pollos_hermanos_db;

CREATE DATABASE pollos_hermanos_db;

USE pollos_hermanos_db;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'supervisor', 'operario','ninguno') DEFAULT 'ninguno',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de lotes de aves
CREATE TABLE IF NOT EXISTS lotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_lote VARCHAR(50) NOT NULL UNIQUE,
    tipo VARCHAR(255) NOT NULL,
    cantidad INT NOT NULL,
    fecha_inicio DATE NOT NULL,
    estado ENUM('activo', 'inactivo') DEFAULT 'activo'
);

-- Alimentación de los lotes
CREATE TABLE IF NOT EXISTS alimentacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lote_id INT NOT NULL,
    fecha DATE NOT NULL,
    tipo_alimento VARCHAR(100) NOT NULL,
    cantidad_kg DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (lote_id) REFERENCES lotes(id) ON DELETE CASCADE
);

-- Control de salud
CREATE TABLE IF NOT EXISTS salud (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lote_id INT NOT NULL,
    fecha DATE NOT NULL,
    tipo_control VARCHAR(100) NOT NULL,
    descripcion TEXT,
    resultado ENUM('saludable', 'enfermo', 'vacunado') NOT NULL,
    FOREIGN KEY (lote_id) REFERENCES lotes(id) ON DELETE CASCADE
);

-- Producción (huevos o engorde de pollos)
    CREATE TABLE IF NOT EXISTS produccion (
        id INT AUTO_INCREMENT PRIMARY KEY,
        lote_id INT NOT NULL,
        fecha DATE NOT NULL,
        tipo ENUM('huevos', 'pollos') NOT NULL,
        cantidad INT NOT NULL,
        FOREIGN KEY (lote_id) REFERENCES lotes(id) ON DELETE CASCADE
    );

-- Inventario de insumos
CREATE TABLE IF NOT EXISTS inventario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    tipo ENUM('alimento', 'medicamento', 'otro') NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    unidad VARCHAR(50) NOT NULL, -- Ejemplo: kg, litros, unidades
    fecha_ingreso DATE NOT NULL,
    fecha_vencimiento DATE
);

-- Distribución / Logística
CREATE TABLE IF NOT EXISTS distribucion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produccion_id INT NOT NULL,
    fecha_envio DATE NOT NULL,
    destino VARCHAR(200) NOT NULL,
    cantidad INT NOT NULL,
    transportista VARCHAR(100),
    FOREIGN KEY (produccion_id) REFERENCES produccion(id) ON DELETE CASCADE
);

-- Registro de actividades de usuarios
CREATE TABLE IF NOT EXISTS actividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    accion VARCHAR(200) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS galpones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    ubicacion VARCHAR(200) NOT NULL,
    capacidad INT NOT NULL, -- Capacidad máxima en unidades de aves
    lote_asignado_id INT DEFAULT NULL, -- Relación opcional con un lote activo
    estado ENUM('activo', 'inactivo', 'mantenimiento') DEFAULT 'activo',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lote_asignado_id) REFERENCES lotes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS galpones_lotes (
    galpon_id INT,
    lote_id INT,
    PRIMARY KEY (galpon_id, lote_id),
    FOREIGN KEY (galpon_id) REFERENCES galpones(id) ON DELETE CASCADE,
    FOREIGN KEY (lote_id) REFERENCES lotes(id) ON DELETE CASCADE
);

