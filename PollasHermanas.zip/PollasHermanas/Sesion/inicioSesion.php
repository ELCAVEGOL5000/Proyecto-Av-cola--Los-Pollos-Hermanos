<?php

session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? ''
];

$activeForm = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return empty($error) ? "" : "<p class='error-mensaje'>$error</p>";
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : "";
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inicio de sesion</title>
    <link rel="stylesheet" href="inicioSesion.css">
</head>
<body>

    <audio id="miAudio" loop>
        <source src="../audio/La Gallina Turuleca - Canciones de la Granja de Zenón 1.mp3" type="audio/mpeg">
    </audio>

    <div class="logo">
        <div class="icon" id="icon"></div>
            Sky Line
        <span class="corp">Corp</span>
    </div>


    <div class="contenido">
        <!-- Inicio de Sesion -->

        <div class="form-box <?= isActiveForm('login', $activeForm); ?>" id="login-form">
            <form action="login_register.php" method="post" >
                <h2>Inicio de Sesión</h2>
                <?= showError($errors['login']); ?>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="contrasena" placeholder="Contraseña" required>
                <button type="submit" name="login">Iniciar Sesion</button>
                <p>¿No tienes una cuenta? <a href="#" onclick="showForm('register-form')">Registrarse</a></p>
            </form>
        </div>

        <!-- registrarse -->
        
        <div class="form-box <?= isActiveForm('register', $activeForm); ?>" id="register-form">
            <form action="login_register.php" method="post">
                <h2>Registro</h2>
                <?= showError($errors['register']); ?>
                <input type="text" name="name" placeholder="Nombre" required>
                <input type="text" name="apellido" placeholder="Apellido" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="contrasena" placeholder="Contraseña" required>
                <button type="submit" name="register">Registrarse</button>
                <p>¿Ya tienes una cuenta? <a href="#" onclick="showForm('login-form')">Iniciar Sesion</a></p>
            </form>
        </div>
    </div>
    <script src="audio.js"></script>
    <script>
        function showForm(formId){
        document.querySelectorAll(".form-box").forEach(form => form.classList.remove("active"));
        document.getElementById(formId).classList.add("active");
        }
    </script>
</body>
</html>