<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['error' => 'No logueado']);
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

$query = "SELECT rol FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($rol);
$stmt->fetch();
$stmt->close();

echo json_encode(['rol' => $rol]);