const logo = document.getElementById('icon');
const audio = document.getElementById('miAudio');

logo.addEventListener('click', () => {
  if (audio.paused) {
    audio.play();
  } else {
    audio.pause();
  }
});