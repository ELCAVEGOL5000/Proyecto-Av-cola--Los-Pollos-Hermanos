<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: inicioSesion.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Esperando asignación de rol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 100px;
        }
    </style>
</head>
<body>
    <h2>⏳ Esperando asignación de rol...</h2>
    <p>Un administrador debe asignarte un rol para continuar.</p>
    <p>Esta página se actualizará automáticamente.</p>

    <script>
        function verificarRol() {
            fetch('verificar_rol.php')
                .then(response => response.json())
                .then(data => {
                    if (data.rol && data.rol !== 'ninguno') {
                        switch (data.rol) {
                            case 'operario':
                                window.location.href = '../home_o/dashboard/dashboard.php';
                                break;
                            case 'supervisor':
                                window.location.href = '../home_s/lotes/lotes.php';
                                break;
                            case 'admin':
                                window.location.href = '../home_a/abm/lotes.php';
                                break;
                        }
                    }
                })
                .catch(error => console.error('Error al verificar rol:', error));
        }

        setInterval(verificarRol, 5000); // consulta cada 5 segundos
    </script>
</body>
</html>