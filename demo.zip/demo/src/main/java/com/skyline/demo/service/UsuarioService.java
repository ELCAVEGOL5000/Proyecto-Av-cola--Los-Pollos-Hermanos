package com.skyline.demo.service;

import com.skyline.demo.model.Usuario;
import com.skyline.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> obtenerUsuarioPorId(Long id) {
        return usuarioRepository.findById(id);
    }

    public Usuario crearUsuario(Usuario usuario) {
        if (usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            throw new IllegalArgumentException("El email " + usuario.getEmail() + " ya está en uso.");
        }
        return usuarioRepository.save(usuario);
    }

    public Optional<Usuario> actualizarUsuario(Long id, Usuario usuarioDetails) {
        return usuarioRepository.findById(id)
                .map(usuarioExistente -> {
                    if (!usuarioExistente.getEmail().equals(usuarioDetails.getEmail()) && usuarioRepository.findByEmail(usuarioDetails.getEmail()).isPresent()) {
                        throw new IllegalArgumentException("El email " + usuarioDetails.getEmail() + " ya está en uso por otro usuario.");
                    }
                    
                    usuarioExistente.setNombre(usuarioDetails.getNombre());
                    usuarioExistente.setApellido(usuarioDetails.getApellido());
                    usuarioExistente.setEmail(usuarioDetails.getEmail());
                    usuarioExistente.setPassword(usuarioDetails.getPassword()); 
                    usuarioExistente.setRol(usuarioDetails.getRol());
                    return usuarioRepository.save(usuarioExistente);
                });
    }

    public boolean eliminarUsuario(Long id) {
        if (usuarioRepository.existsById(id)) {
            usuarioRepository.deleteById(id);
            return true;
        }
        return false;
    }
}