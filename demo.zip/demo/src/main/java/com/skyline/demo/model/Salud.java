package com.skyline.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

@Entity
@Table(name = "salud")
public class Salud {

    public enum ResultadoControl {
        saludable, 
        enfermo, 
        vacunado
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lote_id", nullable = false)
    @NotNull(message = "El ID del lote es obligatorio.")
    private Long loteId;

    @Column(name = "fecha", nullable = false)
    @NotNull(message = "La fecha es obligatoria.")
    @PastOrPresent(message = "La fecha de control/vacunación no puede ser futura.")
    private LocalDate fecha;

    @Column(name = "tipo_control", nullable = false, length = 100)
    @NotNull(message = "El tipo de control es obligatorio.")
    @Size(min = 3, max = 100, message = "El tipo de control debe tener entre 3 y 100 caracteres.")
    private String tipoControl;

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;

    @Enumerated(EnumType.STRING)
    @Column(name = "resultado", nullable = false)
    @NotNull(message = "El resultado del control es obligatorio.")
    private ResultadoControl resultado;

    public Salud() {
    }

    public Salud(Long loteId, LocalDate fecha, String tipoControl, String descripcion, ResultadoControl resultado) {
        this.loteId = loteId;
        this.fecha = fecha;
        this.tipoControl = tipoControl;
        this.descripcion = descripcion;
        this.resultado = resultado;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLoteId() {
        return loteId;
    }

    public void setLoteId(Long loteId) {
        this.loteId = loteId;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getTipoControl() {
        return tipoControl;
    }

    public void setTipoControl(String tipoControl) {
        this.tipoControl = tipoControl;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public ResultadoControl getResultado() {
        return resultado;
    }

    public void setResultado(ResultadoControl resultado) {
        this.resultado = resultado;
    }
}