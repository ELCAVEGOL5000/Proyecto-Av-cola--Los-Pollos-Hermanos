package com.skyline.demo.controller;

import com.skyline.demo.model.Galpon;
import com.skyline.demo.service.GalponService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/galpones")
public class GalponController {

    private final GalponService galponService;

    @Autowired
    public GalponController(GalponService galponService) {
        this.galponService = galponService;
    }

    @GetMapping
    public ResponseEntity<List<Galpon>> obtenerTodosLosGalpones() {
        List<Galpon> galpones = galponService.obtenerTodosLosGalpones();
        return ResponseEntity.ok(galpones);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Galpon> obtenerGalponPorId(@PathVariable Long id) {
        Optional<Galpon> galpon = galponService.obtenerGalponPorId(id);
        return galpon
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Galpon> crearGalpon(@Valid @RequestBody Galpon galpon) {
        Galpon nuevoGalpon = galponService.crearGalpon(galpon);
        return new ResponseEntity<>(nuevoGalpon, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Galpon> actualizarGalpon(@PathVariable Long id, @Valid @RequestBody Galpon galponDetails) {
        Optional<Galpon> galponActualizado = galponService.actualizarGalpon(id, galponDetails);
        return galponActualizado
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarGalpon(@PathVariable Long id) {
        if (galponService.eliminarGalpon(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}