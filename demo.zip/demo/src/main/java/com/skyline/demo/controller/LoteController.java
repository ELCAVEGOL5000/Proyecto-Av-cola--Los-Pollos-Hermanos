package com.skyline.demo.controller;

import com.skyline.demo.model.Lote;
import com.skyline.demo.repository.LoteRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController 
@RequestMapping("/api/lotes") 
public class LoteController {

    @Autowired 
    private LoteRepository loteRepository;

    @PostMapping
    public ResponseEntity<Lote> registrarLote(@Valid @RequestBody Lote lote) {
        Lote nuevoLote = loteRepository.save(lote);
        return new ResponseEntity<>(nuevoLote, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<Iterable<Lote>> obtenerTodos() {
        return ResponseEntity.ok(loteRepository.findAll()); // 200 OK
    }

    // Obtener por ID
    @GetMapping("/{id}")
    public ResponseEntity<Lote> obtenerLotePorId(@PathVariable Long id) {
        return loteRepository.findById(id)
                // Si lo encuentra, devuelve 200 OK
                .map(ResponseEntity::ok)
                // Si no lo encuentra, devuelve 404 Not Found
                .orElse(ResponseEntity.notFound().build()); 
    }

    @PutMapping("/{id}")
    public ResponseEntity<Lote> actualizarLote(@PathVariable Long id, @Valid @RequestBody Lote loteDetails) {
        return loteRepository.findById(id)
                .map(loteExistente -> {
                    // Actualizar todos los campos
                    loteExistente.setCodigoLote(loteDetails.getCodigoLote());
                    loteExistente.setTipo(loteDetails.getTipo());
                    loteExistente.setCantidad(loteDetails.getCantidad());
                    loteExistente.setFechaInicio(loteDetails.getFechaInicio());
                    loteExistente.setEstado(loteDetails.getEstado()); 

                    Lote loteActualizado = loteRepository.save(loteExistente);
                    return ResponseEntity.ok(loteActualizado); // 200 OK
                })
                // Si el ID no existe, devuelve 404 Not Found
                .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarLote(@PathVariable Long id) {
        // Verifica si el lote existe
        if (loteRepository.existsById(id)) {
            loteRepository.deleteById(id);
            // 204 No Content
            return ResponseEntity.noContent().build(); 
        } else {
            // devuelve 404 Not Found
            return ResponseEntity.notFound().build();
        }
    }
}