package com.skyline.demo.controller;

import com.skyline.demo.model.Usuario;
import com.skyline.demo.repository.UsuarioRepository;
import com.skyline.demo.exception.EmailDuplicadoException; // Importación de la excepción personalizada
import com.skyline.demo.model.Rol; 
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    public UsuarioController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Registrar un nuevo usuario.
     * * @param usuario El objeto Usuario a ser creado.
     * @return El usuario creado con HttpStatus 201 (Created).
     * @throws EmailDuplicadoException Si el email ya está registrado.
     */
    @PostMapping
    public ResponseEntity<Usuario> crearUsuario(@Valid @RequestBody Usuario usuario) {
        // Verificar si el email ya existe
        if (usuario.getEmail() != null && usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            throw new EmailDuplicadoException(usuario.getEmail());
        }

        if (usuario.getRol() == null) {
            usuario.setRol(Rol.NINGUNO);
        }
        
        Usuario nuevoUsuario = usuarioRepository.save(usuario);
        return new ResponseEntity<>(nuevoUsuario, HttpStatus.CREATED);
    }

    /**
     * Obtener todos los usuarios.
     * * @return Lista de todos los usuarios.
     */
    @GetMapping
    public List<Usuario> obtenerUsuarios() {
        return usuarioRepository.findAll();
    }

    /**
     * Obtener un usuario por ID.
     * * @param id El ID del usuario.
     * @return ResponseEntity con el usuario y HttpStatus 200, o HttpStatus 404.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> obtenerUsuarioPorId(@PathVariable Long id) {
        Optional<Usuario> usuario = usuarioRepository.findById(id);
        return usuario.map(ResponseEntity::ok)
                      .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * Actualizar un usuario existente.
     * * @param id El ID del usuario a actualizar.
     * @param detallesUsuario Los detalles actualizados del usuario.
     * @return El usuario actualizado con HttpStatus 200 (OK), o HttpStatus 404.
     * @throws EmailDuplicadoException Si el nuevo email ya está registrado por otro usuario.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> actualizarUsuario(@PathVariable Long id, @Valid @RequestBody Usuario detallesUsuario) {
        Optional<Usuario> usuarioExistente = usuarioRepository.findById(id);

        if (usuarioExistente.isPresent()) {
            Usuario usuario = usuarioExistente.get();
            
            // actualizar email
            String nuevoEmail = detallesUsuario.getEmail();
            if (nuevoEmail != null) {
                Optional<Usuario> usuarioConMismoEmail = usuarioRepository.findByEmail(nuevoEmail);
                
                // Si existe otro usuario con el mismo email y su ID no es el que estamos actualizando
                if (usuarioConMismoEmail.isPresent() && !usuarioConMismoEmail.get().getId().equals(id)) {
                    throw new EmailDuplicadoException(nuevoEmail);
                }
                usuario.setEmail(nuevoEmail);
            }

            usuario.setNombre(detallesUsuario.getNombre());
            usuario.setApellido(detallesUsuario.getApellido());
            
            if (detallesUsuario.getRol() != null) {
                usuario.setRol(detallesUsuario.getRol());
            }

            if (detallesUsuario.getPassword() != null && !detallesUsuario.getPassword().isEmpty()) {
                usuario.setPassword(detallesUsuario.getPassword());
            }

            Usuario usuarioActualizado = usuarioRepository.save(usuario);
            return ResponseEntity.ok(usuarioActualizado);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Eliminar un usuario por ID.
     * * @param id El ID del usuario a eliminar.
     * @return HttpStatus 204 (No Content) se elimina con éxito, o HttpStatus 404.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Long id) {
        if (usuarioRepository.existsById(id)) {
            usuarioRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}