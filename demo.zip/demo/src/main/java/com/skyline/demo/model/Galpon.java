package com.skyline.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "galpones")
public class Galpon {

    public enum EstadoGalpon {
        activo,
        inactivo,
        mantenimiento
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 100, unique = true)
    @NotBlank(message = "El nombre del galpón es obligatorio.")
    @Size(min = 3, max = 100, message = "El nombre debe tener entre 3 y 100 caracteres.")
    private String nombre;

    @Column(name = "ubicacion", nullable = false, length = 200)
    @NotBlank(message = "La ubicación es obligatoria.")
    @Size(max = 200, message = "La ubicación no puede exceder los 200 caracteres.")
    private String ubicacion;

    @Column(name = "capacidad", nullable = false)
    @NotNull(message = "La capacidad es obligatoria.")
    @Min(value = 1, message = "La capacidad debe ser al menos 1.")
    private Integer capacidad;

    @Column(name = "lote_asignado_id", nullable = true)
    private Long loteAsignadoId;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false, length = 50)
    @NotNull(message = "El estado es obligatorio.")
    private EstadoGalpon estado;

    @CreationTimestamp
    @Column(name = "creado_en", nullable = false, updatable = false)
    private LocalDateTime creadoEn;

    public Galpon() {
    }

    public Galpon(String nombre, String ubicacion, Integer capacidad, Long loteAsignadoId, EstadoGalpon estado) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.capacidad = capacidad;
        this.loteAsignadoId = loteAsignadoId;
        this.estado = estado;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Integer getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Integer capacidad) {
        this.capacidad = capacidad;
    }

    public Long getLoteAsignadoId() {
        return loteAsignadoId;
    }

    public void setLoteAsignadoId(Long loteAsignadoId) {
        this.loteAsignadoId = loteAsignadoId;
    }

    public EstadoGalpon getEstado() {
        return estado;
    }

    public void setEstado(EstadoGalpon estado) {
        this.estado = estado;
    }

    public LocalDateTime getCreadoEn() {
        return creadoEn;
    }

    public void setCreadoEn(LocalDateTime creadoEn) {
        this.creadoEn = creadoEn;
    }
}