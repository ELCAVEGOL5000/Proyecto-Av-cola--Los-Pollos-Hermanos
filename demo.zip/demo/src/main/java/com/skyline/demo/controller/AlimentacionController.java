package com.skyline.demo.controller;

import com.skyline.demo.model.Alimentacion;
import com.skyline.demo.service.AlimentacionService; // Importar el servicio
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/alimentacion")
public class AlimentacionController {

    private final AlimentacionService alimentacionService;

    @Autowired
    public AlimentacionController(AlimentacionService alimentacionService) {
        this.alimentacionService = alimentacionService;
    }

    // POST: Registrar nueva alimentación (Crea)
    @PostMapping
    public ResponseEntity<Alimentacion> registrarAlimentacion(@Valid @RequestBody Alimentacion alimentacion) {
        Alimentacion nuevoRegistro = alimentacionService.registrarAlimentacion(alimentacion);
        return new ResponseEntity<>(nuevoRegistro, HttpStatus.CREATED); // 201 Created
    }

    // GET: Obtener todos los registros de alimentación (Lee todos)
    @GetMapping
    public ResponseEntity<List<Alimentacion>> obtenerTodos() {
        List<Alimentacion> registros = alimentacionService.obtenerTodos();
        return ResponseEntity.ok(registros); // 200 OK
    }
    
    // GET: Obtener registro por ID (Lee uno)
    @GetMapping("/{id}")
    public ResponseEntity<Alimentacion> obtenerAlimentacionPorId(@PathVariable Long id) {
        Optional<Alimentacion> registro = alimentacionService.obtenerAlimentacionPorId(id);
        return registro
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }

    // PUT: Actualizar un registro existente (Actualiza)
    @PutMapping("/{id}")
    public ResponseEntity<Alimentacion> actualizarAlimentacion(@PathVariable Long id, @Valid @RequestBody Alimentacion alimentacionDetails) {
        Optional<Alimentacion> registroActualizado = alimentacionService.actualizarAlimentacion(id, alimentacionDetails);

        return registroActualizado
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }

    // DELETE: Eliminar un registro por ID (Elimina)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarAlimentacion(@PathVariable Long id) {
        if (alimentacionService.eliminarAlimentacion(id)) {
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    }
}