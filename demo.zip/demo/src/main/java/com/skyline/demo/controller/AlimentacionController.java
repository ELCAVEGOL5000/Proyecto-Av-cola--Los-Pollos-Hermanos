package com.skyline.demo.controller;

import com.skyline.demo.model.Alimentacion;
import com.skyline.demo.repository.AlimentacionRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/alimentacion")
public class AlimentacionController {

    @Autowired
    private AlimentacionRepository alimentacionRepository;

    // Registrar alimentación 
    @PostMapping
    public ResponseEntity<Alimentacion> registrarAlimentacion(@Valid @RequestBody Alimentacion alimentacion) {
        Alimentacion nuevoRegistro = alimentacionRepository.save(alimentacion);
        return new ResponseEntity<>(nuevoRegistro, HttpStatus.CREATED); // 201 Created
    }
}