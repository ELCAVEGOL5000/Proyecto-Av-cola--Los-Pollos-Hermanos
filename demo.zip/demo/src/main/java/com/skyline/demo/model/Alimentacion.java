package com.skyline.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "alimentacion")
public class Alimentacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lote_id", nullable = false)
    @NotNull(message = "El ID del lote es obligatorio.")
    private Long loteId;
    
    @Column(name = "fecha", nullable = false)
    @NotNull(message = "La fecha de alimentación es obligatoria.")
    private LocalDate fecha;

    @Column(name = "tipo_alimento", nullable = false, length = 100)
    @NotNull(message = "El tipo de alimento es obligatorio.")
    @Size(min = 2, max = 100, message = "El tipo de alimento debe tener entre 2 y 100 caracteres.")
    private String tipoAlimento;

    @Column(name = "cantidad_kg", nullable = false, precision = 10, scale = 2)
    @NotNull(message = "La cantidad de alimento (kg) es obligatoria.")
    @DecimalMin(value = "0.01", inclusive = true, message = "La cantidad debe ser mayor a cero.")
    private BigDecimal cantidadKg;

    public Alimentacion() {
        // Constructor vacío requerido por JPA
    }

    /**
     * Constructor conveniente para la creación de instancias.
     */
    public Alimentacion(Long loteId, LocalDate fecha, String tipoAlimento, BigDecimal cantidadKg) {
        this.loteId = loteId;
        this.fecha = fecha;
        this.tipoAlimento = tipoAlimento;
        this.cantidadKg = cantidadKg;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLoteId() {
        return loteId;
    }

    public void setLoteId(Long loteId) {
        this.loteId = loteId;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getTipoAlimento() {
        return tipoAlimento;
    }

    public void setTipoAlimento(String tipoAlimento) {
        this.tipoAlimento = tipoAlimento;
    }

    public BigDecimal getCantidadKg() {
        return cantidadKg;
    }

    public void setCantidadKg(BigDecimal cantidadKg) {
        this.cantidadKg = cantidadKg;
    }
}