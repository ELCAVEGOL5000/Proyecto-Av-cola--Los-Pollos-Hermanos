package com.skyline.demo.controller;

import com.skyline.demo.model.Lote;
import com.skyline.demo.model.Produccion;
import com.skyline.demo.repository.LoteRepository;
import com.skyline.demo.repository.ProduccionRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

class ProduccionIncoherenteException extends RuntimeException {
    public ProduccionIncoherenteException(String message) {
        super(message);
    }
}

@RestController
@RequestMapping("/api/produccion")
public class ProduccionController {

    @Autowired
    private ProduccionRepository produccionRepository;
    
    @Autowired
    private LoteRepository loteRepository;

    @ExceptionHandler(ProduccionIncoherenteException.class)
    public ResponseEntity<String> handleIncoherenteException(ProduccionIncoherenteException ex) {
        // Devuelve 400 con el mensaje de error.
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @PostMapping
    public ResponseEntity<Produccion> registrarProduccion(@Valid @RequestBody Produccion produccion) {

        Produccion nuevoRegistro = produccionRepository.save(produccion);
        return new ResponseEntity<>(nuevoRegistro, HttpStatus.CREATED); 
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produccion> actualizarProduccion(@PathVariable Long id, @Valid @RequestBody Produccion produccionDetails) {
        return produccionRepository.findById(id)
                .map(produccionExistente -> {

                    Long loteId = produccionDetails.getLoteId();
                    Lote lote = loteRepository.findById(loteId)
                            .orElseThrow(() -> new ProduccionIncoherenteException("Lote ID " + loteId + " no encontrado. Imposible validar coherencia."));

                    if (produccionDetails.getCantidad().compareTo(BigDecimal.valueOf(lote.getCantidad())) > 0) {
                        String mensajeError = String.format(
                            "La cantidad de producción (%.2f) es incoherente. Supera la cantidad de aves en el lote (%d).",
                            produccionDetails.getCantidad(), lote.getCantidad()
                        );
                        throw new ProduccionIncoherenteException(mensajeError);
                    }

                    produccionExistente.setLoteId(produccionDetails.getLoteId());
                    produccionExistente.setFecha(produccionDetails.getFecha());
                    produccionExistente.setTipoProduccion(produccionDetails.getTipoProduccion());
                    produccionExistente.setCantidad(produccionDetails.getCantidad());

                    Produccion produccionActualizada = produccionRepository.save(produccionExistente);
                    return ResponseEntity.ok(produccionActualizada);
                })
                .orElse(ResponseEntity.notFound().build()); 
    }
}