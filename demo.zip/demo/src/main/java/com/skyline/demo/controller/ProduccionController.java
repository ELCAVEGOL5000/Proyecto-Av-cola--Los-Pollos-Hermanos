package com.skyline.demo.controller;

import com.skyline.demo.model.Produccion;
import com.skyline.demo.service.ProduccionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/produccion")
public class ProduccionController {

    private final ProduccionService produccionService;

    @Autowired
    public ProduccionController(ProduccionService produccionService) {
        this.produccionService = produccionService;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
        // Mapeamos la excepción estándar a 400 Bad Request, que es el código correcto para errores del cliente/validación.
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @PostMapping
    public ResponseEntity<Produccion> registrarProduccion(@Valid @RequestBody Produccion produccion) {
        Produccion nuevoRegistro = produccionService.registrarProduccion(produccion);
        return new ResponseEntity<>(nuevoRegistro, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Produccion>> obtenerTodas() {
        List<Produccion> registros = produccionService.obtenerTodas();
        return ResponseEntity.ok(registros);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produccion> obtenerProduccionPorId(@PathVariable Long id) {
        Optional<Produccion> registro = produccionService.obtenerProduccionPorId(id);
        return registro
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produccion> actualizarProduccion(@PathVariable Long id, @Valid @RequestBody Produccion produccionDetails) {
        Optional<Produccion> produccionActualizada = produccionService.actualizarProduccion(id, produccionDetails);
        return produccionActualizada
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProduccion(@PathVariable Long id) {
        if (produccionService.eliminarProduccion(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}