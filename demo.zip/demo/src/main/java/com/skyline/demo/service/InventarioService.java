package com.skyline.demo.service;

import com.skyline.demo.model.Inventario;
import com.skyline.demo.repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class InventarioService {

    private final InventarioRepository inventarioRepository;

    @Autowired
    public InventarioService(InventarioRepository inventarioRepository) {
        this.inventarioRepository = inventarioRepository;
    }

    public List<Inventario> obtenerTodosLosItems() {
        return inventarioRepository.findAll();
    }

    public Optional<Inventario> obtenerItemPorId(Long id) {
        return inventarioRepository.findById(id);
    }

    public Inventario crearItemInventario(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }

    public Optional<Inventario> actualizarItemInventario(Long id, Inventario itemDetails) {
        return inventarioRepository.findById(id)
                .map(itemExistente -> {
                    itemExistente.setNombre(itemDetails.getNombre());
                    itemExistente.setTipo(itemDetails.getTipo());
                    itemExistente.setCantidad(itemDetails.getCantidad());
                    itemExistente.setUnidad(itemDetails.getUnidad());
                    itemExistente.setFechaIngreso(itemDetails.getFechaIngreso());
                    itemExistente.setFechaVencimiento(itemDetails.getFechaVencimiento());
                    return inventarioRepository.save(itemExistente);
                });
    }

    public boolean eliminarItemInventario(Long id) {
        if (inventarioRepository.existsById(id)) {
            inventarioRepository.deleteById(id);
            return true;
        }
        return false;
    }
}