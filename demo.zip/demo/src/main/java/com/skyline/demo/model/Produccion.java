package com.skyline.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "produccion")
public class Produccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "lote_id", nullable = false)
    @NotNull(message = "El ID del lote es obligatorio.")
    private Long loteId;
    
    @Column(name = "fecha", nullable = false)
    @NotNull(message = "La fecha de producción es obligatoria.")
    private LocalDate fecha;

    @Column(name = "tipo_produccion", nullable = false, length = 100)
    @NotNull(message = "El tipo de producción es obligatorio.")
    @Size(min = 2, max = 100, message = "El tipo de producción debe tener entre 2 y 100 caracteres.")
    private String tipoProduccion;

    @Column(name = "cantidad", nullable = false, precision = 10, scale = 2)
    @NotNull(message = "La cantidad de producción es obligatoria.")
    @DecimalMin(value = "0.01", inclusive = true, message = "La cantidad debe ser mayor a cero.")
    private BigDecimal cantidad;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLoteId() {
        return loteId;
    }

    public void setLoteId(Long loteId) {
        this.loteId = loteId;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getTipoProduccion() {
        return tipoProduccion;
    }

    public void setTipoProduccion(String tipoProduccion) {
        this.tipoProduccion = tipoProduccion;
    }

    public BigDecimal getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigDecimal cantidad) {
        this.cantidad = cantidad;
    }
}