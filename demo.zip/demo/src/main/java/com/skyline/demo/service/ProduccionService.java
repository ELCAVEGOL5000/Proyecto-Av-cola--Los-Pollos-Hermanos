package com.skyline.demo.service;

import com.skyline.demo.model.Lote;
import com.skyline.demo.model.Produccion;
import com.skyline.demo.repository.LoteRepository;
import com.skyline.demo.repository.ProduccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.math.BigDecimal;

@Service
public class ProduccionService {

    private final ProduccionRepository produccionRepository;
    private final LoteRepository loteRepository;

    @Autowired
    public ProduccionService(ProduccionRepository produccionRepository, LoteRepository loteRepository) {
        this.produccionRepository = produccionRepository;
        this.loteRepository = loteRepository;
    }

    private void validarCoherencia(Produccion produccion) {
        Long loteId = produccion.getLoteId();
        Lote lote = loteRepository.findById(loteId)
                .orElseThrow(() -> new IllegalArgumentException("Lote ID " + loteId + " no encontrado. Imposible validar coherencia."));

        if (produccion.getCantidad().compareTo(BigDecimal.valueOf(lote.getCantidad())) > 0) {
            String mensajeError = String.format(
                "La cantidad de producción (%.2f) es incoherente. Supera la cantidad de aves en el lote (%d).",
                produccion.getCantidad(), lote.getCantidad()
            );
            // Usamos IllegalArgumentException para indicar un fallo en la lógica de negocio/validación.
            throw new IllegalArgumentException(mensajeError);
        }
    }

    public Produccion registrarProduccion(Produccion produccion) {
        validarCoherencia(produccion);
        return produccionRepository.save(produccion);
    }

    public List<Produccion> obtenerTodas() {
        return produccionRepository.findAll();
    }

    public Optional<Produccion> obtenerProduccionPorId(Long id) {
        return produccionRepository.findById(id);
    }

    public Optional<Produccion> actualizarProduccion(Long id, Produccion produccionDetails) {
        return produccionRepository.findById(id)
                .map(produccionExistente -> {
                    
                    produccionExistente.setLoteId(produccionDetails.getLoteId());
                    produccionExistente.setFecha(produccionDetails.getFecha());
                    produccionExistente.setTipoProduccion(produccionDetails.getTipoProduccion());
                    produccionExistente.setCantidad(produccionDetails.getCantidad());

                    validarCoherencia(produccionExistente);

                    return produccionRepository.save(produccionExistente);
                });
    }

    public boolean eliminarProduccion(Long id) {
        if (produccionRepository.existsById(id)) {
            produccionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}