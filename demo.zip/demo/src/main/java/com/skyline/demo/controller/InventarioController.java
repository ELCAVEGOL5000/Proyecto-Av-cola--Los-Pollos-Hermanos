package com.skyline.demo.controller;

import com.skyline.demo.model.Inventario;
import com.skyline.demo.service.InventarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    private final InventarioService inventarioService;

    @Autowired
    public InventarioController(InventarioService inventarioService) {
        this.inventarioService = inventarioService;
    }

    @GetMapping
    public ResponseEntity<List<Inventario>> obtenerTodosLosItems() {
        List<Inventario> items = inventarioService.obtenerTodosLosItems();
        return ResponseEntity.ok(items);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Inventario> obtenerItemPorId(@PathVariable Long id) {
        Optional<Inventario> item = inventarioService.obtenerItemPorId(id);
        return item.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Inventario> crearItemInventario(@Valid @RequestBody Inventario inventario) {
        Inventario nuevoItem = inventarioService.crearItemInventario(inventario);
        return new ResponseEntity<>(nuevoItem, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Inventario> actualizarItemInventario(@PathVariable Long id, @Valid @RequestBody Inventario itemDetails) {
        Optional<Inventario> itemActualizado = inventarioService.actualizarItemInventario(id, itemDetails);
        return itemActualizado
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarItemInventario(@PathVariable Long id) {
        if (inventarioService.eliminarItemInventario(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}