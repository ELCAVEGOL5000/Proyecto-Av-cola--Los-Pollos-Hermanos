package com.skyline.demo.controller;

import com.skyline.demo.model.Inventario;
import com.skyline.demo.repository.InventarioRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    @Autowired
    private InventarioRepository inventarioRepository;

    // Obtener todos los ítems del inventario
    @GetMapping
    public List<Inventario> obtenerTodosLosItems() {
        return inventarioRepository.findAll();
    }

    // Registrar nuevo ítem en el inventario
    @PostMapping
    public ResponseEntity<Inventario> crearItemInventario(@Valid @RequestBody Inventario inventario) {
        Inventario nuevoItem = inventarioRepository.save(inventario);
        return new ResponseEntity<>(nuevoItem, HttpStatus.CREATED); // 201 Created
    }

    // Actualizar ítem existente por ID
    @PutMapping("/{id}")
    public ResponseEntity<Inventario> actualizarItemInventario(@PathVariable Long id, @Valid @RequestBody Inventario itemDetails) {
        return inventarioRepository.findById(id)
                .map(itemExistente -> {
                    // Actualizar campos usando los nuevos nombres (nombre, tipo, unidad, fechas)
                    itemExistente.setNombre(itemDetails.getNombre());
                    itemExistente.setTipo(itemDetails.getTipo()); // Campo 'tipo'
                    itemExistente.setCantidad(itemDetails.getCantidad());
                    itemExistente.setUnidad(itemDetails.getUnidad()); // Campo 'unidad' (antes unidadMedida)
                    itemExistente.setFechaIngreso(itemDetails.getFechaIngreso()); // Campo 'fechaIngreso' (antes fechaUltimaCompra)
                    itemExistente.setFechaVencimiento(itemDetails.getFechaVencimiento()); // Campo 'fechaVencimiento'

                    Inventario itemActualizado = inventarioRepository.save(itemExistente);
                    return ResponseEntity.ok(itemActualizado); // 200 OK
                })
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }

    // Eliminar del inventario por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarItemInventario(@PathVariable Long id) {
        if (!inventarioRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        inventarioRepository.deleteById(id);
        return ResponseEntity.noContent().build(); // 204 No Content
    }
}