package com.skyline.demo.model;

public enum Rol {
    ADMIN,
    SUPERVISOR,
    OPERARIO,
    NINGUNO
}