package com.skyline.demo.service;

import com.skyline.demo.model.Galpon;
import com.skyline.demo.repository.GalponRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class GalponService {

    private final GalponRepository galponRepository;

    @Autowired
    public GalponService(GalponRepository galponRepository) {
        this.galponRepository = galponRepository;
    }

    public List<Galpon> obtenerTodosLosGalpones() {
        return galponRepository.findAll();
    }

    public Optional<Galpon> obtenerGalponPorId(Long id) {
        return galponRepository.findById(id);
    }

    public Galpon crearGalpon(Galpon galpon) {
        return galponRepository.save(galpon);
    }

    public Optional<Galpon> actualizarGalpon(Long id, Galpon galponDetails) {
        return galponRepository.findById(id)
                .map(galponExistente -> {
                    galponExistente.setNombre(galponDetails.getNombre());
                    galponExistente.setUbicacion(galponDetails.getUbicacion());
                    galponExistente.setCapacidad(galponDetails.getCapacidad());
                    galponExistente.setLoteAsignadoId(galponDetails.getLoteAsignadoId());
                    galponExistente.setEstado(galponDetails.getEstado());
                    return galponRepository.save(galponExistente);
                });
    }

    public boolean eliminarGalpon(Long id) {
        if (galponRepository.existsById(id)) {
            galponRepository.deleteById(id);
            return true;
        }
        return false;
    }
}