package com.skyline.demo.service;

import com.skyline.demo.model.Lote;
import com.skyline.demo.repository.LoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class LoteService {

    private final LoteRepository loteRepository;

    // Inyección de dependencia a través del constructor (práctica recomendada)
    @Autowired
    public LoteService(LoteRepository loteRepository) {
        this.loteRepository = loteRepository;
    }

    /**
     * Registra un nuevo lote en la base de datos.
     * @param lote Los datos del lote a guardar.
     * @return El lote guardado, incluyendo el ID generado.
     */
    public Lote registrarLote(Lote lote) {
        return loteRepository.save(lote);
    }

    /**
     * Obtiene una lista de todos los lotes.
     * @return Una lista de objetos Lote.
     */
    public List<Lote> obtenerTodos() {
        // Usamos findAll() de JpaRepository para obtener List<Lote>
        return loteRepository.findAll();
    }

    /**
     * Busca un lote por su identificador.
     * @param id El ID del lote.
     * @return Un Optional que contiene el Lote si existe, o está vacío.
     */
    public Optional<Lote> obtenerLotePorId(Long id) {
        return loteRepository.findById(id);
    }

    /**
     * Actualiza un lote existente con nuevos detalles.
     * @param id El ID del lote a actualizar.
     * @param loteDetails El objeto Lote con los nuevos datos.
     * @return Un Optional que contiene el lote actualizado si el ID existe, o está vacío.
     */
    public Optional<Lote> actualizarLote(Long id, Lote loteDetails) {
        return loteRepository.findById(id)
                .map(loteExistente -> {
                    // Copia de propiedades: La lógica de actualización está aquí.
                    loteExistente.setCodigoLote(loteDetails.getCodigoLote());
                    loteExistente.setTipo(loteDetails.getTipo());
                    loteExistente.setCantidad(loteDetails.getCantidad());
                    loteExistente.setFechaInicio(loteDetails.getFechaInicio());
                    loteExistente.setEstado(loteDetails.getEstado());

                    return loteRepository.save(loteExistente);
                });
    }

    /**
     * Elimina un lote por su identificador.
     * @param id El ID del lote a eliminar.
     * @return true si el lote fue encontrado y eliminado, false si no existía.
     */
    public boolean eliminarLote(Long id) {
        if (loteRepository.existsById(id)) {
            loteRepository.deleteById(id);
            return true;
        }
        return false;
    }
}