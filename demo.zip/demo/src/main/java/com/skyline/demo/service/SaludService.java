package com.skyline.demo.service;

import com.skyline.demo.model.Salud;
import com.skyline.demo.repository.SaludRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class SaludService {

    private final SaludRepository saludRepository;

    @Autowired
    public SaludService(SaludRepository saludRepository) {
        this.saludRepository = saludRepository;
    }

    public Salud registrarControl(Salud salud) {
        return saludRepository.save(salud);
    }

    public List<Salud> obtenerTodosLosControles() {
        return saludRepository.findAll();
    }

    public Optional<Salud> obtenerControlPorId(Long id) {
        return saludRepository.findById(id);
    }

    public Optional<Salud> actualizarControl(Long id, Salud saludDetails) {
        return saludRepository.findById(id)
                .map(controlExistente -> {
                    controlExistente.setLoteId(saludDetails.getLoteId());
                    controlExistente.setFecha(saludDetails.getFecha());
                    controlExistente.setTipoControl(saludDetails.getTipoControl());
                    controlExistente.setDescripcion(saludDetails.getDescripcion());
                    controlExistente.setResultado(saludDetails.getResultado());
                    return saludRepository.save(controlExistente);
                });
    }

    public boolean eliminarControl(Long id) {
        if (saludRepository.existsById(id)) {
            saludRepository.deleteById(id);
            return true;
        }
        return false;
    }
}