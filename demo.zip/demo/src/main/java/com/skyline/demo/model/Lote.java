package com.skyline.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


@Entity
@Table(name = "lotes")
public class Lote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //No nulo
    @NotBlank(message = "El código del lote es obligatorio.")
    @Column(name = "codigo_lote", unique = true, nullable = false)
    private String codigoLote;

    @NotBlank(message = "El tipo de pollo es obligatorio.")
    @Column(name = "tipo", nullable = false)
    private String tipo;

    //No nulo Y  mayor a 0
    @NotNull(message = "La cantidad de pollos es obligatoria.")
    @Min(value = 1, message = "La cantidad debe ser mayor a cero.")
    @Column(name = "cantidad", nullable = false)
    private Integer cantidad;

    //No nulo
    @NotNull(message = "La fecha de inicio es obligatoria.")
    @Column(name = "fecha_inicio", nullable = false)
    private LocalDate fechaInicio;

    @Column(name = "estado")
    @Enumerated(EnumType.STRING)
    private EstadoLote estado = EstadoLote.activo;

    public enum EstadoLote {
        activo, inactivo
    }

    public Lote() {
    }

    public Lote(String codigoLote, String tipo, Integer cantidad, LocalDate fechaInicio, EstadoLote estado) {
        this.codigoLote = codigoLote;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.fechaInicio = fechaInicio;
        this.estado = estado;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoLote() {
        return codigoLote;
    }

    public void setCodigoLote(String codigoLote) {
        this.codigoLote = codigoLote;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public EstadoLote getEstado() {
        return estado;
    }

    public void setEstado(EstadoLote estado) {
        this.estado = estado;
    }
}