package com.skyline.demo.controller;

import com.skyline.demo.model.Salud;
import com.skyline.demo.service.SaludService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/salud")
public class SaludController {

    private final SaludService saludService;

    @Autowired
    public SaludController(SaludService saludService) {
        this.saludService = saludService;
    }

    @PostMapping
    public ResponseEntity<Salud> registrarControl(@Valid @RequestBody Salud salud) {
        Salud nuevoControl = saludService.registrarControl(salud);
        return new ResponseEntity<>(nuevoControl, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Salud>> obtenerTodosLosControles() {
        List<Salud> controles = saludService.obtenerTodosLosControles();
        return ResponseEntity.ok(controles);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Salud> obtenerControlPorId(@PathVariable Long id) {
        Optional<Salud> control = saludService.obtenerControlPorId(id);
        return control
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Salud> actualizarControl(@PathVariable Long id, @Valid @RequestBody Salud saludDetails) {
        Optional<Salud> controlActualizado = saludService.actualizarControl(id, saludDetails);
        return controlActualizado
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarControl(@PathVariable Long id) {
        if (saludService.eliminarControl(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}