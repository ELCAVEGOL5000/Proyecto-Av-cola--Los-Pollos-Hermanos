package com.skyline.demo.controller;

import com.skyline.demo.model.Salud;
import com.skyline.demo.repository.SaludRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/salud")
public class SaludController {

    @Autowired
    private SaludRepository saludRepository;

    //Registrar control sanitario o vacunación
    @PostMapping
    public ResponseEntity<Salud> registrarControl(@Valid @RequestBody Salud salud) {
        Salud nuevoControl = saludRepository.save(salud);
        return new ResponseEntity<>(nuevoControl, HttpStatus.CREATED); // 201 Created
    }

}