package com.skyline.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "inventario")
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 100)
    @NotBlank(message = "El nombre del insumo es obligatorio.")
    @Size(min = 3, max = 100, message = "El nombre debe tener entre 3 y 100 caracteres.")
    private String nombre;

    @Column(name = "tipo", nullable = false, length = 50)
    @NotBlank(message = "El tipo de insumo es obligatorio.")
    private String tipo;

    @Column(name = "cantidad", nullable = false, precision = 10, scale = 2)
    @NotNull(message = "La cantidad de stock es obligatoria.")
    @DecimalMin(value = "0.0", inclusive = true, message = "La cantidad de stock no puede ser negativa.")
    private BigDecimal cantidad;

    @Column(name = "unidad", nullable = false, length = 50)
    @NotBlank(message = "La unidad de medida es obligatoria.")
    @Size(max = 50, message = "La unidad de medida no debe exceder 50 caracteres.")
    private String unidad;

    @Column(name = "fecha_ingreso", nullable = false)
    @NotNull(message = "La fecha de ingreso es obligatoria.")
    private LocalDate fechaIngreso;

    @Column(name = "fecha_vencimiento")
    private LocalDate fechaVencimiento;

    public Inventario() {
    }

    public Inventario(String nombre, String tipo, BigDecimal cantidad, String unidad, LocalDate fechaIngreso, LocalDate fechaVencimiento) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.unidad = unidad;
        this.fechaIngreso = fechaIngreso;
        this.fechaVencimiento = fechaVencimiento;
    }

    public Long getId(){ 
    	return id; 
    }
    
    public void setId(Long id) { 
    	this.id = id; 
    }
    
    public String getNombre() { 
    	return nombre; 
    }
    
    public void setNombre(String nombre) { 
    	this.nombre = nombre; 
    }
    
    public String getTipo() { 
    	return tipo; 
    }
    
    public void setTipo(String tipo) { 
    	this.tipo = tipo; 
    }
    
    public BigDecimal getCantidad() { 
    	return cantidad; 
    }
    
    public void setCantidad(BigDecimal cantidad) { 
    	this.cantidad = cantidad; 
    }
    
    public String getUnidad() { 
    	return unidad; 
    }
    
    public void setUnidad(String unidad) { 
    	this.unidad = unidad; 
    }
    
    public LocalDate getFechaIngreso() { 
    	return fechaIngreso; 
    }
    
    public void setFechaIngreso(LocalDate fechaIngreso) { 
    	this.fechaIngreso = fechaIngreso; 
    }
    
    public LocalDate getFechaVencimiento() { 
    	return fechaVencimiento; 
    }
    
    public void setFechaVencimiento(LocalDate fechaVencimiento) { 
    	this.fechaVencimiento = fechaVencimiento; 
    }
    
}