package com.skyline.demo.service;

import com.skyline.demo.model.Alimentacion;
import com.skyline.demo.repository.AlimentacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AlimentacionService {

    private final AlimentacionRepository alimentacionRepository;

    @Autowired
    public AlimentacionService(AlimentacionRepository alimentacionRepository) {
        this.alimentacionRepository = alimentacionRepository;
    }

    /**
     * Registra un nuevo evento de alimentación.
     */
    public Alimentacion registrarAlimentacion(Alimentacion alimentacion) {
        // Aquí podrías añadir lógica de negocio, como validar si el loteId existe,
        // antes de guardar. Por ahora, solo guarda directamente.
        return alimentacionRepository.save(alimentacion);
    }

    /**
     * Obtiene todos los registros de alimentación.
     */
    public List<Alimentacion> obtenerTodos() {
        return alimentacionRepository.findAll();
    }

    /**
     * Busca un registro de alimentación por su ID.
     */
    public Optional<Alimentacion> obtenerAlimentacionPorId(Long id) {
        return alimentacionRepository.findById(id);
    }

    /**
     * Actualiza un registro de alimentación existente.
     */
    public Optional<Alimentacion> actualizarAlimentacion(Long id, Alimentacion alimentacionDetails) {
        return alimentacionRepository.findById(id)
                .map(registroExistente -> {
                    // Actualizar los campos
                    registroExistente.setLoteId(alimentacionDetails.getLoteId());
                    registroExistente.setFecha(alimentacionDetails.getFecha());
                    registroExistente.setTipoAlimento(alimentacionDetails.getTipoAlimento());
                    registroExistente.setCantidadKg(alimentacionDetails.getCantidadKg());

                    return alimentacionRepository.save(registroExistente);
                });
    }

    /**
     * Elimina un registro de alimentación por su ID.
     */
    public boolean eliminarAlimentacion(Long id) {
        if (alimentacionRepository.existsById(id)) {
            alimentacionRepository.deleteById(id);
            return true;
        }
        return false;
    }
}