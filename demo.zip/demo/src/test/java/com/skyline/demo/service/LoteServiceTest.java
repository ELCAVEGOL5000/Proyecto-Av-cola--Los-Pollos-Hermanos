package com.skyline.demo.service;

import com.skyline.demo.model.Lote;
import com.skyline.demo.repository.LoteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class LoteServiceTest {

    @Mock
    private LoteRepository loteRepository;

    @InjectMocks
    private LoteService loteService;

    private Lote loteActivo;
    private Lote loteInactivo;

    @BeforeEach
    void setUp() {
        loteActivo = new Lote("L001", "Broiler", 1000, LocalDate.now(), Lote.EstadoLote.activo);
        loteActivo.setId(1L);

        loteInactivo = new Lote("L002", "Ponedoras", 500, LocalDate.now().minusDays(30), Lote.EstadoLote.inactivo);
        loteInactivo.setId(2L);
    }

    @Test
    void registrarLote_debeGuardarYLanzarLote() {
        when(loteRepository.save(any(Lote.class))).thenReturn(loteActivo);

        Lote resultado = loteService.registrarLote(loteActivo);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("L001", resultado.getCodigoLote());
        verify(loteRepository, times(1)).save(loteActivo);
    }

    @Test
    void obtenerTodos_debeDevolverTodosLosLotes() {
        List<Lote> lotes = Arrays.asList(loteActivo, loteInactivo);
        when(loteRepository.findAll()).thenReturn(lotes);

        List<Lote> resultado = loteService.obtenerTodos();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals("L001", resultado.get(0).getCodigoLote());
        verify(loteRepository, times(1)).findAll();
    }

    @Test
    void obtenerLotePorId_debeDevolverLote_cuandoExiste() {
        when(loteRepository.findById(1L)).thenReturn(Optional.of(loteActivo));

        Optional<Lote> resultado = loteService.obtenerLotePorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(loteActivo.getCodigoLote(), resultado.get().getCodigoLote());
        verify(loteRepository, times(1)).findById(1L);
    }

    @Test
    void obtenerLotePorId_debeDevolverVacio_cuandoNoExiste() {
        when(loteRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Lote> resultado = loteService.obtenerLotePorId(99L);

        assertFalse(resultado.isPresent());
        verify(loteRepository, times(1)).findById(99L);
    }

    @Test
    void actualizarLote_debeActualizarYDevolverLote_cuandoExiste() {
        Lote detallesNuevos = new Lote("L001_UPD", "Broiler", 1500, LocalDate.now(), Lote.EstadoLote.inactivo);
        
        when(loteRepository.findById(1L)).thenReturn(Optional.of(loteActivo));
        when(loteRepository.save(any(Lote.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Lote> resultado = loteService.actualizarLote(1L, detallesNuevos);

        assertTrue(resultado.isPresent());
        assertEquals(1500, resultado.get().getCantidad());
        assertEquals(Lote.EstadoLote.inactivo, resultado.get().getEstado());
        verify(loteRepository, times(1)).findById(1L);
        verify(loteRepository, times(1)).save(loteActivo);
    }

    @Test
    void actualizarLote_debeDevolverVacio_cuandoNoExiste() {
        Lote detallesNuevos = new Lote("L001_UPD", "Broiler", 1500, LocalDate.now(), Lote.EstadoLote.inactivo);
        
        when(loteRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Lote> resultado = loteService.actualizarLote(99L, detallesNuevos);

        assertFalse(resultado.isPresent());
        verify(loteRepository, times(1)).findById(99L);
        verify(loteRepository, never()).save(any(Lote.class));
    }

    @Test
    void eliminarLote_debeDevolverTrue_cuandoExiste() {
        when(loteRepository.existsById(1L)).thenReturn(true);
        doNothing().when(loteRepository).deleteById(1L);

        boolean resultado = loteService.eliminarLote(1L);

        assertTrue(resultado);
        verify(loteRepository, times(1)).existsById(1L);
        verify(loteRepository, times(1)).deleteById(1L);
    }

    @Test
    void eliminarLote_debeDevolverFalse_cuandoNoExiste() {
        when(loteRepository.existsById(99L)).thenReturn(false);

        boolean resultado = loteService.eliminarLote(99L);

        assertFalse(resultado);
        verify(loteRepository, times(1)).existsById(99L);
        verify(loteRepository, never()).deleteById(99L);
    }
}