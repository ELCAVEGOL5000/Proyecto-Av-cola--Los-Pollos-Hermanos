package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.model.Lote;
import com.skyline.demo.model.Produccion;
import com.skyline.demo.repository.LoteRepository;
import com.skyline.demo.repository.ProduccionRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest; 
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.hamcrest.Matchers.containsString; // Importación necesaria

@WebMvcTest(ProduccionController.class)
public class ProduccionControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private ProduccionRepository produccionRepository;

    @SuppressWarnings("removal")
	@MockBean
    private LoteRepository loteRepository;

    @Autowired 
    private ObjectMapper objectMapper;


    @Test
    void debeActualizarProduccionYDevolver200() throws Exception {
        Long produccionId = 1L;
        Long loteId = 10L;

        Lote loteSimulado = new Lote();
        loteSimulado.setId(loteId);
        loteSimulado.setCantidad(1000); 
        
        Produccion produccionExistente = new Produccion();
        produccionExistente.setId(produccionId);
        produccionExistente.setLoteId(loteId);
        produccionExistente.setFecha(LocalDate.of(2025, 1, 1));
        produccionExistente.setTipoProduccion("Huevos");
        produccionExistente.setCantidad(new BigDecimal("500.00"));

        Produccion produccionDetalles = new Produccion();
        produccionDetalles.setLoteId(loteId); // Mismo Lote ID
        produccionDetalles.setFecha(LocalDate.of(2025, 1, 2));
        produccionDetalles.setTipoProduccion("Huevos Grandes");
        produccionDetalles.setCantidad(new BigDecimal("750.00")); 

        when(produccionRepository.findById(produccionId)).thenReturn(Optional.of(produccionExistente));
        when(loteRepository.findById(loteId)).thenReturn(Optional.of(loteSimulado));
        
        when(produccionRepository.save(any(Produccion.class))).thenAnswer(invocation -> {
            Produccion savedProd = invocation.getArgument(0);
            savedProd.setId(produccionId);
            return savedProd;
        });

        mockMvc.perform(put("/api/produccion/{id}", produccionId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(produccionDetalles)))
        
                .andExpect(status().isOk()) // 200 OK
                .andExpect(jsonPath("$.id").value(produccionId))
                .andExpect(jsonPath("$.tipoProduccion").value("Huevos Grandes"))
                .andExpect(jsonPath("$.cantidad").value(750.00));
    }


    @Test
    void debeDevolverError400SiProduccionEsIncoherente() throws Exception {
        Long produccionId = 2L;
        Long loteId = 20L;

        Lote loteSimulado = new Lote();
        loteSimulado.setId(loteId);
        loteSimulado.setCantidad(500);
        
        Produccion produccionExistente = new Produccion();
        produccionExistente.setId(produccionId);
        produccionExistente.setLoteId(loteId);
        produccionExistente.setFecha(LocalDate.of(2025, 1, 1));
        produccionExistente.setTipoProduccion("Huevos");
        produccionExistente.setCantidad(new BigDecimal("450.00"));

        Produccion produccionDetalles = new Produccion();
        produccionDetalles.setLoteId(loteId);
        produccionDetalles.setFecha(LocalDate.of(2025, 1, 2));
        produccionDetalles.setTipoProduccion("Huevos");
        produccionDetalles.setCantidad(new BigDecimal("501.00"));

        when(produccionRepository.findById(produccionId)).thenReturn(Optional.of(produccionExistente));
        when(loteRepository.findById(loteId)).thenReturn(Optional.of(loteSimulado));

        mockMvc.perform(put("/api/produccion/{id}", produccionId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(produccionDetalles)))
            
            .andExpect(status().isBadRequest()) // 400 Bad Request
            .andExpect(content().string(containsString("La cantidad de producción")))
            .andExpect(content().string(containsString("es incoherente")))
            .andExpect(content().string(containsString("500")));
    }


    @Test
    void debeDevolver404SiProduccionNoExiste() throws Exception {
        Long produccionId = 99L;
        
        Produccion produccionDetalles = new Produccion();
        produccionDetalles.setLoteId(1L);
        produccionDetalles.setFecha(LocalDate.of(2025, 1, 2));
        produccionDetalles.setTipoProduccion("Huevos");
        produccionDetalles.setCantidad(new BigDecimal("100.00"));

        when(produccionRepository.findById(produccionId)).thenReturn(Optional.empty());
        when(loteRepository.findById(anyLong())).thenReturn(Optional.of(new Lote()));

        mockMvc.perform(put("/api/produccion/{id}", produccionId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(produccionDetalles)))
                
                .andExpect(status().isNotFound()); // 404 Not Found
    }
}