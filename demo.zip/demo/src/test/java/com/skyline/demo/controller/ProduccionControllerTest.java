package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skyline.demo.model.Produccion;
import com.skyline.demo.service.ProduccionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProduccionController.class)
public class ProduccionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProduccionService produccionService;

    private ObjectMapper objectMapper;
    private Produccion produccion1;
    private Produccion produccion2;

    @BeforeEach
    void setUp() {
        // Configurar ObjectMapper para manejar LocalDate y BigDecimal
        objectMapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();

        produccion1 = new Produccion(10L, LocalDate.of(2025, 11, 1), "Huevo A", new BigDecimal("300.00"));
        produccion1.setId(1L);

        produccion2 = new Produccion(20L, LocalDate.of(2025, 11, 5), "Carne", new BigDecimal("750.50"));
        produccion2.setId(2L);
    }

    // --- Pruebas para POST (Creación) ---

    @Test
    void registrarProduccion_debeDevolver201_yRegistroCreado_cuandoEsValido() throws Exception {
        Produccion produccionNueva = new Produccion(30L, LocalDate.now(), "Huevo B", new BigDecimal("450.00"));
        Produccion produccionGuardada = new Produccion(30L, LocalDate.now(), "Huevo B", new BigDecimal("450.00"));
        produccionGuardada.setId(3L);

        when(produccionService.registrarProduccion(any(Produccion.class))).thenReturn(produccionGuardada);

        mockMvc.perform(post("/api/produccion")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(produccionNueva)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3L))
                .andExpect(jsonPath("$.tipoProduccion").value("Huevo B"));
        
        verify(produccionService, times(1)).registrarProduccion(any(Produccion.class));
    }

    @Test
    void registrarProduccion_debeDevolver400_cuandoEsIncoherente() throws Exception {
        Produccion produccionIncoherente = new Produccion(10L, LocalDate.now(), "Carne", new BigDecimal("1500.00"));
        
        // Simular la excepción de negocio lanzada por el servicio
        when(produccionService.registrarProduccion(any(Produccion.class)))
            .thenThrow(new IllegalArgumentException("La cantidad de producción es incoherente."));

        mockMvc.perform(post("/api/produccion")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(produccionIncoherente)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("La cantidad de producción es incoherente."));
        
        verify(produccionService, times(1)).registrarProduccion(any(Produccion.class));
    }

    // --- Pruebas para GET (Obtener) ---

    @Test
    void obtenerTodas_debeDevolver200_yListaDeRegistros() throws Exception {
        when(produccionService.obtenerTodas()).thenReturn(Arrays.asList(produccion1, produccion2));

        mockMvc.perform(get("/api/produccion")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[1].loteId").value(20L));

        verify(produccionService, times(1)).obtenerTodas();
    }

    @Test
    void obtenerProduccionPorId_debeDevolver200_cuandoExiste() throws Exception {
        when(produccionService.obtenerProduccionPorId(1L)).thenReturn(Optional.of(produccion1));

        mockMvc.perform(get("/api/produccion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipoProduccion").value("Huevo A"));
        
        verify(produccionService, times(1)).obtenerProduccionPorId(1L);
    }

    @Test
    void obtenerProduccionPorId_debeDevolver404_cuandoNoExiste() throws Exception {
        when(produccionService.obtenerProduccionPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/produccion/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(produccionService, times(1)).obtenerProduccionPorId(99L);
    }

    // --- Pruebas para PUT (Actualización) ---

    @Test
    void actualizarProduccion_debeDevolver200_yRegistroActualizado_cuandoEsValido() throws Exception {
        Produccion detallesNuevos = new Produccion(10L, LocalDate.of(2025, 11, 1), "Huevo Actualizado", new BigDecimal("350.00"));
        Produccion produccionActualizada = new Produccion(10L, LocalDate.of(2025, 11, 1), "Huevo Actualizado", new BigDecimal("350.00"));
        produccionActualizada.setId(1L);

        when(produccionService.actualizarProduccion(eq(1L), any(Produccion.class))).thenReturn(Optional.of(produccionActualizada));

        mockMvc.perform(put("/api/produccion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipoProduccion").value("Huevo Actualizado"))
                .andExpect(jsonPath("$.cantidad").value(350.00));
        
        verify(produccionService, times(1)).actualizarProduccion(eq(1L), any(Produccion.class));
    }

    @Test
    void actualizarProduccion_debeDevolver404_cuandoNoExiste() throws Exception {
        Produccion detallesNuevos = new Produccion(10L, LocalDate.now(), "Inexistente", new BigDecimal("10.0"));
        
        when(produccionService.actualizarProduccion(eq(99L), any(Produccion.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/produccion/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isNotFound());
        
        verify(produccionService, times(1)).actualizarProduccion(eq(99L), any(Produccion.class));
    }

    @Test
    void actualizarProduccion_debeDevolver400_cuandoActualizacionEsIncoherente() throws Exception {
        Produccion detallesNuevos = new Produccion(10L, LocalDate.now(), "Carne Incoherente", new BigDecimal("2000.00"));
        
        // Simular que el servicio lanza una excepción por incoherencia
        when(produccionService.actualizarProduccion(eq(1L), any(Produccion.class)))
            .thenThrow(new IllegalArgumentException("La cantidad de producción es incoherente."));

        mockMvc.perform(put("/api/produccion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("La cantidad de producción es incoherente."));
        
        verify(produccionService, times(1)).actualizarProduccion(eq(1L), any(Produccion.class));
    }


    // --- Pruebas para DELETE (Eliminación) ---

    @Test
    void eliminarProduccion_debeDevolver204_cuandoExiste() throws Exception {
        when(produccionService.eliminarProduccion(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/produccion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(produccionService, times(1)).eliminarProduccion(1L);
    }

    @Test
    void eliminarProduccion_debeDevolver404_cuandoNoExiste() throws Exception {
        when(produccionService.eliminarProduccion(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/produccion/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(produccionService, times(1)).eliminarProduccion(99L);
    }
}