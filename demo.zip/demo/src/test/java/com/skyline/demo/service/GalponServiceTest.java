package com.skyline.demo.service;

import com.skyline.demo.model.Galpon;
import com.skyline.demo.model.Galpon.EstadoGalpon;
import com.skyline.demo.repository.GalponRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class GalponServiceTest {

    @Mock
    private GalponRepository galponRepository;

    @InjectMocks
    private GalponService galponService;

    private Galpon galpon1;
    private Galpon galpon2;

    @BeforeEach
    void setUp() {
        galpon1 = new Galpon("Galpon A", "Sector Norte", 500, null, EstadoGalpon.activo);
        galpon1.setId(1L);
        // Mockear el timestamp ya que no se genera automáticamente en la unidad de prueba
        galpon1.setCreadoEn(LocalDateTime.now().minusDays(5));

        galpon2 = new Galpon("Galpon B", "Sector Sur", 800, 101L, EstadoGalpon.mantenimiento);
        galpon2.setId(2L);
        galpon2.setCreadoEn(LocalDateTime.now().minusDays(1));
    }

    @Test
    void crearGalpon_debeGuardarYDevolverGalpon() {
        when(galponRepository.save(any(Galpon.class))).thenReturn(galpon1);

        Galpon resultado = galponService.crearGalpon(galpon1);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Galpon A", resultado.getNombre());
        verify(galponRepository, times(1)).save(galpon1);
    }

    @Test
    void obtenerTodosLosGalpones_debeDevolverTodosLosRegistros() {
        List<Galpon> galpones = Arrays.asList(galpon1, galpon2);
        when(galponRepository.findAll()).thenReturn(galpones);

        List<Galpon> resultado = galponService.obtenerTodosLosGalpones();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals(EstadoGalpon.activo, resultado.get(0).getEstado());
        verify(galponRepository, times(1)).findAll();
    }

    @Test
    void obtenerGalponPorId_debeDevolverGalpon_cuandoExiste() {
        when(galponRepository.findById(1L)).thenReturn(Optional.of(galpon1));

        Optional<Galpon> resultado = galponService.obtenerGalponPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(500, resultado.get().getCapacidad());
        verify(galponRepository, times(1)).findById(1L);
    }

    @Test
    void obtenerGalponPorId_debeDevolverVacio_cuandoNoExiste() {
        when(galponRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Galpon> resultado = galponService.obtenerGalponPorId(99L);

        assertFalse(resultado.isPresent());
        verify(galponRepository, times(1)).findById(99L);
    }

    @Test
    void actualizarGalpon_debeActualizarYDevolverGalpon_cuandoExiste() {
        Galpon detallesNuevos = new Galpon("Galpon A Modificado", "Sector Oeste", 600, 202L, EstadoGalpon.inactivo);
        
        when(galponRepository.findById(1L)).thenReturn(Optional.of(galpon1));
        when(galponRepository.save(any(Galpon.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Galpon> resultado = galponService.actualizarGalpon(1L, detallesNuevos);

        assertTrue(resultado.isPresent());
        assertEquals("Galpon A Modificado", resultado.get().getNombre());
        assertEquals(600, resultado.get().getCapacidad());
        assertEquals(EstadoGalpon.inactivo, resultado.get().getEstado());
        verify(galponRepository, times(1)).findById(1L);
        verify(galponRepository, times(1)).save(galpon1);
    }

    @Test
    void actualizarGalpon_debeDevolverVacio_cuandoNoExiste() {
        Galpon detallesNuevos = new Galpon("Inexistente", "N/A", 100, null, EstadoGalpon.activo);
        
        when(galponRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Galpon> resultado = galponService.actualizarGalpon(99L, detallesNuevos);

        assertFalse(resultado.isPresent());
        verify(galponRepository, times(1)).findById(99L);
        verify(galponRepository, never()).save(any(Galpon.class));
    }

    @Test
    void eliminarGalpon_debeDevolverTrue_cuandoExiste() {
        when(galponRepository.existsById(1L)).thenReturn(true);
        doNothing().when(galponRepository).deleteById(1L);

        boolean resultado = galponService.eliminarGalpon(1L);

        assertTrue(resultado);
        verify(galponRepository, times(1)).existsById(1L);
        verify(galponRepository, times(1)).deleteById(1L);
    }

    @Test
    void eliminarGalpon_debeDevolverFalse_cuandoNoExiste() {
        when(galponRepository.existsById(99L)).thenReturn(false);

        boolean resultado = galponService.eliminarGalpon(99L);

        assertFalse(resultado);
        verify(galponRepository, times(1)).existsById(99L);
        verify(galponRepository, never()).deleteById(99L);
    }
}