package com.skyline.demo.service;

import com.skyline.demo.model.Inventario;
import com.skyline.demo.repository.InventarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private InventarioService inventarioService;

    private Inventario item1;
    private Inventario item2;

    @BeforeEach
    void setUp() {
        item1 = new Inventario("Vacuna Aviar", "Medicamento", new BigDecimal("100.00"), "dosis", LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        item1.setId(1L);

        item2 = new Inventario("Concentrado Etapa 2", "Alimento", new BigDecimal("5000.50"), "kg", LocalDate.of(2025, 2, 10), null);
        item2.setId(2L);
    }

    @Test
    void crearItemInventario_debeGuardarYDevolverItem() {
        when(inventarioRepository.save(any(Inventario.class))).thenReturn(item1);

        Inventario resultado = inventarioService.crearItemInventario(item1);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Vacuna Aviar", resultado.getNombre());
        verify(inventarioRepository, times(1)).save(item1);
    }

    @Test
    void obtenerTodosLosItems_debeDevolverListaDeItems() {
        List<Inventario> items = Arrays.asList(item1, item2);
        when(inventarioRepository.findAll()).thenReturn(items);

        List<Inventario> resultado = inventarioService.obtenerTodosLosItems();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(inventarioRepository, times(1)).findAll();
    }

    @Test
    void obtenerItemPorId_debeDevolverItem_cuandoExiste() {
        when(inventarioRepository.findById(1L)).thenReturn(Optional.of(item1));

        Optional<Inventario> resultado = inventarioService.obtenerItemPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("dosis", resultado.get().getUnidad());
        verify(inventarioRepository, times(1)).findById(1L);
    }

    @Test
    void obtenerItemPorId_debeDevolverVacio_cuandoNoExiste() {
        when(inventarioRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Inventario> resultado = inventarioService.obtenerItemPorId(99L);

        assertFalse(resultado.isPresent());
        verify(inventarioRepository, times(1)).findById(99L);
    }

    @Test
    void actualizarItemInventario_debeActualizarYDevolverItem_cuandoExiste() {
        Inventario detallesNuevos = new Inventario("Vacuna Aviar", "Medicamento", new BigDecimal("50.00"), "ml", LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        
        when(inventarioRepository.findById(1L)).thenReturn(Optional.of(item1));
        when(inventarioRepository.save(any(Inventario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Inventario> resultado = inventarioService.actualizarItemInventario(1L, detallesNuevos);

        assertTrue(resultado.isPresent());
        assertEquals(new BigDecimal("50.00"), resultado.get().getCantidad());
        assertEquals("ml", resultado.get().getUnidad());
        verify(inventarioRepository, times(1)).findById(1L);
        verify(inventarioRepository, times(1)).save(item1);
    }

    @Test
    void actualizarItemInventario_debeDevolverVacio_cuandoNoExiste() {
        Inventario detallesNuevos = new Inventario("Inexistente", "N/A", new BigDecimal("1.0"), "unidad", LocalDate.now(), null);
        
        when(inventarioRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Inventario> resultado = inventarioService.actualizarItemInventario(99L, detallesNuevos);

        assertFalse(resultado.isPresent());
        verify(inventarioRepository, times(1)).findById(99L);
        verify(inventarioRepository, never()).save(any(Inventario.class));
    }

    @Test
    void eliminarItemInventario_debeDevolverTrue_cuandoExiste() {
        when(inventarioRepository.existsById(1L)).thenReturn(true);
        doNothing().when(inventarioRepository).deleteById(1L);

        boolean resultado = inventarioService.eliminarItemInventario(1L);

        assertTrue(resultado);
        verify(inventarioRepository, times(1)).existsById(1L);
        verify(inventarioRepository, times(1)).deleteById(1L);
    }

    @Test
    void eliminarItemInventario_debeDevolverFalse_cuandoNoExiste() {
        when(inventarioRepository.existsById(99L)).thenReturn(false);

        boolean resultado = inventarioService.eliminarItemInventario(99L);

        assertFalse(resultado);
        verify(inventarioRepository, times(1)).existsById(99L);
        verify(inventarioRepository, never()).deleteById(99L);
    }
}