package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.model.Alimentacion;
import com.skyline.demo.repository.AlimentacionRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest; 
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AlimentacionController.class)
public class AlimentacionControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private AlimentacionRepository alimentacionRepository;

    @Autowired 
    private ObjectMapper objectMapper;


    @Test
    void debeRegistrarAlimentacionYDevolver201() throws Exception {
    	//Entrada
        Alimentacion alimentacionEntrada = new Alimentacion();
        alimentacionEntrada.setLoteId(1L);
        alimentacionEntrada.setFecha(LocalDate.of(2025, 11, 18));
        alimentacionEntrada.setTipoAlimento("Inicio");
        alimentacionEntrada.setCantidadKg(new BigDecimal("150.50"));
        
        //Salida simulada
        Alimentacion alimentacionSalida = new Alimentacion();
        alimentacionSalida.setId(10L); 
        alimentacionSalida.setLoteId(1L);
        alimentacionSalida.setFecha(LocalDate.of(2025, 11, 18));
        alimentacionSalida.setTipoAlimento("Inicio");
        alimentacionSalida.setCantidadKg(new BigDecimal("150.50"));

        when(alimentacionRepository.save(any(Alimentacion.class))).thenReturn(alimentacionSalida);

        mockMvc.perform(post("/api/alimentacion")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(alimentacionEntrada)))
        
                .andExpect(status().isCreated()) //201 Created
                .andExpect(jsonPath("$.id").value(10L))
                .andExpect(jsonPath("$.tipoAlimento").value("Inicio"))
                // La cantidad debe coincidir con el valor de la entrada
                .andExpect(jsonPath("$.cantidadKg").value(150.50)); 
    }


    @Test
    void debeDevolverError400SiFaltaLoteId() throws Exception {
        // falta loteId
        Alimentacion alimentacionInvalida = new Alimentacion();
        alimentacionInvalida.setLoteId(null);
        alimentacionInvalida.setFecha(LocalDate.of(2025, 11, 18));
        alimentacionInvalida.setTipoAlimento("Crecimiento");
        alimentacionInvalida.setCantidadKg(new BigDecimal("100.00"));

        mockMvc.perform(post("/api/alimentacion")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(alimentacionInvalida)))
            
            .andExpect(status().isBadRequest()); //400 Bad Request
    }
    
    @Test
    void debeDevolverError400SiCantidadEsCero() throws Exception {
        // cantidad 0
        Alimentacion alimentacionInvalida = new Alimentacion();
        alimentacionInvalida.setLoteId(1L); 
        alimentacionInvalida.setFecha(LocalDate.of(2025, 11, 18));
        alimentacionInvalida.setTipoAlimento("Crecimiento");
        alimentacionInvalida.setCantidadKg(new BigDecimal("0.00"));

        mockMvc.perform(post("/api/alimentacion")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(alimentacionInvalida)))
            
            .andExpect(status().isBadRequest()); //400 Bad Request
    }
}