package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skyline.demo.model.Alimentacion;
import com.skyline.demo.service.AlimentacionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AlimentacionController.class)
public class AlimentacionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AlimentacionService alimentacionService;

    private ObjectMapper objectMapper;
    private Alimentacion registro1;
    private Alimentacion registro2;

    @BeforeEach
    void setUp() {
        objectMapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();

        registro1 = new Alimentacion(10L, LocalDate.of(2025, 1, 15), "Concentrado Inicial", new BigDecimal("50.50"));
        registro1.setId(1L);

        registro2 = new Alimentacion(11L, LocalDate.of(2025, 1, 16), "Concentrado Crecimiento", new BigDecimal("120.00"));
        registro2.setId(2L);
    }

    @Test
    void registrarAlimentacion_debeDevolver201_yRegistro() throws Exception {
        Alimentacion registroNuevo = new Alimentacion(12L, LocalDate.now(), "Vitaminas", new BigDecimal("5.00"));
        Alimentacion registroGuardado = new Alimentacion(12L, LocalDate.now(), "Vitaminas", new BigDecimal("5.00"));
        registroGuardado.setId(3L);

        when(alimentacionService.registrarAlimentacion(any(Alimentacion.class))).thenReturn(registroGuardado);

        mockMvc.perform(post("/api/alimentacion")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registroNuevo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3L))
                .andExpect(jsonPath("$.tipoAlimento").value("Vitaminas"));
        
        verify(alimentacionService, times(1)).registrarAlimentacion(any(Alimentacion.class));
    }

    @Test
    void obtenerTodos_debeDevolver200_yListaDeRegistros() throws Exception {
        when(alimentacionService.obtenerTodos()).thenReturn(Arrays.asList(registro1, registro2));

        mockMvc.perform(get("/api/alimentacion")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].tipoAlimento").value("Concentrado Inicial"));

        verify(alimentacionService, times(1)).obtenerTodos();
    }

    @Test
    void obtenerAlimentacionPorId_debeDevolver200_cuandoExiste() throws Exception {
        when(alimentacionService.obtenerAlimentacionPorId(1L)).thenReturn(Optional.of(registro1));

        mockMvc.perform(get("/api/alimentacion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tipoAlimento").value("Concentrado Inicial"));
        
        verify(alimentacionService, times(1)).obtenerAlimentacionPorId(1L);
    }

    @Test
    void obtenerAlimentacionPorId_debeDevolver404_cuandoNoExiste() throws Exception {
        when(alimentacionService.obtenerAlimentacionPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/alimentacion/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(alimentacionService, times(1)).obtenerAlimentacionPorId(99L);
    }

    @Test
    void actualizarAlimentacion_debeDevolver200_yRegistroActualizado() throws Exception {
        Alimentacion detallesNuevos = new Alimentacion(10L, LocalDate.now(), "Concentrado Final", new BigDecimal("75.25"));
        Alimentacion registroActualizado = new Alimentacion(10L, LocalDate.now(), "Concentrado Final", new BigDecimal("75.25"));
        registroActualizado.setId(1L);

        when(alimentacionService.actualizarAlimentacion(eq(1L), any(Alimentacion.class))).thenReturn(Optional.of(registroActualizado));

        mockMvc.perform(put("/api/alimentacion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cantidadKg").value(75.25))
                .andExpect(jsonPath("$.tipoAlimento").value("Concentrado Final"));
        
        verify(alimentacionService, times(1)).actualizarAlimentacion(eq(1L), any(Alimentacion.class));
    }

    @Test
    void actualizarAlimentacion_debeDevolver404_cuandoNoExiste() throws Exception {
        Alimentacion detallesNuevos = new Alimentacion(10L, LocalDate.now(), "Concentrado Final", new BigDecimal("75.25"));
        
        when(alimentacionService.actualizarAlimentacion(eq(99L), any(Alimentacion.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/alimentacion/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isNotFound());
        
        verify(alimentacionService, times(1)).actualizarAlimentacion(eq(99L), any(Alimentacion.class));
    }

    @Test
    void eliminarAlimentacion_debeDevolver204_cuandoExiste() throws Exception {
        when(alimentacionService.eliminarAlimentacion(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/alimentacion/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(alimentacionService, times(1)).eliminarAlimentacion(1L);
    }

    @Test
    void eliminarAlimentacion_debeDevolver404_cuandoNoExiste() throws Exception {
        when(alimentacionService.eliminarAlimentacion(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/alimentacion/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(alimentacionService, times(1)).eliminarAlimentacion(99L);
    }
}