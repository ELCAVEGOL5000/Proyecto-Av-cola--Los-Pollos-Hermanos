package com.skyline.demo.service;

import com.skyline.demo.model.Salud;
import com.skyline.demo.model.Salud.ResultadoControl;
import com.skyline.demo.repository.SaludRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class SaludServiceTest {

    @Mock
    private SaludRepository saludRepository;

    @InjectMocks
    private SaludService saludService;

    private Salud controlVacunacion;
    private Salud controlEnfermo;

    @BeforeEach
    void setUp() {
        // Control 1: Vacunación exitosa
        controlVacunacion = new Salud(
            1L, 
            LocalDate.now().minusDays(5), 
            "Vacunación NewCastle", 
            "Aplicación de vacuna NewCastle al lote completo.", 
            ResultadoControl.vacunado
        );
        controlVacunacion.setId(10L);

        // Control 2: Diagnóstico de enfermedad
        controlEnfermo = new Salud(
            2L, 
            LocalDate.now().minusDays(10), 
            "Control Respiratorio", 
            "Se detectaron 5 aves con síntomas respiratorios. Se inicia tratamiento.", 
            ResultadoControl.enfermo
        );
        controlEnfermo.setId(20L);
    }

    @Test
    void registrarControl_debeGuardarYDevolverControl() {
        when(saludRepository.save(any(Salud.class))).thenReturn(controlVacunacion);

        Salud resultado = saludService.registrarControl(controlVacunacion);

        assertNotNull(resultado);
        assertEquals(ResultadoControl.vacunado, resultado.getResultado());
        verify(saludRepository, times(1)).save(controlVacunacion);
    }

    @Test
    void obtenerTodosLosControles_debeDevolverListaDeControles() {
        List<Salud> controles = Arrays.asList(controlVacunacion, controlEnfermo);
        when(saludRepository.findAll()).thenReturn(controles);

        List<Salud> resultado = saludService.obtenerTodosLosControles();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(saludRepository, times(1)).findAll();
    }

    @Test
    void obtenerControlPorId_debeDevolverControl_cuandoExiste() {
        when(saludRepository.findById(10L)).thenReturn(Optional.of(controlVacunacion));

        Optional<Salud> resultado = saludService.obtenerControlPorId(10L);

        assertTrue(resultado.isPresent());
        assertEquals(1L, resultado.get().getLoteId());
        verify(saludRepository, times(1)).findById(10L);
    }

    @Test
    void obtenerControlPorId_debeDevolverVacio_cuandoNoExiste() {
        when(saludRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Salud> resultado = saludService.obtenerControlPorId(99L);

        assertFalse(resultado.isPresent());
        verify(saludRepository, times(1)).findById(99L);
    }

    @Test
    void actualizarControl_debeActualizarYDevolverControl_cuandoExiste() {
        Salud detallesNuevos = new Salud(
            1L, 
            LocalDate.now(), // Fecha actualizada
            "Vacunación NewCastle", 
            "Vacunación terminada y aprobada.", // Descripción actualizada
            ResultadoControl.saludable // Resultado actualizado
        );
        
        when(saludRepository.findById(10L)).thenReturn(Optional.of(controlVacunacion));
        when(saludRepository.save(any(Salud.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Salud> resultado = saludService.actualizarControl(10L, detallesNuevos);

        assertTrue(resultado.isPresent());
        assertEquals(ResultadoControl.saludable, resultado.get().getResultado());
        assertEquals("Vacunación terminada y aprobada.", resultado.get().getDescripcion());
        verify(saludRepository, times(1)).findById(10L);
        verify(saludRepository, times(1)).save(controlVacunacion);
    }

    @Test
    void actualizarControl_debeDevolverVacio_cuandoNoExiste() {
        Salud detallesNuevos = new Salud(1L, LocalDate.now(), "Control inexistente", "", ResultadoControl.saludable);
        
        when(saludRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Salud> resultado = saludService.actualizarControl(99L, detallesNuevos);

        assertFalse(resultado.isPresent());
        verify(saludRepository, times(1)).findById(99L);
        verify(saludRepository, never()).save(any(Salud.class));
    }

    @Test
    void eliminarControl_debeDevolverTrue_cuandoExiste() {
        when(saludRepository.existsById(10L)).thenReturn(true);
        doNothing().when(saludRepository).deleteById(10L);

        boolean resultado = saludService.eliminarControl(10L);

        assertTrue(resultado);
        verify(saludRepository, times(1)).existsById(10L);
        verify(saludRepository, times(1)).deleteById(10L);
    }

    @Test
    void eliminarControl_debeDevolverFalse_cuandoNoExiste() {
        when(saludRepository.existsById(99L)).thenReturn(false);

        boolean resultado = saludService.eliminarControl(99L);

        assertFalse(resultado);
        verify(saludRepository, times(1)).existsById(99L);
        verify(saludRepository, never()).deleteById(99L);
    }
}