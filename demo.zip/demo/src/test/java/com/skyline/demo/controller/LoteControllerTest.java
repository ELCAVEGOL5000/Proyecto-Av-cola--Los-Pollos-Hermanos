package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.model.Lote;
import com.skyline.demo.repository.LoteRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest; 
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List; 
import java.util.Optional; 
import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify; // Importar verify
import static org.mockito.Mockito.times; // Importar times
import static org.mockito.Mockito.never; // Importar never
import static org.mockito.ArgumentMatchers.anyLong; // Importar anyLong
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get; 
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put; 
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete; // Importar delete
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Prueba de Slice para LoteController usando @WebMvcTest.
 * Esta anotación carga solo la capa web, incluyendo el Controller,
 * el Validador y el manejo de excepciones de Spring.
 */
@WebMvcTest(LoteController.class)
public class LoteControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private LoteRepository loteRepository;

    @Autowired 
    private ObjectMapper objectMapper;


    @Test
    void debeRegistrarLoteYAsignarEstadoActivoPorDefecto() throws Exception {
        // entrada
        Lote loteEntrada = new Lote();
        loteEntrada.setCodigoLote("TEST-UNITARIO-001");
        loteEntrada.setTipo("Pollos de Prueba");
        loteEntrada.setCantidad(150);
        loteEntrada.setFechaInicio(LocalDate.of(2026, 5, 20));

        // salida simulada
        Lote loteSalida = new Lote();
        loteSalida.setId(50L); 
        loteSalida.setCodigoLote("TEST-UNITARIO-001");
        loteSalida.setTipo("Pollos de Prueba");
        loteSalida.setCantidad(150);
        loteSalida.setFechaInicio(LocalDate.of(2026, 5, 20));
        loteSalida.setEstado(Lote.EstadoLote.activo); 

        when(loteRepository.save(any(Lote.class))).thenReturn(loteSalida);

        mockMvc.perform(post("/api/lotes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loteEntrada)))
        
                .andExpect(status().isCreated()) // Espera 201 Created
                .andExpect(jsonPath("$.id").value(50L))
                .andExpect(jsonPath("$.estado").value("activo"));
    }

    @Test
    void debeDevolverError400SiFaltaCantidad() throws Exception {
        //Canitidad nula
        Lote loteInvalido = new Lote();
        loteInvalido.setCodigoLote("BAD-DATA-001");
        loteInvalido.setTipo("Pollos de Engorde");
        loteInvalido.setCantidad(null); 
        loteInvalido.setFechaInicio(LocalDate.of(2025, 10, 1));
        
        mockMvc.perform(post("/api/lotes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loteInvalido)))
            
            .andExpect(status().isBadRequest()); // 400 Bad Request
    }
    
    
    @Test
    void debeObtenerTodosLosLotesYDevolverStatus200() throws Exception {
        // lotes simulados
        Lote lote1 = new Lote();
        lote1.setId(1L);
        lote1.setCodigoLote("L-001");
        lote1.setTipo("Broiler");
        lote1.setCantidad(1000);
        lote1.setFechaInicio(LocalDate.of(2024, 1, 1));
        
        Lote lote2 = new Lote();
        lote2.setId(2L);
        lote2.setCodigoLote("L-002");
        lote2.setTipo("Ponedora");
        lote2.setCantidad(500);
        lote2.setFechaInicio(LocalDate.of(2024, 2, 1));
        
        List<Lote> lotesSimulados = List.of(lote1, lote2);
        
        when(loteRepository.findAll()).thenReturn(lotesSimulados);
        
        mockMvc.perform(get("/api/lotes")
                        .contentType(MediaType.APPLICATION_JSON))
                
                .andExpect(status().isOk()) // 200 OK
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].codigoLote").value("L-001"));
    }
    
    @Test
    void debeObtenerLotePorIdYDevolverStatus200() throws Exception {
        Long loteId = 1L;
        // Un lote simulado
        Lote loteSimulado = new Lote();
        loteSimulado.setId(loteId);
        loteSimulado.setCodigoLote("L-001-BUSCADO");
        loteSimulado.setTipo("Ponedora");
        loteSimulado.setCantidad(100);
        loteSimulado.setFechaInicio(LocalDate.of(2024, 5, 15));
        
        when(loteRepository.findById(loteId)).thenReturn(Optional.of(loteSimulado));
        
        mockMvc.perform(get("/api/lotes/{id}", loteId)
                        .contentType(MediaType.APPLICATION_JSON))
                
                .andExpect(status().isOk()) // 200 OK
                .andExpect(jsonPath("$.codigoLote").value("L-001-BUSCADO"));
    }
    
    @Test
    void debeDevolver404SiLoteNoExiste() throws Exception {
        Long loteId = 999L;
        
        when(loteRepository.findById(loteId)).thenReturn(Optional.empty());
        
        mockMvc.perform(get("/api/lotes/{id}", loteId)
                        .contentType(MediaType.APPLICATION_JSON))
                
                .andExpect(status().isNotFound()); // 404 Not Found
    }


    @Test
    void debeActualizarLoteExistenteYDevolverStatus200() throws Exception {
        Long loteId = 10L;
        
        Lote loteExistente = new Lote();
        loteExistente.setId(loteId);
        loteExistente.setCodigoLote("L-VIEJO-01");
        loteExistente.setCantidad(500);
        loteExistente.setEstado(Lote.EstadoLote.activo);
        loteExistente.setTipo("Carne");
        loteExistente.setFechaInicio(LocalDate.of(2024, 1, 1));
        
        Lote loteActualizadoEntrada = new Lote();
        loteActualizadoEntrada.setCodigoLote("L-NUEVO-02"); 
        loteActualizadoEntrada.setTipo("Carne");
        loteActualizadoEntrada.setCantidad(750); 
        loteActualizadoEntrada.setFechaInicio(LocalDate.of(2024, 1, 1));
        loteActualizadoEntrada.setEstado(Lote.EstadoLote.inactivo); 
        
        when(loteRepository.findById(loteId)).thenReturn(Optional.of(loteExistente));

        when(loteRepository.save(any(Lote.class))).thenAnswer(invocation -> {
            Lote savedLote = invocation.getArgument(0);
            savedLote.setId(loteId); 
            return savedLote;
        });

        mockMvc.perform(put("/api/lotes/{id}", loteId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loteActualizadoEntrada)))
                
                .andExpect(status().isOk()) // 200 OK
                .andExpect(jsonPath("$.codigoLote").value("L-NUEVO-02"))
                .andExpect(jsonPath("$.cantidad").value(750))
                .andExpect(jsonPath("$.estado").value("inactivo"));
    }
    

    @Test
    void debeEliminarLoteExistenteYDevolver204() throws Exception {
        Long loteId = 1L;
        // el lote existe
        when(loteRepository.existsById(loteId)).thenReturn(true);

        mockMvc.perform(delete("/api/lotes/{id}", loteId) 
                        .contentType(MediaType.APPLICATION_JSON))
                
                .andExpect(status().isNoContent()); // 204 No Content
        
        verify(loteRepository, times(1)).deleteById(loteId); 
    }
    
    @Test
    void debeDevolver404AlIntentarEliminarLoteNoExistente() throws Exception {
        Long loteId = 999L;
        
        //el lote NO existe
        when(loteRepository.existsById(loteId)).thenReturn(false);
        
        mockMvc.perform(delete("/api/lotes/{id}", loteId)
                        .contentType(MediaType.APPLICATION_JSON))
                
                .andExpect(status().isNotFound()); // 404 Not Found
        
        verify(loteRepository, never()).deleteById(anyLong());
    }
}