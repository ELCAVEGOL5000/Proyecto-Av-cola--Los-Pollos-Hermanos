package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skyline.demo.model.Lote;
import com.skyline.demo.service.LoteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LoteController.class)
public class LoteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LoteService loteService;

    private ObjectMapper objectMapper;
    private Lote loteActivo;
    private Lote loteInactivo;

    @BeforeEach
    void setUp() {
        objectMapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();

        loteActivo = new Lote("L001", "Broiler", 1000, LocalDate.now(), Lote.EstadoLote.activo);
        loteActivo.setId(1L);

        loteInactivo = new Lote("L002", "Ponedoras", 500, LocalDate.now().minusDays(30), Lote.EstadoLote.inactivo);
        loteInactivo.setId(2L);
    }

    @Test
    void registrarLote_debeDevolver201_yLote() throws Exception {
        Lote loteNuevo = new Lote("L003", "Pollitos", 200, LocalDate.now(), Lote.EstadoLote.activo);
        Lote loteGuardado = new Lote("L003", "Pollitos", 200, LocalDate.now(), Lote.EstadoLote.activo);
        loteGuardado.setId(3L);

        when(loteService.registrarLote(any(Lote.class))).thenReturn(loteGuardado);

        mockMvc.perform(post("/api/lotes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loteNuevo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3L))
                .andExpect(jsonPath("$.codigoLote").value("L003"));
        
        verify(loteService, times(1)).registrarLote(any(Lote.class));
    }

    @Test
    void obtenerTodos_debeDevolver200_yListaDeLotes() throws Exception {
        when(loteService.obtenerTodos()).thenReturn(Arrays.asList(loteActivo, loteInactivo));

        mockMvc.perform(get("/api/lotes")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].codigoLote").value("L001"));

        verify(loteService, times(1)).obtenerTodos();
    }

    @Test
    void obtenerLotePorId_debeDevolver200_cuandoExiste() throws Exception {
        when(loteService.obtenerLotePorId(1L)).thenReturn(Optional.of(loteActivo));

        mockMvc.perform(get("/api/lotes/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.codigoLote").value("L001"));
        
        verify(loteService, times(1)).obtenerLotePorId(1L);
    }

    @Test
    void obtenerLotePorId_debeDevolver404_cuandoNoExiste() throws Exception {
        when(loteService.obtenerLotePorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/lotes/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(loteService, times(1)).obtenerLotePorId(99L);
    }

    @Test
    void actualizarLote_debeDevolver200_yLoteActualizado() throws Exception {
        Lote detallesNuevos = new Lote("L001_UPD", "Broiler", 1500, LocalDate.now(), Lote.EstadoLote.inactivo);
        Lote loteActualizado = new Lote("L001_UPD", "Broiler", 1500, LocalDate.now(), Lote.EstadoLote.inactivo);
        loteActualizado.setId(1L);

        when(loteService.actualizarLote(eq(1L), any(Lote.class))).thenReturn(Optional.of(loteActualizado));

        mockMvc.perform(put("/api/lotes/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cantidad").value(1500))
                .andExpect(jsonPath("$.estado").value("inactivo"));
        
        verify(loteService, times(1)).actualizarLote(eq(1L), any(Lote.class));
    }

    @Test
    void actualizarLote_debeDevolver404_cuandoNoExiste() throws Exception {
        Lote detallesNuevos = new Lote("L001_UPD", "Broiler", 1500, LocalDate.now(), Lote.EstadoLote.inactivo);
        
        when(loteService.actualizarLote(eq(99L), any(Lote.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/lotes/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isNotFound());
        
        verify(loteService, times(1)).actualizarLote(eq(99L), any(Lote.class));
    }

    @Test
    void eliminarLote_debeDevolver204_cuandoExiste() throws Exception {
        when(loteService.eliminarLote(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/lotes/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(loteService, times(1)).eliminarLote(1L);
    }

    @Test
    void eliminarLote_debeDevolver404_cuandoNoExiste() throws Exception {
        when(loteService.eliminarLote(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/lotes/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(loteService, times(1)).eliminarLote(99L);
    }
}