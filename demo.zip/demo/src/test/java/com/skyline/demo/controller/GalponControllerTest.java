package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skyline.demo.model.Galpon;
import com.skyline.demo.model.Galpon.EstadoGalpon;
import com.skyline.demo.service.GalponService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(GalponController.class)
public class GalponControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private GalponService galponService;

    private ObjectMapper objectMapper;
    private Galpon galpon1;
    private Galpon galpon2;

    @BeforeEach
    void setUp() {
        // Necesario para serializar LocalDateTime y Enums
        objectMapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();

        galpon1 = new Galpon("Galpon A", "Sector Norte", 500, 10L, EstadoGalpon.activo);
        galpon1.setId(1L);
        galpon1.setCreadoEn(LocalDateTime.now().minusDays(5));

        galpon2 = new Galpon("Galpon B", "Sector Sur", 800, null, EstadoGalpon.mantenimiento);
        galpon2.setId(2L);
        galpon2.setCreadoEn(LocalDateTime.now().minusDays(1));
    }

    @Test
    void crearGalpon_debeDevolver201_yGalponCreado() throws Exception {
        Galpon galponNuevo = new Galpon("Galpon C", "Sector Este", 200, null, EstadoGalpon.inactivo);
        Galpon galponGuardado = new Galpon("Galpon C", "Sector Este", 200, null, EstadoGalpon.inactivo);
        galponGuardado.setId(3L);
        galponGuardado.setCreadoEn(LocalDateTime.now());

        when(galponService.crearGalpon(any(Galpon.class))).thenReturn(galponGuardado);

        mockMvc.perform(post("/api/galpones")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(galponNuevo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3L))
                .andExpect(jsonPath("$.nombre").value("Galpon C"));
        
        verify(galponService, times(1)).crearGalpon(any(Galpon.class));
    }

    @Test
    void obtenerTodosLosGalpones_debeDevolver200_yLista() throws Exception {
        when(galponService.obtenerTodosLosGalpones()).thenReturn(Arrays.asList(galpon1, galpon2));

        mockMvc.perform(get("/api/galpones")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].estado").value("activo"));

        verify(galponService, times(1)).obtenerTodosLosGalpones();
    }

    @Test
    void obtenerGalponPorId_debeDevolver200_cuandoExiste() throws Exception {
        when(galponService.obtenerGalponPorId(1L)).thenReturn(Optional.of(galpon1));

        mockMvc.perform(get("/api/galpones/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ubicacion").value("Sector Norte"));
        
        verify(galponService, times(1)).obtenerGalponPorId(1L);
    }

    @Test
    void obtenerGalponPorId_debeDevolver404_cuandoNoExiste() throws Exception {
        when(galponService.obtenerGalponPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/galpones/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(galponService, times(1)).obtenerGalponPorId(99L);
    }

    @Test
    void actualizarGalpon_debeDevolver200_yGalponActualizado() throws Exception {
        Galpon detallesNuevos = new Galpon("Galpon A v2", "Sector Norte", 550, 10L, EstadoGalpon.activo);
        Galpon galponActualizado = new Galpon("Galpon A v2", "Sector Norte", 550, 10L, EstadoGalpon.activo);
        galponActualizado.setId(1L);

        when(galponService.actualizarGalpon(eq(1L), any(Galpon.class))).thenReturn(Optional.of(galponActualizado));

        mockMvc.perform(put("/api/galpones/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.capacidad").value(550))
                .andExpect(jsonPath("$.nombre").value("Galpon A v2"));
        
        verify(galponService, times(1)).actualizarGalpon(eq(1L), any(Galpon.class));
    }

    @Test
    void actualizarGalpon_debeDevolver404_cuandoNoExiste() throws Exception {
        Galpon detallesNuevos = new Galpon("Galpon Fantasma", "N/A", 100, null, EstadoGalpon.activo);
        
        when(galponService.actualizarGalpon(eq(99L), any(Galpon.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/galpones/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isNotFound());
        
        verify(galponService, times(1)).actualizarGalpon(eq(99L), any(Galpon.class));
    }

    @Test
    void eliminarGalpon_debeDevolver204_cuandoExiste() throws Exception {
        when(galponService.eliminarGalpon(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/galpones/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(galponService, times(1)).eliminarGalpon(1L);
    }

    @Test
    void eliminarGalpon_debeDevolver404_cuandoNoExiste() throws Exception {
        when(galponService.eliminarGalpon(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/galpones/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(galponService, times(1)).eliminarGalpon(99L);
    }
}