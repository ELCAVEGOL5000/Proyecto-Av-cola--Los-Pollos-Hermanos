package com.skyline.demo.service;

import com.skyline.demo.model.Alimentacion;
import com.skyline.demo.repository.AlimentacionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class AlimentacionServiceTest {

    @Mock
    private AlimentacionRepository alimentacionRepository;

    @InjectMocks
    private AlimentacionService alimentacionService;

    private Alimentacion registro1;
    private Alimentacion registro2;

    @BeforeEach
    void setUp() {
        registro1 = new Alimentacion(10L, LocalDate.of(2025, 1, 15), "Concentrado Inicio", new BigDecimal("50.50"));
        registro1.setId(1L);

        registro2 = new Alimentacion(11L, LocalDate.of(2025, 1, 16), "Concentrado Engorde", new BigDecimal("120.00"));
        registro2.setId(2L);
    }

    @Test
    void registrarAlimentacion_debeGuardarYDevolverRegistro() {
        when(alimentacionRepository.save(any(Alimentacion.class))).thenReturn(registro1);

        Alimentacion resultado = alimentacionService.registrarAlimentacion(registro1);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals(new BigDecimal("50.50"), resultado.getCantidadKg());
        verify(alimentacionRepository, times(1)).save(registro1);
    }

    @Test
    void obtenerTodos_debeDevolverTodosLosRegistros() {
        List<Alimentacion> registros = Arrays.asList(registro1, registro2);
        when(alimentacionRepository.findAll()).thenReturn(registros);

        List<Alimentacion> resultado = alimentacionService.obtenerTodos();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(alimentacionRepository, times(1)).findAll();
    }

    @Test
    void obtenerAlimentacionPorId_debeDevolverRegistro_cuandoExiste() {
        when(alimentacionRepository.findById(1L)).thenReturn(Optional.of(registro1));

        Optional<Alimentacion> resultado = alimentacionService.obtenerAlimentacionPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Concentrado Inicio", resultado.get().getTipoAlimento());
        verify(alimentacionRepository, times(1)).findById(1L);
    }

    @Test
    void obtenerAlimentacionPorId_debeDevolverVacio_cuandoNoExiste() {
        when(alimentacionRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Alimentacion> resultado = alimentacionService.obtenerAlimentacionPorId(99L);

        assertFalse(resultado.isPresent());
        verify(alimentacionRepository, times(1)).findById(99L);
    }

    @Test
    void actualizarAlimentacion_debeActualizarYDevolverRegistro_cuandoExiste() {
        Alimentacion detallesNuevos = new Alimentacion(10L, LocalDate.of(2025, 1, 15), "Concentrado Final", new BigDecimal("75.25"));
        
        when(alimentacionRepository.findById(1L)).thenReturn(Optional.of(registro1));
        when(alimentacionRepository.save(any(Alimentacion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Alimentacion> resultado = alimentacionService.actualizarAlimentacion(1L, detallesNuevos);

        assertTrue(resultado.isPresent());
        assertEquals("Concentrado Final", resultado.get().getTipoAlimento());
        assertEquals(new BigDecimal("75.25"), resultado.get().getCantidadKg());
        verify(alimentacionRepository, times(1)).findById(1L);
        verify(alimentacionRepository, times(1)).save(registro1);
    }

    @Test
    void actualizarAlimentacion_debeDevolverVacio_cuandoNoExiste() {
        Alimentacion detallesNuevos = new Alimentacion(10L, LocalDate.of(2025, 1, 15), "Concentrado Final", new BigDecimal("75.25"));
        
        when(alimentacionRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Alimentacion> resultado = alimentacionService.actualizarAlimentacion(99L, detallesNuevos);

        assertFalse(resultado.isPresent());
        verify(alimentacionRepository, times(1)).findById(99L);
        verify(alimentacionRepository, never()).save(any(Alimentacion.class));
    }

    @Test
    void eliminarAlimentacion_debeDevolverTrue_cuandoExiste() {
        when(alimentacionRepository.existsById(1L)).thenReturn(true);
        doNothing().when(alimentacionRepository).deleteById(1L);

        boolean resultado = alimentacionService.eliminarAlimentacion(1L);

        assertTrue(resultado);
        verify(alimentacionRepository, times(1)).existsById(1L);
        verify(alimentacionRepository, times(1)).deleteById(1L);
    }

    @Test
    void eliminarAlimentacion_debeDevolverFalse_cuandoNoExiste() {
        when(alimentacionRepository.existsById(99L)).thenReturn(false);

        boolean resultado = alimentacionService.eliminarAlimentacion(99L);

        assertFalse(resultado);
        verify(alimentacionRepository, times(1)).existsById(99L);
        verify(alimentacionRepository, never()).deleteById(99L);
    }
}