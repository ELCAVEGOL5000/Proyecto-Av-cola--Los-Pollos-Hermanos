package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skyline.demo.model.Inventario;
import com.skyline.demo.service.InventarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(InventarioController.class)
public class InventarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InventarioService inventarioService;

    private ObjectMapper objectMapper;
    private Inventario item1;
    private Inventario item2;

    @BeforeEach
    void setUp() {
        // Configurar ObjectMapper para manejar LocalDate
        objectMapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();

        item1 = new Inventario("Vacuna Aviar", "Medicamento", new BigDecimal("100.00"), "dosis", LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        item1.setId(1L);

        item2 = new Inventario("Concentrado Etapa 2", "Alimento", new BigDecimal("5000.50"), "kg", LocalDate.of(2025, 2, 10), null);
        item2.setId(2L);
    }

    @Test
    void crearItemInventario_debeDevolver201_yItemCreado() throws Exception {
        Inventario itemNuevo = new Inventario("Desinfectante", "Limpieza", new BigDecimal("25.0"), "litros", LocalDate.now(), null);
        Inventario itemGuardado = new Inventario("Desinfectante", "Limpieza", new BigDecimal("25.0"), "litros", LocalDate.now(), null);
        itemGuardado.setId(3L);

        when(inventarioService.crearItemInventario(any(Inventario.class))).thenReturn(itemGuardado);

        mockMvc.perform(post("/api/inventario")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(itemNuevo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3L))
                .andExpect(jsonPath("$.nombre").value("Desinfectante"));
        
        verify(inventarioService, times(1)).crearItemInventario(any(Inventario.class));
    }

    @Test
    void obtenerTodosLosItems_debeDevolver200_yListaDeItems() throws Exception {
        when(inventarioService.obtenerTodosLosItems()).thenReturn(Arrays.asList(item1, item2));

        mockMvc.perform(get("/api/inventario")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].tipo").value("Medicamento"));

        verify(inventarioService, times(1)).obtenerTodosLosItems();
    }

    @Test
    void obtenerItemPorId_debeDevolver200_cuandoExiste() throws Exception {
        when(inventarioService.obtenerItemPorId(1L)).thenReturn(Optional.of(item1));

        mockMvc.perform(get("/api/inventario/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cantidad").value(100.00))
                .andExpect(jsonPath("$.nombre").value("Vacuna Aviar"));
        
        verify(inventarioService, times(1)).obtenerItemPorId(1L);
    }

    @Test
    void obtenerItemPorId_debeDevolver404_cuandoNoExiste() throws Exception {
        when(inventarioService.obtenerItemPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/inventario/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(inventarioService, times(1)).obtenerItemPorId(99L);
    }

    @Test
    void actualizarItemInventario_debeDevolver200_yItemActualizado() throws Exception {
        Inventario detallesNuevos = new Inventario("Vacuna Aviar", "Medicamento", new BigDecimal("50.00"), "dosis", LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        Inventario itemActualizado = new Inventario("Vacuna Aviar", "Medicamento", new BigDecimal("50.00"), "dosis", LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        itemActualizado.setId(1L);

        when(inventarioService.actualizarItemInventario(eq(1L), any(Inventario.class))).thenReturn(Optional.of(itemActualizado));

        mockMvc.perform(put("/api/inventario/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cantidad").value(50.00))
                .andExpect(jsonPath("$.unidad").value("dosis"));
        
        verify(inventarioService, times(1)).actualizarItemInventario(eq(1L), any(Inventario.class));
    }

    @Test
    void actualizarItemInventario_debeDevolver404_cuandoNoExiste() throws Exception {
        Inventario detallesNuevos = new Inventario("Inexistente", "N/A", new BigDecimal("1.0"), "unidad", LocalDate.now(), null);
        
        when(inventarioService.actualizarItemInventario(eq(99L), any(Inventario.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/inventario/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isNotFound());
        
        verify(inventarioService, times(1)).actualizarItemInventario(eq(99L), any(Inventario.class));
    }

    @Test
    void eliminarItemInventario_debeDevolver204_cuandoExiste() throws Exception {
        when(inventarioService.eliminarItemInventario(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/inventario/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(inventarioService, times(1)).eliminarItemInventario(1L);
    }

    @Test
    void eliminarItemInventario_debeDevolver404_cuandoNoExiste() throws Exception {
        when(inventarioService.eliminarItemInventario(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/inventario/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(inventarioService, times(1)).eliminarItemInventario(99L);
    }
}