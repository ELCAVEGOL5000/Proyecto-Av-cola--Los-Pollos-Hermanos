package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.model.Inventario;
import com.skyline.demo.repository.InventarioRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest; 
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(InventarioController.class)
public class InventarioControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private InventarioRepository inventarioRepository;

    @Autowired 
    private ObjectMapper objectMapper;

    
    private Inventario crearItemBase() {
        Inventario item = new Inventario();
        item.setNombre("Alimento Balanceado"); 
        item.setTipo("Materia Prima");        
        item.setUnidad("kg");                 
        item.setCantidad(new BigDecimal("500.00"));
        item.setFechaIngreso(LocalDate.of(2025, 11, 1)); 
        item.setFechaVencimiento(LocalDate.of(2026, 5, 1)); 
        return item;
    }

    @Test
    void debeRegistrarNuevoItemYDevolver201() throws Exception {
        Inventario nuevoItem = crearItemBase();
        nuevoItem.setId(1L);

        when(inventarioRepository.save(any(Inventario.class))).thenReturn(nuevoItem);

        mockMvc.perform(post("/api/inventario")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(crearItemBase())))
                
                .andExpect(status().isCreated()) //201 Created
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.nombre").value("Alimento Balanceado")) 
                .andExpect(jsonPath("$.cantidad").value(500.00));    
    }

    @Test
    void debeDevolver400SiFaltaNombreEnPost() throws Exception {
        Inventario itemInvalido = crearItemBase();
        itemInvalido.setNombre(null); 

        mockMvc.perform(post("/api/inventario")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(itemInvalido)))
                
                .andExpect(status().isBadRequest()); // 400 Bad Request
    }


    @Test
    void debeActualizarItemYDevolver200() throws Exception {
        Long itemId = 2L;
        Inventario itemExistente = crearItemBase();
        itemExistente.setId(itemId);

        Inventario itemActualizadoDetails = crearItemBase();
        itemActualizadoDetails.setCantidad(new BigDecimal("1200.50"));
        itemActualizadoDetails.setUnidad("Sacos"); 

        // WHEN: Simulación de búsqueda y guardado
        when(inventarioRepository.findById(itemId)).thenReturn(Optional.of(itemExistente));
        when(inventarioRepository.save(any(Inventario.class))).thenAnswer(invocation -> {
            Inventario savedItem = invocation.getArgument(0);
            savedItem.setId(itemId);
            return savedItem;
        });

        mockMvc.perform(put("/api/inventario/{id}", itemId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(itemActualizadoDetails)))
                
                .andExpect(status().isOk()) // Espera 200 OK
                .andExpect(jsonPath("$.id").value(itemId))
                .andExpect(jsonPath("$.unidad").value("Sacos"))     
                .andExpect(jsonPath("$.cantidad").value(1200.50)); 
    }

    @Test
    void debeDevolver404SiItemNoExisteEnPut() throws Exception {
        Long itemId = 99L;

        when(inventarioRepository.findById(itemId)).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/inventario/{id}", itemId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(crearItemBase())))
                
                .andExpect(status().isNotFound()); // 404 Not Found
    }
}