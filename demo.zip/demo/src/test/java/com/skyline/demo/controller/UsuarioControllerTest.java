package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.model.Usuario;
import com.skyline.demo.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Autowired
    private ObjectMapper objectMapper;

    private Usuario usuarioOperario;
    private Usuario usuarioAdmin;

    @BeforeEach
    void setUp() {
        usuarioOperario = new Usuario("Juan", "Perez", "juan.perez@test.com", "pass12345678", Usuario.Rol.OPERARIO);
        usuarioOperario.setId(1L);

        usuarioAdmin = new Usuario("Ana", "Gomez", "ana.gomez@test.com", "adminPass8765", Usuario.Rol.ADMIN);
        usuarioAdmin.setId(2L);
    }

    @Test
    void crearUsuario_debeRetornar201YUsuarioCreado() throws Exception {
        when(usuarioService.crearUsuario(any(Usuario.class))).thenReturn(usuarioOperario);

        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(usuarioOperario)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.nombre").value("Juan"))
                .andExpect(jsonPath("$.rol").value("OPERARIO"));

        verify(usuarioService, times(1)).crearUsuario(any(Usuario.class));
    }

    @Test
    void crearUsuario_conEmailExistente_debeRetornar400() throws Exception {
        when(usuarioService.crearUsuario(any(Usuario.class))).thenThrow(new IllegalArgumentException("El email juan.perez@test.com ya está en uso."));

        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(usuarioOperario)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("El email juan.perez@test.com ya está en uso."));

        verify(usuarioService, times(1)).crearUsuario(any(Usuario.class));
    }

    @Test
    void crearUsuario_conValidacionFallida_debeRetornar400() throws Exception {
        Usuario usuarioInvalido = new Usuario("Corto", "Apellido", "invalid-email", "pass", Usuario.Rol.OPERARIO);

        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(usuarioInvalido)))
                .andExpect(status().isBadRequest());
        
        verify(usuarioService, never()).crearUsuario(any(Usuario.class));
    }

    @Test
    void obtenerTodosLosUsuarios_debeRetornar200YListaDeUsuarios() throws Exception {
        when(usuarioService.obtenerTodosLosUsuarios()).thenReturn(Arrays.asList(usuarioOperario, usuarioAdmin));

        mockMvc.perform(get("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].nombre").value("Juan"));
        
        verify(usuarioService, times(1)).obtenerTodosLosUsuarios();
    }

    @Test
    void obtenerUsuarioPorId_conIdExistente_debeRetornar200YUsuario() throws Exception {
        when(usuarioService.obtenerUsuarioPorId(1L)).thenReturn(Optional.of(usuarioOperario));

        mockMvc.perform(get("/api/usuarios/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Juan"));
        
        verify(usuarioService, times(1)).obtenerUsuarioPorId(1L);
    }

    @Test
    void obtenerUsuarioPorId_conIdNoExistente_debeRetornar404() throws Exception {
        when(usuarioService.obtenerUsuarioPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/usuarios/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(usuarioService, times(1)).obtenerUsuarioPorId(99L);
    }

    @Test
    void actualizarUsuario_debeRetornar200YUsuarioActualizado() throws Exception {
        Usuario detallesActualizados = new Usuario("Juancito", "Perez", "juan.perez.nuevo@test.com", "passNuevo1234", Usuario.Rol.SUPERVISOR);
        detallesActualizados.setId(1L);

        when(usuarioService.actualizarUsuario(eq(1L), any(Usuario.class))).thenReturn(Optional.of(detallesActualizados));

        mockMvc.perform(put("/api/usuarios/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesActualizados)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Juancito"))
                .andExpect(jsonPath("$.rol").value("SUPERVISOR"));

        verify(usuarioService, times(1)).actualizarUsuario(eq(1L), any(Usuario.class));
    }

    @Test
    void actualizarUsuario_conIdNoExistente_debeRetornar404() throws Exception {
        Usuario detallesActualizados = new Usuario("Juancito", "Perez", "juan.perez.nuevo@test.com", "passNuevo1234", Usuario.Rol.SUPERVISOR);
        
        when(usuarioService.actualizarUsuario(eq(99L), any(Usuario.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/usuarios/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesActualizados)))
                .andExpect(status().isNotFound());

        verify(usuarioService, times(1)).actualizarUsuario(eq(99L), any(Usuario.class));
    }

    @Test
    void actualizarUsuario_conEmailDeOtroUsuario_debeRetornar400() throws Exception {
        Usuario detallesConflictivos = new Usuario("Juan", "Perez", usuarioAdmin.getEmail(), "passNuevo1234", Usuario.Rol.SUPERVISOR);

        when(usuarioService.actualizarUsuario(eq(1L), any(Usuario.class)))
            .thenThrow(new IllegalArgumentException("El email ana.gomez@test.com ya está en uso por otro usuario."));

        mockMvc.perform(put("/api/usuarios/{id}", 1L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesConflictivos)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("El email ana.gomez@test.com ya está en uso por otro usuario."));

        verify(usuarioService, times(1)).actualizarUsuario(eq(1L), any(Usuario.class));
    }

    @Test
    void eliminarUsuario_conIdExistente_debeRetornar204() throws Exception {
        when(usuarioService.eliminarUsuario(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/usuarios/{id}", 1L))
                .andExpect(status().isNoContent());

        verify(usuarioService, times(1)).eliminarUsuario(1L);
    }

    @Test
    void eliminarUsuario_conIdNoExistente_debeRetornar404() throws Exception {
        when(usuarioService.eliminarUsuario(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/usuarios/{id}", 99L))
                .andExpect(status().isNotFound());

        verify(usuarioService, times(1)).eliminarUsuario(99L);
    }
}