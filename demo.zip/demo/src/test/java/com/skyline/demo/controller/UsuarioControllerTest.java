package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.exception.EmailDuplicadoException;
import com.skyline.demo.model.Rol;
import com.skyline.demo.model.Usuario;
import com.skyline.demo.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.containsString;

/**
 * Pruebas unitarias para UsuarioController.
 * Se ha aplicado una estrategia de aislamiento de objetos de modelo (Usuario) 
 * dentro de cada test para evitar la contaminación de estado (shared mutable state) 
 * entre ejecuciones de pruebas.
 */
@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @SuppressWarnings("removal")
	@MockBean
    private UsuarioRepository usuarioRepository;

    private Usuario usuarioExistente;

    @BeforeEach
    void setUp() {
        usuarioExistente = new Usuario();
        usuarioExistente.setId(1L);
        usuarioExistente.setNombre("Juan");
        usuarioExistente.setApellido("Perez");
        usuarioExistente.setEmail("juan.perez@test.com");
        usuarioExistente.setPassword("password123");
        usuarioExistente.setRol(Rol.OPERARIO);
    }

    @Test
    void testCrearUsuario_Exito() throws Exception {
        Usuario usuarioNuevo = new Usuario();
        usuarioNuevo.setNombre("Ana");
        usuarioNuevo.setApellido("Gomez");
        usuarioNuevo.setEmail("ana.gomez.nuevo@test.com");
        usuarioNuevo.setPassword("segura456");
        usuarioNuevo.setRol(Rol.ADMIN);
        
        when(usuarioRepository.findByEmail(usuarioNuevo.getEmail())).thenReturn(Optional.empty());
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuarioExistente);

        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuarioNuevo)))
                .andExpect(status().isCreated()) //HTTP 201
                .andExpect(jsonPath("$.id").value(usuarioExistente.getId()))
                .andExpect(jsonPath("$.rol").value(Rol.OPERARIO.toString()));
    }

    @Test
    void testCrearUsuario_EmailDuplicado() throws Exception {
        Usuario usuarioDuplicado = new Usuario();
        usuarioDuplicado.setNombre("Ana");
        usuarioDuplicado.setApellido("Gomez");
        usuarioDuplicado.setEmail("ana.gomez@test.com");
        usuarioDuplicado.setPassword("segura456");
        usuarioDuplicado.setRol(Rol.ADMIN);
        
        when(usuarioRepository.findByEmail(usuarioDuplicado.getEmail())).thenReturn(Optional.of(usuarioExistente));

        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuarioDuplicado)))
                .andExpect(status().isConflict()) //HTTP 409
                .andExpect(result -> assertTrue(result.getResolvedException() instanceof EmailDuplicadoException))
                .andExpect(content().string(containsString("ya está registrado")));
    }
    
    @Test
    void testCrearUsuario_PasswordCorta() throws Exception {
        Usuario userInvalido = new Usuario();
        userInvalido.setNombre("Juan");
        userInvalido.setApellido("Perez");
        userInvalido.setEmail("juan.invalido@test.com");
        userInvalido.setRol(Rol.OPERARIO);
        
        userInvalido.setPassword("corta"); // Menos de 8 caracteres

        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userInvalido)))
                
                .andExpect(status().isBadRequest()) // HTTP 400
                .andExpect(content().string(containsString("La contraseña debe tener al menos 8 caracteres.")));
    }

    @Test
    void testObtenerUsuarioPorId_Exito() throws Exception {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));

        mockMvc.perform(get("/api/usuarios/{id}", 1L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Juan"))
                .andExpect(jsonPath("$.email").value("juan.perez@test.com"));
    }
    
    @Test
    void testActualizarUsuario_Exito() throws Exception {
        Usuario detallesActualizados = new Usuario();
        detallesActualizados.setNombre("Juan Carlos");
        detallesActualizados.setApellido("Perez"); 
        detallesActualizados.setRol(Rol.SUPERVISOR);
        detallesActualizados.setEmail("juan.carlos.perez@test.com");
        detallesActualizados.setPassword("newpass456"); // Contraseña válida

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));
        when(usuarioRepository.findByEmail(detallesActualizados.getEmail())).thenReturn(Optional.empty());
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(invocation -> {
            Usuario savedUser = invocation.getArgument(0);
            savedUser.setId(1L);
            return savedUser;
        });

        mockMvc.perform(put("/api/usuarios/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(detallesActualizados)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Juan Carlos"))
                .andExpect(jsonPath("$.rol").value(Rol.SUPERVISOR.toString()));
    }
    
    @Test
    void testActualizarUsuario_EmailDuplicadoPorOtroUsuario() throws Exception {
        Usuario otroUsuario = new Usuario();
        otroUsuario.setId(2L);
        otroUsuario.setEmail("duplicado@test.com");
        
        // El usuario a actualizar es el 1L (Juan)
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));
        // Pero el nuevo email pertenece al 2L (otroUsuario)
        when(usuarioRepository.findByEmail("duplicado@test.com")).thenReturn(Optional.of(otroUsuario));

        Usuario detallesConEmailDuplicado = new Usuario();
        detallesConEmailDuplicado.setNombre(usuarioExistente.getNombre());
        detallesConEmailDuplicado.setApellido(usuarioExistente.getApellido());
        detallesConEmailDuplicado.setPassword(usuarioExistente.getPassword());
        detallesConEmailDuplicado.setRol(usuarioExistente.getRol());
        
        // Establecemos el email que causará el conflicto
        detallesConEmailDuplicado.setEmail("duplicado@test.com");

        mockMvc.perform(put("/api/usuarios/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(detallesConEmailDuplicado)))
                .andExpect(status().isConflict()) //HTTP 409
                .andExpect(result -> assertTrue(result.getResolvedException() instanceof EmailDuplicadoException));
    }


    @Test
    void testEliminarUsuario_Exito() throws Exception {
        when(usuarioRepository.existsById(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/usuarios/{id}", 1L))
                .andExpect(status().isNoContent()); //HTTP 204
        verify(usuarioRepository, times(1)).deleteById(1L);
    }
    
    @Test
    void testEliminarUsuario_NoEncontrado() throws Exception {
        when(usuarioRepository.existsById(anyLong())).thenReturn(false);

        mockMvc.perform(delete("/api/usuarios/{id}", 99L))
                .andExpect(status().isNotFound()); // HTTP 404
        
        verify(usuarioRepository, never()).deleteById(anyLong());
    }
}