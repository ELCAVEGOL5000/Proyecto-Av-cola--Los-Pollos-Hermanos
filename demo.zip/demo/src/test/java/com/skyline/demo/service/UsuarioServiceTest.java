package com.skyline.demo.service;

import com.skyline.demo.model.Usuario;
import com.skyline.demo.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuarioOperario;
    private Usuario usuarioAdmin;

    @BeforeEach
    void setUp() {
        usuarioOperario = new Usuario("Juan", "Perez", "juan.perez@test.com", "pass12345", Usuario.Rol.OPERARIO);
        usuarioOperario.setId(1L);

        usuarioAdmin = new Usuario("Ana", "Gomez", "ana.gomez@test.com", "adminPass", Usuario.Rol.ADMIN);
        usuarioAdmin.setId(2L);
    }

    @Test
    void obtenerTodosLosUsuarios_debeRetornarListaDeUsuarios() {
        List<Usuario> usuarios = Arrays.asList(usuarioOperario, usuarioAdmin);
        when(usuarioRepository.findAll()).thenReturn(usuarios);

        List<Usuario> resultado = usuarioService.obtenerTodosLosUsuarios();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(usuarioRepository, times(1)).findAll();
    }

    @Test
    void obtenerUsuarioPorId_conIdExistente_debeRetornarOptionalConUsuario() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOperario));

        Optional<Usuario> resultado = usuarioService.obtenerUsuarioPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Juan", resultado.get().getNombre());
        verify(usuarioRepository, times(1)).findById(1L);
    }

    @Test
    void obtenerUsuarioPorId_conIdNoExistente_debeRetornarOptionalVacio() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Usuario> resultado = usuarioService.obtenerUsuarioPorId(99L);

        assertFalse(resultado.isPresent());
        verify(usuarioRepository, times(1)).findById(99L);
    }

    @Test
    void crearUsuario_conEmailNuevo_debeGuardarYRetornarUsuario() {
        when(usuarioRepository.findByEmail(usuarioOperario.getEmail())).thenReturn(Optional.empty());
        when(usuarioRepository.save(usuarioOperario)).thenReturn(usuarioOperario);

        Usuario resultado = usuarioService.crearUsuario(usuarioOperario);

        assertNotNull(resultado);
        assertEquals(usuarioOperario.getEmail(), resultado.getEmail());
        verify(usuarioRepository, times(1)).findByEmail(usuarioOperario.getEmail());
        verify(usuarioRepository, times(1)).save(usuarioOperario);
    }

    @Test
    void crearUsuario_conEmailExistente_debeLanzarExcepcion() {
        when(usuarioRepository.findByEmail(usuarioOperario.getEmail())).thenReturn(Optional.of(usuarioOperario));

        assertThrows(IllegalArgumentException.class, () -> {
            usuarioService.crearUsuario(usuarioOperario);
        });

        verify(usuarioRepository, times(1)).findByEmail(usuarioOperario.getEmail());
        verify(usuarioRepository, never()).save(any(Usuario.class));
    }

    @Test
    void actualizarUsuario_conIdExistenteYEmailIgual_debeActualizarYRetornarOptionalConUsuario() {
        Usuario detallesActualizados = new Usuario("Juancito", "Perez", "juan.perez@test.com", "newPass", Usuario.Rol.SUPERVISOR);
        detallesActualizados.setId(1L);

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOperario));
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Usuario> resultado = usuarioService.actualizarUsuario(1L, detallesActualizados);

        assertTrue(resultado.isPresent());
        assertEquals("Juancito", resultado.get().getNombre());
        assertEquals(Usuario.Rol.SUPERVISOR, resultado.get().getRol());
        verify(usuarioRepository, times(1)).findById(1L);
        verify(usuarioRepository, never()).findByEmail(anyString());
        verify(usuarioRepository, times(1)).save(any(Usuario.class));
    }

    @Test
    void actualizarUsuario_conIdExistenteYEmailNuevo_debeActualizarYRetornarOptionalConUsuario() {
        Usuario detallesActualizados = new Usuario("Ana", "Gomez", "ana.gomez.new@test.com", "newPass", Usuario.Rol.ADMIN);
        detallesActualizados.setId(2L);

        when(usuarioRepository.findById(2L)).thenReturn(Optional.of(usuarioAdmin));
        when(usuarioRepository.findByEmail("ana.gomez.new@test.com")).thenReturn(Optional.empty());
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Usuario> resultado = usuarioService.actualizarUsuario(2L, detallesActualizados);

        assertTrue(resultado.isPresent());
        assertEquals("Ana", resultado.get().getNombre());
        assertEquals("ana.gomez.new@test.com", resultado.get().getEmail());
        verify(usuarioRepository, times(1)).findById(2L);
        verify(usuarioRepository, times(1)).findByEmail("ana.gomez.new@test.com");
        verify(usuarioRepository, times(1)).save(any(Usuario.class));
    }

    @Test
    void actualizarUsuario_conIdExistenteYEmailDeOtroUsuario_debeLanzarExcepcion() {
        Usuario detallesActualizados = new Usuario("Juan", "Perez", usuarioAdmin.getEmail(), "pass12345", Usuario.Rol.OPERARIO);

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOperario));
        when(usuarioRepository.findByEmail(usuarioAdmin.getEmail())).thenReturn(Optional.of(usuarioAdmin));

        assertThrows(IllegalArgumentException.class, () -> {
            usuarioService.actualizarUsuario(1L, detallesActualizados);
        });

        verify(usuarioRepository, times(1)).findById(1L);
        verify(usuarioRepository, times(1)).findByEmail(usuarioAdmin.getEmail());
        verify(usuarioRepository, never()).save(any(Usuario.class));
    }

    @Test
    void actualizarUsuario_conIdNoExistente_debeRetornarOptionalVacio() {
        Usuario detallesActualizados = new Usuario("Inexistente", "User", "notfound@test.com", "pass", Usuario.Rol.OPERARIO);

        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Usuario> resultado = usuarioService.actualizarUsuario(99L, detallesActualizados);

        assertFalse(resultado.isPresent());
        verify(usuarioRepository, times(1)).findById(99L);
        verify(usuarioRepository, never()).save(any(Usuario.class));
    }

    @Test
    void eliminarUsuario_conIdExistente_debeEliminarYRetornarTrue() {
        when(usuarioRepository.existsById(1L)).thenReturn(true);
        doNothing().when(usuarioRepository).deleteById(1L);

        boolean resultado = usuarioService.eliminarUsuario(1L);

        assertTrue(resultado);
        verify(usuarioRepository, times(1)).existsById(1L);
        verify(usuarioRepository, times(1)).deleteById(1L);
    }

    @Test
    void eliminarUsuario_conIdNoExistente_debeRetornarFalse() {
        when(usuarioRepository.existsById(99L)).thenReturn(false);

        boolean resultado = usuarioService.eliminarUsuario(99L);

        assertFalse(resultado);
        verify(usuarioRepository, times(1)).existsById(99L);
        verify(usuarioRepository, never()).deleteById(anyLong());
    }
}