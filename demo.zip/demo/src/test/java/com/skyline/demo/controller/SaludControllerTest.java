package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skyline.demo.model.Salud;
import com.skyline.demo.repository.SaludRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest; 
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SaludController.class)
public class SaludControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
	@MockBean
    private SaludRepository saludRepository;

    @Autowired 
    private ObjectMapper objectMapper;


    @Test
    void debeRegistrarControlSaludableYDevolver201() throws Exception {
        //Registro
        Salud saludEntrada = new Salud();
        saludEntrada.setLoteId(2L);
        saludEntrada.setFecha(LocalDate.now().minusDays(1));
        saludEntrada.setTipoControl("Inspección General");
        saludEntrada.setDescripcion("Todas las aves están activas y comen bien.");
        saludEntrada.setResultado(Salud.ResultadoControl.saludable);

        // Salida Esperada
        Salud saludSalida = new Salud();
        saludSalida.setId(5L); 
        saludSalida.setLoteId(2L);
        saludSalida.setFecha(LocalDate.now().minusDays(1));
        saludSalida.setTipoControl("Inspección General");
        saludSalida.setResultado(Salud.ResultadoControl.saludable);
        
        when(saludRepository.save(any(Salud.class))).thenReturn(saludSalida);

        mockMvc.perform(post("/api/salud")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(saludEntrada)))
        
                .andExpect(status().isCreated()) // 201 Created
                .andExpect(jsonPath("$.id").value(5L))
                .andExpect(jsonPath("$.resultado").value("saludable"));
    }
    
    @Test
    void debeRegistrarVacunacionYDevolver201() throws Exception {
        // Registro de vacunación
        Salud saludEntrada = new Salud();
        saludEntrada.setLoteId(3L);
        saludEntrada.setFecha(LocalDate.now());
        saludEntrada.setTipoControl("Vacunación NewCastle");
        saludEntrada.setDescripcion("Vacuna aplicada por agua de bebida.");
        saludEntrada.setResultado(Salud.ResultadoControl.vacunado);

        // Salida simulada
        Salud saludSalida = new Salud();
        saludSalida.setId(6L); 
        saludSalida.setLoteId(3L);
        saludSalida.setFecha(LocalDate.now());
        saludSalida.setTipoControl("Vacunación NewCastle");
        saludSalida.setResultado(Salud.ResultadoControl.vacunado);
        
        when(saludRepository.save(any(Salud.class))).thenReturn(saludSalida);

        mockMvc.perform(post("/api/salud")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(saludEntrada)))
        
                .andExpect(status().isCreated()) //201 Created
                .andExpect(jsonPath("$.resultado").value("vacunado"));
    }



    @Test
    void debeDevolverError400SiFechaEsFutura() throws Exception {
        // Registro inválido
        Salud saludInvalida = new Salud();
        saludInvalida.setLoteId(4L); 
        saludInvalida.setFecha(LocalDate.now().plusDays(1));
        saludInvalida.setTipoControl("Inspección");
        saludInvalida.setResultado(Salud.ResultadoControl.saludable);

        mockMvc.perform(post("/api/salud")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(saludInvalida)))
            .andExpect(status().isBadRequest()); // Espera 400 
    }

    @Test
    void debeDevolverError400SiResultadoEsNulo() throws Exception {
        // Registro inválido
        Salud saludInvalida = new Salud();
        saludInvalida.setLoteId(4L); 
        saludInvalida.setFecha(LocalDate.now());
        saludInvalida.setTipoControl("Inspección");
        saludInvalida.setResultado(null);

        mockMvc.perform(post("/api/salud")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(saludInvalida)))
            
            .andExpect(status().isBadRequest()); // Espera 400
    }
}