package com.skyline.demo.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.skyline.demo.model.Salud;
import com.skyline.demo.model.Salud.ResultadoControl;
import com.skyline.demo.service.SaludService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SaludController.class)
public class SaludControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SaludService saludService;

    private ObjectMapper objectMapper;
    private Salud controlVacunacion;
    private Salud controlEnfermo;
    private LocalDate today = LocalDate.now();

    @BeforeEach
    void setUp() {
        // Configurar ObjectMapper para manejar LocalDate
        objectMapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();

        controlVacunacion = new Salud(1L, today.minusDays(5), "Vacunación", "Dosis completa", ResultadoControl.vacunado);
        controlVacunacion.setId(10L);

        controlEnfermo = new Salud(2L, today.minusDays(1), "Examen", "Diagnóstico Gumboro", ResultadoControl.enfermo);
        controlEnfermo.setId(20L);
    }

    // --- Pruebas para POST (Registro) ---

    @Test
    void registrarControl_debeDevolver201_yControlCreado() throws Exception {
        Salud nuevoControl = new Salud(3L, today, "Control Rutina", "Todo bien", ResultadoControl.saludable);
        Salud controlGuardado = new Salud(3L, today, "Control Rutina", "Todo bien", ResultadoControl.saludable);
        controlGuardado.setId(30L);

        when(saludService.registrarControl(any(Salud.class))).thenReturn(controlGuardado);

        mockMvc.perform(post("/api/salud")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoControl)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(30L))
                .andExpect(jsonPath("$.resultado").value("saludable"));
        
        verify(saludService, times(1)).registrarControl(any(Salud.class));
    }
    
    // --- Pruebas para GET (Obtener) ---

    @Test
    void obtenerTodosLosControles_debeDevolver200_yListaDeControles() throws Exception {
        when(saludService.obtenerTodosLosControles()).thenReturn(Arrays.asList(controlVacunacion, controlEnfermo));

        mockMvc.perform(get("/api/salud")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].tipoControl").value("Vacunación"));

        verify(saludService, times(1)).obtenerTodosLosControles();
    }

    @Test
    void obtenerControlPorId_debeDevolver200_cuandoExiste() throws Exception {
        when(saludService.obtenerControlPorId(10L)).thenReturn(Optional.of(controlVacunacion));

        mockMvc.perform(get("/api/salud/{id}", 10L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.resultado").value("vacunado"));
        
        verify(saludService, times(1)).obtenerControlPorId(10L);
    }

    @Test
    void obtenerControlPorId_debeDevolver404_cuandoNoExiste() throws Exception {
        when(saludService.obtenerControlPorId(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/salud/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        
        verify(saludService, times(1)).obtenerControlPorId(99L);
    }

    // --- Pruebas para PUT (Actualización) ---

    @Test
    void actualizarControl_debeDevolver200_yControlActualizado() throws Exception {
        Salud detallesNuevos = new Salud(1L, today, "Vacunación", "Descripción editada", ResultadoControl.saludable);
        Salud controlActualizado = new Salud(1L, today, "Vacunación", "Descripción editada", ResultadoControl.saludable);
        controlActualizado.setId(10L);

        when(saludService.actualizarControl(eq(10L), any(Salud.class))).thenReturn(Optional.of(controlActualizado));

        mockMvc.perform(put("/api/salud/{id}", 10L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.descripcion").value("Descripción editada"))
                .andExpect(jsonPath("$.resultado").value("saludable"));
        
        verify(saludService, times(1)).actualizarControl(eq(10L), any(Salud.class));
    }

    @Test
    void actualizarControl_debeDevolver404_cuandoNoExiste() throws Exception {
        Salud detallesNuevos = new Salud(1L, today, "Control inexistente", "", ResultadoControl.saludable);
        
        when(saludService.actualizarControl(eq(99L), any(Salud.class))).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/salud/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(detallesNuevos)))
                .andExpect(status().isNotFound());
        
        verify(saludService, times(1)).actualizarControl(eq(99L), any(Salud.class));
    }

    // --- Pruebas para DELETE (Eliminación) ---

    @Test
    void eliminarControl_debeDevolver204_cuandoExiste() throws Exception {
        when(saludService.eliminarControl(10L)).thenReturn(true);

        mockMvc.perform(delete("/api/salud/{id}", 10L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(saludService, times(1)).eliminarControl(10L);
    }

    @Test
    void eliminarControl_debeDevolver404_cuandoNoExiste() throws Exception {
        when(saludService.eliminarControl(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/salud/{id}", 99L)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(saludService, times(1)).eliminarControl(99L);
    }
}