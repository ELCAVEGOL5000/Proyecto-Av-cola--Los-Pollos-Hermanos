package com.skyline.demo.service;

import com.skyline.demo.model.Lote;
import com.skyline.demo.model.Produccion;
import com.skyline.demo.repository.LoteRepository;
import com.skyline.demo.repository.ProduccionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ProduccionServiceTest {

    @Mock
    private ProduccionRepository produccionRepository;

    @Mock
    private LoteRepository loteRepository;

    @InjectMocks
    private ProduccionService produccionService;

    private Produccion produccion1;
    private Produccion produccion2;
    private Lote loteExistente;

    @BeforeEach
    void setUp() {
        // Lote de referencia para la validación de coherencia (capacidad: 1000)
        loteExistente = new Lote();
        loteExistente.setId(10L);
        loteExistente.setCantidad(1000); // 1000 aves

        // Producción válida (300 unidades de Huevo A)
        produccion1 = new Produccion(10L, LocalDate.of(2025, 11, 1), "Huevo A", new BigDecimal("300.00"));
        produccion1.setId(1L);

        // Producción válida (750 unidades de Carne)
        produccion2 = new Produccion(10L, LocalDate.of(2025, 11, 5), "Carne", new BigDecimal("750.50"));
        produccion2.setId(2L);
    }

    // --- Pruebas para registrarProduccion ---

    @Test
    void registrarProduccion_debeGuardar_cuandoEsCoherente() {
        when(loteRepository.findById(10L)).thenReturn(Optional.of(loteExistente));
        when(produccionRepository.save(any(Produccion.class))).thenReturn(produccion1);

        Produccion resultado = produccionService.registrarProduccion(produccion1);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        verify(produccionRepository, times(1)).save(produccion1);
        verify(loteRepository, times(1)).findById(10L);
    }

    @Test
    void registrarProduccion_debeLanzarExcepcion_cuandoLaCantidadEsIncoherente() {
        // Intenta registrar 1500 unidades, pero el lote solo tiene 1000 aves.
        Produccion produccionIncoherente = new Produccion(10L, LocalDate.now(), "Huevo B", new BigDecimal("1500.00"));
        
        when(loteRepository.findById(10L)).thenReturn(Optional.of(loteExistente));

        // Verificamos que se lance IllegalArgumentException
        Exception excepcion = assertThrows(IllegalArgumentException.class, () -> {
            produccionService.registrarProduccion(produccionIncoherente);
        });

        assertTrue(excepcion.getMessage().contains("La cantidad de producción"));
        assertTrue(excepcion.getMessage().contains("Supera la cantidad de aves en el lote"));
        verify(produccionRepository, never()).save(any(Produccion.class));
        verify(loteRepository, times(1)).findById(10L);
    }

    @Test
    void registrarProduccion_debeLanzarExcepcion_cuandoLoteIdNoExiste() {
        Produccion produccionConLoteInvalido = new Produccion(99L, LocalDate.now(), "Huevo", new BigDecimal("100.00"));
        
        when(loteRepository.findById(99L)).thenReturn(Optional.empty());

        Exception excepcion = assertThrows(IllegalArgumentException.class, () -> {
            produccionService.registrarProduccion(produccionConLoteInvalido);
        });

        assertTrue(excepcion.getMessage().contains("Lote ID 99 no encontrado"));
        verify(produccionRepository, never()).save(any(Produccion.class));
    }
    
    // --- Pruebas para actualizarProduccion ---

    @Test
    void actualizarProduccion_debeActualizar_cuandoExisteYEsCoherente() {
        Produccion detallesNuevos = new Produccion(10L, LocalDate.of(2025, 11, 2), "Huevo C", new BigDecimal("500.00"));
        
        when(produccionRepository.findById(1L)).thenReturn(Optional.of(produccion1));
        when(loteRepository.findById(10L)).thenReturn(Optional.of(loteExistente));
        when(produccionRepository.save(any(Produccion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Produccion> resultado = produccionService.actualizarProduccion(1L, detallesNuevos);

        assertTrue(resultado.isPresent());
        assertEquals("Huevo C", resultado.get().getTipoProduccion());
        assertEquals(new BigDecimal("500.00"), resultado.get().getCantidad());
        verify(produccionRepository, times(1)).findById(1L);
        verify(produccionRepository, times(1)).save(produccion1);
    }

    @Test
    void actualizarProduccion_debeLanzarExcepcion_cuandoActualizacionEsIncoherente() {
        // Detalle nuevo que supera la capacidad del lote (1500 > 1000)
        Produccion detallesNuevos = new Produccion(10L, LocalDate.of(2025, 11, 2), "Carne Procesada", new BigDecimal("1500.00"));
        
        when(produccionRepository.findById(1L)).thenReturn(Optional.of(produccion1));
        when(loteRepository.findById(10L)).thenReturn(Optional.of(loteExistente));

        Exception excepcion = assertThrows(IllegalArgumentException.class, () -> {
            produccionService.actualizarProduccion(1L, detallesNuevos);
        });

        assertTrue(excepcion.getMessage().contains("Supera la cantidad de aves"));
        verify(produccionRepository, times(1)).findById(1L);
        verify(produccionRepository, never()).save(any(Produccion.class));
    }
    
    @Test
    void actualizarProduccion_debeDevolverVacio_cuandoNoExiste() {
        Produccion detallesNuevos = new Produccion(10L, LocalDate.now(), "Huevo", new BigDecimal("10.0"));
        
        when(produccionRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Produccion> resultado = produccionService.actualizarProduccion(99L, detallesNuevos);

        assertFalse(resultado.isPresent());
        verify(produccionRepository, times(1)).findById(99L);
        verify(loteRepository, never()).findById(anyLong()); // No se llama a validarCoherencia
        verify(produccionRepository, never()).save(any(Produccion.class));
    }

    // --- Pruebas CRUD básicas ---

    @Test
    void obtenerTodas_debeDevolverListaDeRegistros() {
        List<Produccion> registros = Arrays.asList(produccion1, produccion2);
        when(produccionRepository.findAll()).thenReturn(registros);

        List<Produccion> resultado = produccionService.obtenerTodas();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(produccionRepository, times(1)).findAll();
    }

    @Test
    void obtenerProduccionPorId_debeDevolverRegistro_cuandoExiste() {
        when(produccionRepository.findById(1L)).thenReturn(Optional.of(produccion1));

        Optional<Produccion> resultado = produccionService.obtenerProduccionPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Huevo A", resultado.get().getTipoProduccion());
        verify(produccionRepository, times(1)).findById(1L);
    }
    
    @Test
    void eliminarProduccion_debeDevolverTrue_cuandoExiste() {
        when(produccionRepository.existsById(1L)).thenReturn(true);
        doNothing().when(produccionRepository).deleteById(1L);

        boolean resultado = produccionService.eliminarProduccion(1L);

        assertTrue(resultado);
        verify(produccionRepository, times(1)).existsById(1L);
        verify(produccionRepository, times(1)).deleteById(1L);
    }
    
    @Test
    void eliminarProduccion_debeDevolverFalse_cuandoNoExiste() {
        when(produccionRepository.existsById(99L)).thenReturn(false);

        boolean resultado = produccionService.eliminarProduccion(99L);

        assertFalse(resultado);
        verify(produccionRepository, times(1)).existsById(99L);
        verify(produccionRepository, never()).deleteById(99L);
    }
}